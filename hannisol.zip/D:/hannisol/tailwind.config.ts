import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  prefix: "",
  theme: {
    container: {
      center: true,
      padding: "2rem",
      screens: {
        "2xl": "1400px",
      },
    },
    extend: {
      colors: {
        border: "hsl(var(--border))",
        input: "hsl(var(--input))",
        ring: "hsl(var(--ring))",
        background: "hsl(var(--background))",
        foreground: "hsl(var(--foreground))",
        primary: {
          DEFAULT: "hsl(var(--primary))",
          foreground: "hsl(var(--primary-foreground))",
        },
        secondary: {
          DEFAULT: "hsl(var(--secondary))",
          foreground: "hsl(var(--secondary-foreground))",
        },
        destructive: {
          DEFAULT: "hsl(var(--destructive))",
          foreground: "hsl(var(--destructive-foreground))",
        },
        muted: {
          DEFAULT: "hsl(var(--muted))",
          foreground: "hsl(var(--muted-foreground))",
        },
        accent: {
          DEFAULT: "hsl(var(--accent))",
          foreground: "hsl(var(--accent-foreground))",
        },
        popover: {
          DEFAULT: "hsl(var(--popover))",
          foreground: "hsl(var(--popover-foreground))",
        },
        card: {
          DEFAULT: "hsl(var(--card))",
          foreground: "hsl(var(--card-foreground))",
        },
        // Hannisol Brand Colors
        hannisol: {
          gold: {
            50: "#fefce8",
            100: "#fef3c7", 
            200: "#fde68a",
            300: "#fcd34d",
            400: "#fbbf24",
            500: "#f59e0b", // Primary gold
            600: "#d97706",
            700: "#b45309",
            800: "#92400e",
            900: "#78350f",
          },
          teal: {
            400: "#4ade80",
            500: "#10b981",
            600: "#059669",
          },
          purple: {
            400: "#a855f7",
            500: "#9333ea", 
            600: "#7c3aed",
          },
          orange: {
            400: "#fb923c",
            500: "#f97316",
            600: "#ea580c",
          }
        },
        // Solana Status Colors
        solana: {
          valid: "#10b981",   // Green
          warning: "#f59e0b", // Yellow
          error: "#ef4444",   // Red
          info: "#3b82f6",    // Blue
          neutral: "#6b7280", // Gray
        }
      },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
      },
      fontFamily: {
        sans: ["var(--font-geist-sans)", "system-ui", "sans-serif"],
        mono: ["var(--font-geist-mono)", "monospace"],
        // Hannisol Brand Typography
        serif: ["Times", "Georgia", "serif"],
      },
      letterSpacing: {
        'brand': '3px', // For HANNISOL text
      },
      keyframes: {
        "accordion-down": {
          from: { height: "0" },
          to: { height: "var(--radix-accordion-content-height)" },
        },
        "accordion-up": {
          from: { height: "var(--radix-accordion-content-height)" },
          to: { height: "0" },
        },
        // Custom animations for address checker
        "pulse-gold": {
          "0%, 100%": { 
            transform: "scale(1)",
            backgroundColor: "rgb(251 191 36 / 0.1)"
          },
          "50%": { 
            transform: "scale(1.05)",
            backgroundColor: "rgb(251 191 36 / 0.2)"
          },
        },
        "slide-in": {
          "0%": { 
            opacity: "0", 
            transform: "translateY(10px)" 
          },
          "100%": { 
            opacity: "1", 
            transform: "translateY(0)" 
          },
        },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
        "pulse-gold": "pulse-gold 2s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "slide-in": "slide-in 0.3s ease-out",
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'gradient-conic': 'conic-gradient(from 180deg at 50% 50%, var(--tw-gradient-stops))',
        // Hannisol brand gradients
        'hannisol-gold': 'linear-gradient(135deg, #fbbf24 0%, #f59e0b 50%, #d97706 100%)',
        'hannisol-accent': 'linear-gradient(135deg, #4ade80 0%, #a855f7 50%, #fb923c 100%)',
      },
      boxShadow: {
        'gold': '0 4px 14px 0 rgb(251 191 36 / 0.25)',
        'card-hover': '0 8px 30px 0 rgb(0 0 0 / 0.12)',
      }
    },
  },
  plugins: [require("tailwindcss-animate")],
} satisfies Config;

export default config;