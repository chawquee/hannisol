/** @type {import('next').NextConfig} */
const nextConfig = {
  // Performance optimizations
  experimental: {
    optimizePackageImports: ['lucide-react', '@radix-ui/react-icons'],
  },
  
  // Image optimization
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**',
      },
    ],
    formats: ['image/webp', 'image/avif'],
    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
  },

  // SEO and Performance
  poweredByHeader: false,
  generateEtags: true,
  compress: true,

  // Headers for SEO and security
  async headers() {
    return [
      {
        source: '/:path*',
        headers: [
          {
            key: 'X-DNS-Prefetch-Control',
            value: 'on'
          },
          {
            key: 'X-XSS-Protection',
            value: '1; mode=block'
          },
          {
            key: 'X-Frame-Options',
            value: 'SAMEORIGIN'
          },
          {
            key: 'X-Content-Type-Options',
            value: 'nosniff'
          },
          {
            key: 'Referrer-Policy',
            value: 'origin-when-cross-origin'
          },
          // Cache headers for static assets
          {
            key: 'Cache-Control',
            value: 'public, max-age=31536000, immutable'
          }
        ],
      },
      // API routes caching
      {
        source: '/api/:path*',
        headers: [
          {
            key: 'Cache-Control',
            value: 'public, max-age=300, stale-while-revalidate=600'
          }
        ],
      }
    ]
  },

  // Redirects for SEO
  async redirects() {
    return [
      {
        source: '/check',
        destination: '/',
        permanent: true,
      },
      {
        source: '/checker',
        destination: '/',
        permanent: true,
      },
      {
        source: '/validate',
        destination: '/',
        permanent: true,
      }
    ]
  },

  // Rewrites for clean URLs
  async rewrites() {
    return [
      {
        source: '/sitemap.xml',
        destination: '/api/sitemap',
      },
      {
        source: '/robots.txt',
        destination: '/api/robots',
      }
    ]
  },

  // Webpack configuration for optimizations
  webpack: (config, { isServer }) => {
    // Optimize bundle size
    config.resolve.fallback = {
      ...config.resolve.fallback,
      fs: false,
      net: false,
      tls: false,
    };

    // Add bundle analyzer in development
    if (!isServer && process.env.ANALYZE === 'true') {
      const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');
      config.plugins.push(
        new BundleAnalyzerPlugin({
          analyzerMode: 'browser',
          openAnalyzer: true,
        })
      );
    }

    return config;
  },

  // Environment variables for ads and analytics
  env: {
    GOOGLE_ADSENSE_ID: process.env.GOOGLE_ADSENSE_ID,
    GOOGLE_ANALYTICS_ID: process.env.GOOGLE_ANALYTICS_ID,
    COINZILLA_ZONE_ID: process.env.COINZILLA_ZONE_ID,
    A_ADS_ID: process.env.A_ADS_ID,
    MEDIA_NET_ID: process.env.MEDIA_NET_ID,
    SOLANA_RPC_URL: process.env.SOLANA_RPC_URL,
    NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL || 'https://hannisol.com',
  },

  // TypeScript configuration
  typescript: {
    // Disable type checking during build (handle in CI/CD)
    ignoreBuildErrors: false,
  },

  // ESLint configuration
  eslint: {
    ignoreDuringBuilds: false,
  },

  // Output configuration for deployment
  output: 'standalone',
  
  // Disable source maps in production for security
  productionBrowserSourceMaps: false,

  // Experimental features for performance
  swcMinify: true,
  
  // Runtime configuration
  serverRuntimeConfig: {
    // Server-only secrets
  },
  publicRuntimeConfig: {
    // Client-side environment variables
    siteUrl: process.env.NEXT_PUBLIC_SITE_URL || 'https://hannisol.com',
    siteName: 'Hannisol - Solana Address Checker',
    siteDescription: 'Professional Solana address validation and analysis tool with real-time balance tracking, security assessment, and risk analysis.',
  },
};

module.exports = nextConfig;