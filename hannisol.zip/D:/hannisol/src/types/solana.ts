// Solana Address Types
export interface SolanaAddress {
  address: string
  isValid: boolean
  type: 'wallet' | 'program' | 'token_account' | 'unknown'
  network: 'mainnet' | 'testnet' | 'devnet'
}

// Balance and Token Types
export interface TokenInfo {
  mint: string
  symbol: string
  name: string
  decimals: number
  logo?: string
  website?: string
  coingeckoId?: string
}

export interface TokenBalance {
  mint: string
  tokenInfo: TokenInfo
  balance: string
  uiAmount: number
  decimals: number
  value?: number
}

export interface SolanaBalance {
  solBalance: number
  lamports: number
  usdValue: number
  tokens: TokenBalance[]
  nftCount: number
  totalValue: number
  lastUpdated: Date
}

// Transaction Types
export interface TransactionSignature {
  signature: string
  slot: number
  blockTime: number
  confirmationStatus: 'processed' | 'confirmed' | 'finalized'
}

export interface SolanaTransaction {
  signature: string
  slot: number
  blockTime: number
  fee: number
  status: 'success' | 'failed'
  type: 'transfer' | 'receive' | 'stake' | 'unstake' | 'swap' | 'nft' | 'unknown'
  amount?: number
  token?: string
  from?: string
  to?: string
  programId?: string
  inner_instructions?: any[]
}

// Account Types
export interface AccountInfo {
  address: string
  lamports: number
  owner: string
  executable: boolean
  rentEpoch: number
  dataSize: number
  data?: any
}

// Risk Assessment Types
export interface RiskMetric {
  name: string
  score: number
  weight: number
  description: string
  category: 'security' | 'liquidity' | 'community' | 'technical'
}

export interface RiskAssessment {
  overallScore: number
  riskLevel: 'very_low' | 'low' | 'medium' | 'high' | 'very_high'
  metrics: RiskMetric[]
  warnings: string[]
  recommendations: string[]
  lastUpdated: Date
}

// Security Analysis Types
export interface SecurityFlag {
  type: 'warning' | 'error' | 'info'
  message: string
  severity: 'low' | 'medium' | 'high' | 'critical'
  category: string
}

export interface SecurityAnalysis {
  flags: SecurityFlag[]
  suspiciousActivity: boolean
  blacklisted: boolean
  whitelisted: boolean
  riskScore: number
  lastChecked: Date
}

// Community Data Types
export interface SocialMetric {
  platform: string
  followers: number
  engagement: number
  sentiment: 'positive' | 'neutral' | 'negative'
  lastUpdated: Date
}

export interface CommunityData {
  socialMetrics: SocialMetric[]
  overallSentiment: 'positive' | 'neutral' | 'negative'
  communityScore: number
  mentions: number
  trendingKeywords: string[]
  lastUpdated: Date
}

// Analysis Results Types
export interface AddressAnalysis {
  address: string
  validation: {
    isValid: boolean
    format: string
    length: number
    type: string
    network: string
    errors: string[]
  }
  balance: SolanaBalance
  transactions: SolanaTransaction[]
  account: AccountInfo
  security: SecurityAnalysis
  risk: RiskAssessment
  community: CommunityData
  finalGrade: {
    technical: number | string
    security: number | string
    community: number | string
    overall: string
    confidence: number
  }
  analysisTime: number
  timestamp: Date
}

// API Response Types
export interface ApiResponse<T> {
  success: boolean
  data?: T
  error?: string
  timestamp: Date
  requestId?: string
}

export interface PaginatedResponse<T> {
  data: T[]
  pagination: {
    page: number
    limit: number
    total: number
    hasNext: boolean
    hasPrev: boolean
  }
}

// WebSocket Types for Real-time Updates
export interface WebSocketMessage {
  type: 'balance_update' | 'new_transaction' | 'risk_update' | 'price_update'
  address: string
  data: any
  timestamp: Date
}

// Configuration Types
export interface RpcConfig {
  endpoint: string
  commitment: 'processed' | 'confirmed' | 'finalized'
  timeout: number
  retries: number
}

export interface AnalysisConfig {
  includeTransactions: boolean
  transactionLimit: number
  includeTokens: boolean
  includeNfts: boolean
  includeRiskAssessment: boolean
  includeCommunityData: boolean
  realTimeUpdates: boolean
}

// Error Types
export interface SolanaError {
  code: string
  message: string
  details?: any
  timestamp: Date
}

// Staking Information Types
export interface StakeAccount {
  address: string
  stakeAmount: number
  validator: string
  activationEpoch: number
  deactivationEpoch?: number
  status: 'active' | 'inactive' | 'activating' | 'deactivating'
  rewards: number
}

// NFT Types
export interface NftMetadata {
  mint: string
  name: string
  symbol: string
  image?: string
  description?: string
  collection?: string
  attributes?: Array<{
    trait_type: string
    value: string | number
  }>
}

export interface NftBalance {
  mint: string
  metadata: NftMetadata
  owner: string
  frozen: boolean
}

// Price Data Types
export interface PriceData {
  symbol: string
  price: number
  change24h: number
  volume24h: number
  marketCap: number
  lastUpdated: Date
}