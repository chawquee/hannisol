import { useState, useEffect, useCallback } from 'react'
import { isValidSolanaAddress } from '@/lib/utils'
import { trackAddressCheck, trackAnalysisComplete } from '@/components/analytics/google-analytics'

interface ValidationResult {
  isValid: boolean
  format: string
  length: number
  type: string
  network: string
  errors: string[]
}

interface AddressValidationState {
  address: string
  isValidating: boolean
  validationResult: ValidationResult | null
  error: string | null
}

export function useAddressValidation() {
  const [state, setState] = useState<AddressValidationState>({
    address: '',
    isValidating: false,
    validationResult: null,
    error: null
  })

  const validateAddress = useCallback(async (address: string) => {
    if (!address.trim()) {
      setState(prev => ({
        ...prev,
        address: '',
        validationResult: null,
        error: null
      }))
      return
    }

    setState(prev => ({
      ...prev,
      address: address.trim(),
      isValidating: true,
      error: null
    }))

    try {
      const startTime = Date.now()
      
      // Basic validation
      const isValid = isValidSolanaAddress(address.trim())
      const errors: string[] = []

      // Detailed validation checks
      if (address.length < 32) {
        errors.push('Address too short')
      }
      if (address.length > 44) {
        errors.push('Address too long')
      }
      if (!/^[1-9A-HJ-NP-Za-km-z]+$/.test(address)) {
        errors.push('Invalid Base58 characters')
      }

      const validationResult: ValidationResult = {
        isValid,
        format: 'Base58',
        length: address.length,
        type: 'Wallet Address',
        network: 'Solana Mainnet',
        errors
      }

      // Simulate network validation delay
      await new Promise(resolve => setTimeout(resolve, 500))

      setState(prev => ({
        ...prev,
        isValidating: false,
        validationResult,
        error: null
      }))

      // Track validation
      const analysisTime = Date.now() - startTime
      trackAddressCheck(address, isValid)
      if (isValid) {
        trackAnalysisComplete(address, analysisTime)
      }

    } catch (error) {
      setState(prev => ({
        ...prev,
        isValidating: false,
        error: error instanceof Error ? error.message : 'Validation failed'
      }))
    }
  }, [])

  const resetValidation = useCallback(() => {
    setState({
      address: '',
      isValidating: false,
      validationResult: null,
      error: null
    })
  }, [])

  return {
    ...state,
    validateAddress,
    resetValidation
  }
}