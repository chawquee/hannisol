import { useState, useEffect, useCallback } from 'react'
import { isValidSolanaAddress } from '@/lib/utils'

interface TokenBalance {
  mint: string
  symbol: string
  name: string
  balance: number
  decimals: number
  uiAmount: number
  logo?: string
}

interface BalanceData {
  solBalance: number
  usdValue: number
  tokens: TokenBalance[]
  nftCount: number
  totalValue: number
  lastUpdated: Date
}

interface BalanceState {
  data: BalanceData | null
  isLoading: boolean
  error: string | null
  lastFetched: Date | null
}

export function useSolanaBalance(address?: string) {
  const [state, setState] = useState<BalanceState>({
    data: null,
    isLoading: false,
    error: null,
    lastFetched: null
  })

  const fetchBalance = useCallback(async (targetAddress: string) => {
    if (!targetAddress || !isValidSolanaAddress(targetAddress)) {
      setState(prev => ({
        ...prev,
        error: 'Invalid Solana address'
      }))
      return
    }

    setState(prev => ({
      ...prev,
      isLoading: true,
      error: null
    }))

    try {
      // For demo purposes, we'll return mock data
      // In production, this would make actual RPC calls to Solana
      
      await new Promise(resolve => setTimeout(resolve, 1000)) // Simulate API delay

      const mockBalanceData: BalanceData = {
        solBalance: 1.25,
        usdValue: 127.89,
        tokens: [
          {
            mint: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
            symbol: 'USDC',
            name: 'USD Coin',
            balance: 2000000,
            decimals: 6,
            uiAmount: 2.0,
            logo: '/tokens/usdc.png'
          }
        ],
        nftCount: 3,
        totalValue: 129.89,
        lastUpdated: new Date()
      }

      setState(prev => ({
        ...prev,
        data: mockBalanceData,
        isLoading: false,
        lastFetched: new Date()
      }))

    } catch (error) {
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Failed to fetch balance'
      }))
    }
  }, [])

  const refreshBalance = useCallback(() => {
    if (address) {
      fetchBalance(address)
    }
  }, [address, fetchBalance])

  // Auto-fetch when address changes
  useEffect(() => {
    if (address && isValidSolanaAddress(address)) {
      fetchBalance(address)
    }
  }, [address, fetchBalance])

  return {
    ...state,
    fetchBalance,
    refreshBalance
  }
}

// Hook for getting SOL price data
export function useSolanaPrice() {
  const [price, setPrice] = useState<number | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const fetchPrice = useCallback(async () => {
    setIsLoading(true)
    setError(null)

    try {
      // In production, this would fetch from CoinGecko or another price API
      await new Promise(resolve => setTimeout(resolve, 500))
      
      // Mock SOL price
      setPrice(102.31)
      
    } catch (error) {
      setError(error instanceof Error ? error.message : 'Failed to fetch price')
    } finally {
      setIsLoading(false)
    }
  }, [])

  useEffect(() => {
    fetchPrice()
    
    // Refresh price every 5 minutes
    const interval = setInterval(fetchPrice, 5 * 60 * 1000)
    return () => clearInterval(interval)
  }, [fetchPrice])

  return {
    price,
    isLoading,
    error,
    refreshPrice: fetchPrice
  }
}