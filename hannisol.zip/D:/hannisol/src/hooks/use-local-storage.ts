import { useState, useEffect, useCallback, useRef } from 'react'

// Type for the hook return value
type UseLocalStorageReturn<T> = [
  T,
  (value: T | ((prev: T) => T)) => void,
  () => void
]

// Type for storage event
interface StorageChangeEvent<T> {
  key: string
  oldValue: T | null
  newValue: T | null
}

// Hook for localStorage with TypeScript support and SSR safety
export function useLocalStorage<T>(
  key: string,
  defaultValue: T,
  options: {
    serialize?: (value: T) => string
    deserialize?: (value: string) => T
    onError?: (error: Error) => void
  } = {}
): UseLocalStorageReturn<T> {
  const {
    serialize = JSON.stringify,
    deserialize = JSON.parse,
    onError = console.error
  } = options

  // Store the default value to avoid unnecessary re-renders
  const defaultValueRef = useRef(defaultValue)
  defaultValueRef.current = defaultValue

  const [state, setState] = useState<T>(() => {
    // Only access localStorage on client side
    if (typeof window === 'undefined') {
      return defaultValue
    }

    try {
      const item = localStorage.getItem(key)
      if (item === null) {
        return defaultValue
      }
      return deserialize(item)
    } catch (error) {
      onError(error as Error)
      return defaultValue
    }
  })

  // Update localStorage when state changes
  const setValue = useCallback(
    (value: T | ((prev: T) => T)) => {
      try {
        setState(prevState => {
          const newValue = typeof value === 'function' 
            ? (value as (prev: T) => T)(prevState)
            : value

          if (typeof window !== 'undefined') {
            localStorage.setItem(key, serialize(newValue))
          }

          return newValue
        })
      } catch (error) {
        onError(error as Error)
      }
    },
    [key, serialize, onError]
  )

  // Remove item from localStorage
  const removeValue = useCallback(() => {
    try {
      setState(defaultValueRef.current)
      if (typeof window !== 'undefined') {
        localStorage.removeItem(key)
      }
    } catch (error) {
      onError(error as Error)
    }
  }, [key, onError])

  // Listen for storage changes from other tabs/windows
  useEffect(() => {
    if (typeof window === 'undefined') return

    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === key && e.newValue !== null) {
        try {
          setState(deserialize(e.newValue))
        } catch (error) {
          onError(error as Error)
        }
      } else if (e.key === key && e.newValue === null) {
        setState(defaultValueRef.current)
      }
    }

    window.addEventListener('storage', handleStorageChange)
    return () => window.removeEventListener('storage', handleStorageChange)
  }, [key, deserialize, onError])

  return [state, setValue, removeValue]
}

// Hook for storing user preferences
export function useUserPreferences() {
  const [preferences, setPreferences, removePreferences] = useLocalStorage('hannisol_preferences', {
    theme: 'system' as 'light' | 'dark' | 'system',
    currency: 'USD' as string,
    language: 'en' as string,
    notifications: {
      browser: true,
      email: true,
      security: true,
      marketing: false
    },
    privacy: {
      analytics: true,
      cookies: true,
      thirdParty: false
    },
    ui: {
      compactMode: false,
      animationsEnabled: true,
      soundEnabled: false
    }
  })

  const updatePreference = useCallback(<K extends keyof typeof preferences>(
    key: K,
    value: typeof preferences[K]
  ) => {
    setPreferences(prev => ({
      ...prev,
      [key]: value
    }))
  }, [setPreferences])

  const resetPreferences = useCallback(() => {
    removePreferences()
  }, [removePreferences])

  return {
    preferences,
    setPreferences,
    updatePreference,
    resetPreferences
  }
}

// Hook for storing recent addresses
export function useRecentAddresses(maxItems: number = 10) {
  const [recentAddresses, setRecentAddresses] = useLocalStorage<string[]>('hannisol_recent_addresses', [])

  const addAddress = useCallback((address: string) => {
    setRecentAddresses(prev => {
      // Remove if already exists
      const filtered = prev.filter(addr => addr !== address)
      // Add to beginning
      const updated = [address, ...filtered]
      // Limit to maxItems
      return updated.slice(0, maxItems)
    })
  }, [setRecentAddresses, maxItems])

  const removeAddress = useCallback((address: string) => {
    setRecentAddresses(prev => prev.filter(addr => addr !== address))
  }, [setRecentAddresses])

  const clearAddresses = useCallback(() => {
    setRecentAddresses([])
  }, [setRecentAddresses])

  return {
    recentAddresses,
    addAddress,
    removeAddress,
    clearAddresses
  }
}

// Hook for storing favorite addresses
export function useFavoriteAddresses() {
  const [favorites, setFavorites] = useLocalStorage<Array<{
    address: string
    label?: string
    addedAt: number
  }>>('hannisol_favorite_addresses', [])

  const addFavorite = useCallback((address: string, label?: string) => {
    setFavorites(prev => {
      // Check if already exists
      if (prev.some(fav => fav.address === address)) {
        return prev
      }
      
      return [...prev, {
        address,
        label,
        addedAt: Date.now()
      }]
    })
  }, [setFavorites])

  const removeFavorite = useCallback((address: string) => {
    setFavorites(prev => prev.filter(fav => fav.address !== address))
  }, [setFavorites])

  const updateFavoriteLabel = useCallback((address: string, label: string) => {
    setFavorites(prev => prev.map(fav => 
      fav.address === address ? { ...fav, label } : fav
    ))
  }, [setFavorites])

  const isFavorite = useCallback((address: string) => {
    return favorites.some(fav => fav.address === address)
  }, [favorites])

  return {
    favorites,
    addFavorite,
    removeFavorite,
    updateFavoriteLabel,
    isFavorite
  }
}

// Hook for storing search history
export function useSearchHistory(maxItems: number = 20) {
  const [searchHistory, setSearchHistory] = useLocalStorage<Array<{
    query: string
    timestamp: number
    results?: number
  }>>('hannisol_search_history', [])

  const addSearch = useCallback((query: string, results?: number) => {
    setSearchHistory(prev => {
      const filtered = prev.filter(item => item.query !== query)
      const updated = [{
        query,
        timestamp: Date.now(),
        results
      }, ...filtered]
      return updated.slice(0, maxItems)
    })
  }, [setSearchHistory, maxItems])

  const removeSearch = useCallback((query: string) => {
    setSearchHistory(prev => prev.filter(item => item.query !== query))
  }, [setSearchHistory])

  const clearHistory = useCallback(() => {
    setSearchHistory([])
  }, [setSearchHistory])

  return {
    searchHistory,
    addSearch,
    removeSearch,
    clearHistory
  }
}

// Hook for storing UI state (collapsed sidebars, etc.)
export function useUIState() {
  const [uiState, setUIState] = useLocalStorage('hannisol_ui_state', {
    sidebarCollapsed: false,
    activeTab: 'overview',
    tableView: 'cards' as 'cards' | 'table',
    sortBy: 'date' as string,
    sortOrder: 'desc' as 'asc' | 'desc',
    filters: {
      showOnlyValid: false,
      hideEmpty: false,
      dateRange: 'all'
    }
  })

  const updateUIState = useCallback(<K extends keyof typeof uiState>(
    key: K,
    value: typeof uiState[K]
  ) => {
    setUIState(prev => ({
      ...prev,
      [key]: value
    }))
  }, [setUIState])

  return {
    uiState,
    setUIState,
    updateUIState
  }
}

// Hook for storing API configuration
export function useAPIConfig() {
  const [config, setConfig] = useLocalStorage('hannisol_api_config', {
    rpcEndpoint: 'https://api.mainnet-beta.solana.com',
    timeout: 30000,
    retries: 3,
    rateLimitPerMinute: 60,
    cacheEnabled: true,
    cacheTTL: 300000 // 5 minutes
  })

  const updateConfig = useCallback(<K extends keyof typeof config>(
    key: K,
    value: typeof config[K]
  ) => {
    setConfig(prev => ({
      ...prev,
      [key]: value
    }))
  }, [setConfig])

  return {
    config,
    setConfig,
    updateConfig
  }
}

// Storage event emitter for cross-component communication
class StorageEventEmitter {
  private listeners: Map<string, Set<(data: any) => void>> = new Map()

  emit<T>(key: string, data: T) {
    const keyListeners = this.listeners.get(key)
    if (keyListeners) {
      keyListeners.forEach(listener => listener(data))
    }
  }

  on<T>(key: string, listener: (data: T) => void) {
    if (!this.listeners.has(key)) {
      this.listeners.set(key, new Set())
    }
    this.listeners.get(key)!.add(listener)

    return () => {
      const keyListeners = this.listeners.get(key)
      if (keyListeners) {
        keyListeners.delete(listener)
        if (keyListeners.size === 0) {
          this.listeners.delete(key)
        }
      }
    }
  }
}

export const storageEvents = new StorageEventEmitter()

// Hook for listening to storage events
export function useStorageEvent<T>(key: string, callback: (data: T) => void) {
  useEffect(() => {
    return storageEvents.on(key, callback)
  }, [key, callback])
}

// Utility functions
export const storageUtils = {
  // Check if localStorage is available
  isAvailable: (): boolean => {
    try {
      if (typeof window === 'undefined') return false
      const test = '__localStorage_test__'
      localStorage.setItem(test, test)
      localStorage.removeItem(test)
      return true
    } catch {
      return false
    }
  },

  // Get storage usage
  getUsage: (): { used: number; total: number; percentage: number } => {
    if (typeof window === 'undefined') {
      return { used: 0, total: 0, percentage: 0 }
    }

    let used = 0
    for (const key in localStorage) {
      if (localStorage.hasOwnProperty(key)) {
        used += localStorage[key].length + key.length
      }
    }

    const total = 5 * 1024 * 1024 // 5MB typical limit
    const percentage = (used / total) * 100

    return { used, total, percentage }
  },

  // Clear all Hannisol data
  clearAll: (): void => {
    if (typeof window === 'undefined') return

    const keys = Object.keys(localStorage).filter(key => 
      key.startsWith('hannisol_')
    )
    
    keys.forEach(key => localStorage.removeItem(key))
  }
}