import { useState, useEffect, useCallback } from 'react'
import { isValidSolanaAddress } from '@/lib/utils'
import { trackUserFlow } from '@/components/analytics/google-analytics'

interface Transaction {
  signature: string
  slot: number
  blockTime: number
  fee: number
  status: 'success' | 'failed'
  type: 'transfer' | 'receive' | 'stake' | 'unstake' | 'swap' | 'nft' | 'unknown'
  amount?: number
  token?: string
  from?: string
  to?: string
  programId?: string
  confirmationStatus?: 'processed' | 'confirmed' | 'finalized'
}

interface TransactionAnalysis {
  totalCount: number
  successCount: number
  failedCount: number
  totalVolume: number
  averageAmount: number
  transactionTypes: Record<string, number>
  recentActivity: Transaction[]
  firstTransaction?: Date
  lastTransaction?: Date
  activityScore: number
}

interface TransactionState {
  transactions: Transaction[]
  analysis: TransactionAnalysis | null
  isLoading: boolean
  error: string | null
  hasMore: boolean
  page: number
}

interface UseTransactionDataOptions {
  limit?: number
  includeAnalysis?: boolean
  autoRefresh?: boolean
  refreshInterval?: number
}

export function useTransactionData(
  address?: string,
  options: UseTransactionDataOptions = {}
) {
  const {
    limit = 50,
    includeAnalysis = true,
    autoRefresh = false,
    refreshInterval = 30000 // 30 seconds
  } = options

  const [state, setState] = useState<TransactionState>({
    transactions: [],
    analysis: null,
    isLoading: false,
    error: null,
    hasMore: true,
    page: 1
  })

  const fetchTransactions = useCallback(async (
    targetAddress: string,
    page: number = 1,
    append: boolean = false
  ) => {
    if (!targetAddress || !isValidSolanaAddress(targetAddress)) {
      setState(prev => ({
        ...prev,
        error: 'Invalid Solana address'
      }))
      return
    }

    setState(prev => ({
      ...prev,
      isLoading: true,
      error: null
    }))

    try {
      // Track user flow
      trackUserFlow('transaction_analysis', 'fetch_started')

      // In production, this would make actual API calls
      // For demo purposes, we'll simulate transaction data
      await new Promise(resolve => setTimeout(resolve, 1000))

      const mockTransactions: Transaction[] = [
        {
          signature: 'tx_' + Math.random().toString(36).substr(2, 9),
          slot: 150000000 + Math.floor(Math.random() * 1000),
          blockTime: Date.now() - Math.floor(Math.random() * 86400000 * 30), // Last 30 days
          fee: 5000 + Math.floor(Math.random() * 10000),
          status: Math.random() > 0.1 ? 'success' : 'failed',
          type: ['transfer', 'receive', 'stake', 'unstake', 'swap'][Math.floor(Math.random() * 5)] as any,
          amount: Math.random() * 10,
          token: 'SOL',
          confirmationStatus: 'confirmed'
        },
        {
          signature: 'tx_' + Math.random().toString(36).substr(2, 9),
          slot: 150000000 + Math.floor(Math.random() * 1000),
          blockTime: Date.now() - Math.floor(Math.random() * 86400000 * 7), // Last week
          fee: 5000,
          status: 'success',
          type: 'receive',
          amount: 2.5,
          token: 'SOL',
          confirmationStatus: 'finalized'
        },
        {
          signature: 'tx_' + Math.random().toString(36).substr(2, 9),
          slot: 150000000 + Math.floor(Math.random() * 1000),
          blockTime: Date.now() - Math.floor(Math.random() * 86400000 * 14), // Last 2 weeks
          fee: 10000,
          status: 'success',
          type: 'unstake',
          amount: 0.25,
          token: 'SOL',
          confirmationStatus: 'finalized'
        }
      ]

      // Generate analysis if requested
      let analysis: TransactionAnalysis | null = null
      if (includeAnalysis) {
        const allTransactions = append 
          ? [...state.transactions, ...mockTransactions]
          : mockTransactions

        analysis = generateTransactionAnalysis(allTransactions)
      }

      setState(prev => ({
        ...prev,
        transactions: append 
          ? [...prev.transactions, ...mockTransactions]
          : mockTransactions,
        analysis,
        isLoading: false,
        hasMore: mockTransactions.length === limit,
        page: append ? prev.page + 1 : 1
      }))

      trackUserFlow('transaction_analysis', 'fetch_completed')

    } catch (error) {
      console.error('Error fetching transactions:', error)
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: error instanceof Error ? error.message : 'Failed to fetch transactions'
      }))

      trackUserFlow('transaction_analysis', 'fetch_failed')
    }
  }, [limit, includeAnalysis, state.transactions])

  const loadMore = useCallback(() => {
    if (address && state.hasMore && !state.isLoading) {
      fetchTransactions(address, state.page + 1, true)
    }
  }, [address, state.hasMore, state.isLoading, state.page, fetchTransactions])

  const refresh = useCallback(() => {
    if (address) {
      fetchTransactions(address, 1, false)
    }
  }, [address, fetchTransactions])

  const reset = useCallback(() => {
    setState({
      transactions: [],
      analysis: null,
      isLoading: false,
      error: null,
      hasMore: true,
      page: 1
    })
  }, [])

  // Auto-fetch when address changes
  useEffect(() => {
    if (address && isValidSolanaAddress(address)) {
      fetchTransactions(address, 1, false)
    }
  }, [address, fetchTransactions])

  // Auto-refresh functionality
  useEffect(() => {
    if (!autoRefresh || !address) return

    const interval = setInterval(() => {
      if (!state.isLoading) {
        refresh()
      }
    }, refreshInterval)

    return () => clearInterval(interval)
  }, [autoRefresh, address, refresh, refreshInterval, state.isLoading])

  return {
    ...state,
    loadMore,
    refresh,
    reset,
    fetchTransactions
  }
}

// Helper function to generate transaction analysis
function generateTransactionAnalysis(transactions: Transaction[]): TransactionAnalysis {
  const successfulTxs = transactions.filter(tx => tx.status === 'success')
  const failedTxs = transactions.filter(tx => tx.status === 'failed')
  
  const totalVolume = successfulTxs.reduce((sum, tx) => sum + (tx.amount || 0), 0)
  const averageAmount = successfulTxs.length > 0 ? totalVolume / successfulTxs.length : 0
  
  const transactionTypes = transactions.reduce((acc, tx) => {
    acc[tx.type] = (acc[tx.type] || 0) + 1
    return acc
  }, {} as Record<string, number>)

  const sortedTxs = transactions.sort((a, b) => b.blockTime - a.blockTime)
  const recentActivity = sortedTxs.slice(0, 10)

  const firstTransaction = transactions.length > 0 
    ? new Date(Math.min(...transactions.map(tx => tx.blockTime)))
    : undefined

  const lastTransaction = transactions.length > 0
    ? new Date(Math.max(...transactions.map(tx => tx.blockTime)))
    : undefined

  // Calculate activity score based on transaction frequency and recency
  const now = Date.now()
  const lastWeek = now - (7 * 24 * 60 * 60 * 1000)
  const recentTxCount = transactions.filter(tx => tx.blockTime > lastWeek).length
  const activityScore = Math.min(100, recentTxCount * 10) // 0-100 scale

  return {
    totalCount: transactions.length,
    successCount: successfulTxs.length,
    failedCount: failedTxs.length,
    totalVolume,
    averageAmount,
    transactionTypes,
    recentActivity,
    firstTransaction,
    lastTransaction,
    activityScore
  }
}

// Hook for real-time transaction monitoring
export function useTransactionMonitor(address?: string) {
  const [newTransactions, setNewTransactions] = useState<Transaction[]>([])
  const [isMonitoring, setIsMonitoring] = useState(false)

  const startMonitoring = useCallback(() => {
    if (!address || !isValidSolanaAddress(address)) return

    setIsMonitoring(true)
    
    // In production, this would set up WebSocket connections
    // For demo, we'll simulate new transactions periodically
    const interval = setInterval(() => {
      if (Math.random() > 0.7) { // 30% chance of new transaction
        const newTx: Transaction = {
          signature: 'tx_' + Math.random().toString(36).substr(2, 9),
          slot: 150000000 + Math.floor(Math.random() * 1000),
          blockTime: Date.now(),
          fee: 5000,
          status: 'success',
          type: 'receive',
          amount: Math.random() * 5,
          token: 'SOL',
          confirmationStatus: 'processed'
        }

        setNewTransactions(prev => [newTx, ...prev.slice(0, 4)]) // Keep last 5
      }
    }, 10000) // Check every 10 seconds

    return () => {
      clearInterval(interval)
      setIsMonitoring(false)
    }
  }, [address])

  const stopMonitoring = useCallback(() => {
    setIsMonitoring(false)
    setNewTransactions([])
  }, [])

  return {
    newTransactions,
    isMonitoring,
    startMonitoring,
    stopMonitoring
  }
}

// Hook for transaction filtering and sorting
export function useTransactionFilters() {
  const [filters, setFilters] = useState({
    type: 'all',
    status: 'all',
    dateRange: 'all',
    minAmount: 0,
    maxAmount: Infinity
  })

  const [sortBy, setSortBy] = useState<'date' | 'amount' | 'type'>('date')
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc')

  const filterTransactions = useCallback((transactions: Transaction[]) => {
    return transactions
      .filter(tx => {
        if (filters.type !== 'all' && tx.type !== filters.type) return false
        if (filters.status !== 'all' && tx.status !== filters.status) return false
        if (tx.amount !== undefined) {
          if (tx.amount < filters.minAmount || tx.amount > filters.maxAmount) return false
        }
        
        // Date range filtering
        if (filters.dateRange !== 'all') {
          const now = Date.now()
          const txDate = tx.blockTime
          
          switch (filters.dateRange) {
            case '24h':
              if (now - txDate > 24 * 60 * 60 * 1000) return false
              break
            case '7d':
              if (now - txDate > 7 * 24 * 60 * 60 * 1000) return false
              break
            case '30d':
              if (now - txDate > 30 * 24 * 60 * 60 * 1000) return false
              break
          }
        }
        
        return true
      })
      .sort((a, b) => {
        let aValue: any, bValue: any
        
        switch (sortBy) {
          case 'date':
            aValue = a.blockTime
            bValue = b.blockTime
            break
          case 'amount':
            aValue = a.amount || 0
            bValue = b.amount || 0
            break
          case 'type':
            aValue = a.type
            bValue = b.type
            break
        }
        
        if (sortOrder === 'asc') {
          return aValue > bValue ? 1 : -1
        } else {
          return aValue < bValue ? 1 : -1
        }
      })
  }, [filters, sortBy, sortOrder])

  return {
    filters,
    setFilters,
    sortBy,
    setSortBy,
    sortOrder,
    setSortOrder,
    filterTransactions
  }
}