import { Metadata } from 'next'
import { FileText, AlertTriangle, Scale, Clock } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'

export const metadata: Metadata = {
  title: 'Terms of Service - Hannisol Legal Agreement',
  description: 'Terms of Service and legal agreement for using Hannisol Solana address checker platform and services.',
  keywords: ['terms of service', 'legal agreement', 'hannisol terms', 'user agreement'],
}

export default function TermsPage() {
  const lastUpdated = 'June 1, 2025'
  const effectiveDate = 'June 1, 2025'

  const sections = [
    {
      id: 'acceptance',
      title: '1. Acceptance of Terms',
      content: (
        <div className="space-y-4">
          <p className="text-gray-600">
            By accessing or using Hannisol's website and services, you agree to be bound 
            by these Terms of Service ("Terms"). If you do not agree to these Terms, 
            please do not use our services.
          </p>
          <p className="text-gray-600">
            These Terms constitute a legally binding agreement between you and Hannisol 
            regarding your use of our Solana address analysis platform.
          </p>
        </div>
      )
    },
    {
      id: 'services',
      title: '2. Description of Services',
      content: (
        <div className="space-y-4">
          <p className="text-gray-600">
            Hannisol provides professional Solana blockchain address analysis services, including:
          </p>
          <ul className="space-y-2 text-gray-600 ml-4">
            <li>• Address validation and format verification</li>
            <li>• Balance and token holdings analysis</li>
            <li>• Security assessment and risk analysis</li>
            <li>• Transaction history analysis</li>
            <li>• Community sentiment analysis</li>
            <li>• API access for developers</li>
          </ul>
          <p className="text-gray-600">
            Our services analyze publicly available blockchain data and provide 
            analytical insights for informational purposes only.
          </p>
        </div>
      )
    },
    {
      id: 'user-obligations',
      title: '3. User Obligations',
      content: (
        <div className="space-y-4">
          <h4 className="font-semibold text-gray-900">Acceptable Use</h4>
          <p className="text-gray-600">You agree to use our services only for lawful purposes and in accordance with these Terms. You must not:</p>
          <ul className="space-y-2 text-gray-600 ml-4">
            <li>• Use our services for illegal activities or to facilitate illegal activities</li>
            <li>• Attempt to gain unauthorized access to our systems or data</li>
            <li>• Interfere with or disrupt our services or servers</li>
            <li>• Use automated tools to scrape or harvest data beyond rate limits</li>
            <li>• Misrepresent your identity or provide false information</li>
            <li>• Violate any applicable laws or regulations</li>
          </ul>

          <h4 className="font-semibold text-gray-900">API Usage</h4>
          <p className="text-gray-600">
            If using our API, you must comply with rate limits, authentication requirements, 
            and usage guidelines as specified in our API documentation.
          </p>
        </div>
      )
    },
    {
      id: 'disclaimers',
      title: '4. Disclaimers and Limitations',
      content: (
        <div className="space-y-4">
          <Alert variant="warning">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              <strong>Important:</strong> Our services are provided for informational purposes only 
              and do not constitute financial, investment, or legal advice.
            </AlertDescription>
          </Alert>

          <h4 className="font-semibold text-gray-900">No Financial Advice</h4>
          <p className="text-gray-600">
            Hannisol provides analytical tools and information about blockchain addresses. 
            We do not provide financial, investment, tax, or legal advice. Any decisions 
            you make based on our analysis are solely your responsibility.
          </p>

          <h4 className="font-semibold text-gray-900">Data Accuracy</h4>
          <p className="text-gray-600">
            While we strive for accuracy, we cannot guarantee that all information 
            provided is complete, accurate, or up-to-date. Blockchain data may be 
            subject to network delays or inconsistencies.
          </p>

          <h4 className="font-semibold text-gray-900">Service Availability</h4>
          <p className="text-gray-600">
            We aim for high availability but cannot guarantee uninterrupted service. 
            We may suspend or discontinue services for maintenance, updates, or other reasons.
          </p>
        </div>
      )
    },
    {
      id: 'liability',
      title: '5. Limitation of Liability',
      content: (
        <div className="space-y-4">
          <p className="text-gray-600">
            TO THE MAXIMUM EXTENT PERMITTED BY LAW, HANNISOL SHALL NOT BE LIABLE FOR:
          </p>
          <ul className="space-y-2 text-gray-600 ml-4">
            <li>• Any indirect, incidental, special, or consequential damages</li>
            <li>• Loss of profits, data, or business opportunities</li>
            <li>• Any damages resulting from use of our services or reliance on our analysis</li>
            <li>• Any damages caused by errors, omissions, or interruptions in service</li>
          </ul>
          <p className="text-gray-600">
            Our total liability to you for any claims arising from these Terms or 
            your use of our services shall not exceed the amount you paid us in the 
            12 months preceding the claim, or $100, whichever is greater.
          </p>
        </div>
      )
    },
    {
      id: 'intellectual-property',
      title: '6. Intellectual Property',
      content: (
        <div className="space-y-4">
          <h4 className="font-semibold text-gray-900">Our Rights</h4>
          <p className="text-gray-600">
            All content, features, and functionality of our services, including but not 
            limited to text, graphics, logos, software, and design, are owned by Hannisol 
            and protected by copyright, trademark, and other intellectual property laws.
          </p>

          <h4 className="font-semibold text-gray-900">Limited License</h4>
          <p className="text-gray-600">
            We grant you a limited, non-exclusive, non-transferable license to access 
            and use our services for their intended purpose, subject to these Terms.
          </p>

          <h4 className="font-semibold text-gray-900">Restrictions</h4>
          <p className="text-gray-600">
            You may not copy, modify, distribute, sell, or lease any part of our services 
            or included software, nor may you reverse engineer or attempt to extract 
            the source code of that software.
          </p>
        </div>
      )
    },
    {
      id: 'privacy',
      title: '7. Privacy',
      content: (
        <div className="space-y-4">
          <p className="text-gray-600">
            Your privacy is important to us. Our collection and use of personal 
            information is governed by our Privacy Policy, which is incorporated 
            into these Terms by reference.
          </p>
          <p className="text-gray-600">
            By using our services, you consent to the collection and use of your 
            information as described in our Privacy Policy.
          </p>
        </div>
      )
    },
    {
      id: 'termination',
      title: '8. Termination',
      content: (
        <div className="space-y-4">
          <p className="text-gray-600">
            We may terminate or suspend your access to our services immediately, 
            without prior notice or liability, for any reason, including if you 
            breach these Terms.
          </p>
          <p className="text-gray-600">
            You may discontinue using our services at any time. Upon termination, 
            your right to use our services will cease immediately.
          </p>
          <p className="text-gray-600">
            Provisions that by their nature should survive termination shall survive, 
            including ownership provisions, warranty disclaimers, and limitations of liability.
          </p>
        </div>
      )
    },
    {
      id: 'modifications',
      title: '9. Modifications to Terms',
      content: (
        <div className="space-y-4">
          <p className="text-gray-600">
            We reserve the right to modify these Terms at any time. We will notify 
            users of material changes by posting the updated Terms on our website 
            and updating the "Last Modified" date.
          </p>
          <p className="text-gray-600">
            Your continued use of our services after such modifications constitutes 
            acceptance of the updated Terms. If you do not agree to the modified Terms, 
            you should discontinue use of our services.
          </p>
        </div>
      )
    },
    {
      id: 'governing-law',
      title: '10. Governing Law and Jurisdiction',
      content: (
        <div className="space-y-4">
          <p className="text-gray-600">
            These Terms shall be governed by and construed in accordance with the laws 
            of [Jurisdiction], without regard to its conflict of law provisions.
          </p>
          <p className="text-gray-600">
            Any disputes arising from these Terms or your use of our services shall be 
            resolved through binding arbitration in accordance with the rules of [Arbitration Organization].
          </p>
        </div>
      )
    },
    {
      id: 'contact',
      title: '11. Contact Information',
      content: (
        <div className="space-y-4">
          <p className="text-gray-600">
            If you have any questions about these Terms, please contact us:
          </p>
          <div className="space-y-2 text-gray-600">
            <p>
              <strong>Email:</strong>{' '}
              <a href="mailto:legal@hannisol.com" className="text-blue-600 hover:underline">
                legal@hannisol.com
              </a>
            </p>
            <p>
              <strong>Support:</strong>{' '}
              <a href="mailto:support@hannisol.com" className="text-blue-600 hover:underline">
                support@hannisol.com
              </a>
            </p>
            <p>
              <strong>Website:</strong>{' '}
              <a href="https://hannisol.com" className="text-blue-600 hover:underline">
                https://hannisol.com
              </a>
            </p>
          </div>
        </div>
      )
    }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-6 py-12">
          <div className="text-center">
            <div className="flex items-center justify-center mb-4">
              <Scale className="w-8 h-8 text-blue-600" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Terms of Service
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Legal agreement governing your use of Hannisol's Solana address analysis platform.
            </p>
            <div className="flex items-center justify-center mt-6 space-x-6 text-sm text-gray-500">
              <div className="flex items-center">
                <Clock className="w-4 h-4 mr-2" />
                Last updated: {lastUpdated}
              </div>
              <div className="flex items-center">
                <FileText className="w-4 h-4 mr-2" />
                Effective: {effectiveDate}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-12">
        {/* Important Notice */}
        <Alert variant="info" className="mb-8">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            <strong>Please read carefully:</strong> These Terms of Service constitute a legally binding 
            agreement. By using Hannisol, you agree to be bound by these terms.
          </AlertDescription>
        </Alert>

        {/* Terms Sections */}
        <div className="space-y-8">
          {sections.map((section) => (
            <Card key={section.id} className="address-card">
              <CardHeader>
                <CardTitle className="text-xl">{section.title}</CardTitle>
              </CardHeader>
              <CardContent>
                {section.content}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Agreement Acknowledgment */}
        <Card className="address-card mt-12 bg-blue-50 border-blue-200">
          <CardContent className="p-8">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-blue-900 mb-4">
                Agreement Acknowledgment
              </h2>
              <p className="text-blue-800 mb-6">
                By continuing to use Hannisol, you acknowledge that you have read, 
                understood, and agree to be bound by these Terms of Service.
              </p>
              <div className="text-sm text-blue-700">
                <p className="mb-2">
                  <strong>Version:</strong> 1.0
                </p>
                <p className="mb-2">
                  <strong>Effective Date:</strong> {effectiveDate}
                </p>
                <p>
                  <strong>Governing Law:</strong> [Your Jurisdiction]
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Download Terms */}
        <div className="text-center mt-8">
          <p className="text-gray-600 mb-4">
            For your records, you may download a copy of these Terms of Service.
          </p>
          <button className="text-blue-600 hover:underline font-medium">
            Download Terms (PDF)
          </button>
        </div>
      </div>
    </div>
  )
}