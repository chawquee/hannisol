'use client'

import { useEffect } from 'react'
import { AlertTriangle, RefreshCw, Home } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

interface ErrorProps {
  error: Error & { digest?: string }
  reset: () => void
}

export default function Error({ error, reset }: ErrorProps) {
  useEffect(() => {
    // Log the error to an error reporting service
    console.error('Application error:', error)
  }, [error])

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="max-w-md w-full">
        <CardHeader className="text-center">
          {/* Hannisol Logo */}
          <div className="hannisol-logo mx-auto mb-4">
            <div className="hannisol-logo-h">H</div>
            <div className="hannisol-logo-accent-1"></div>
            <div className="hannisol-logo-accent-2"></div>
            <div className="hannisol-logo-accent-3"></div>
          </div>
          
          <div className="flex items-center justify-center mb-4">
            <AlertTriangle className="w-8 h-8 text-red-500" />
          </div>
          
          <CardTitle className="text-xl font-bold text-gray-900">
            Something went wrong
          </CardTitle>
        </CardHeader>
        
        <CardContent className="text-center space-y-4">
          <p className="text-gray-600">
            We apologize for the inconvenience. An unexpected error occurred while processing your request.
          </p>
          
          {/* Error Details (Development only) */}
          {process.env.NODE_ENV === 'development' && (
            <div className="p-3 bg-red-50 rounded-lg border border-red-200 text-left">
              <p className="text-sm font-medium text-red-800 mb-1">Error Details:</p>
              <p className="text-xs text-red-700 font-mono break-all">
                {error.message}
              </p>
              {error.digest && (
                <p className="text-xs text-red-600 mt-1">
                  Error ID: {error.digest}
                </p>
              )}
            </div>
          )}
          
          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 pt-4">
            <Button 
              onClick={reset}
              variant="default"
              className="flex-1 flex items-center space-x-2"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Try Again</span>
            </Button>
            
            <Button 
              onClick={() => window.location.href = '/'}
              variant="outline"
              className="flex-1 flex items-center space-x-2"
            >
              <Home className="w-4 h-4" />
              <span>Go Home</span>
            </Button>
          </div>
          
          {/* Help Text */}
          <div className="pt-4 border-t border-gray-200">
            <p className="text-sm text-gray-500">
              If this problem persists, please{' '}
              <a 
                href="mailto:support@hannisol.com" 
                className="text-blue-600 hover:underline"
              >
                contact our support team
              </a>
            </p>
          </div>
          
          {/* Brand Slogan */}
          <div className="pt-4">
            <p className="hannisol-slogan text-xs text-gray-600">
              "Hannisol's Insight, Navigating Crypto Like Hannibal Crossed the Alps."
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}