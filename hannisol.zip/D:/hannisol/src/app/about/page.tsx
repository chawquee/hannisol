import { Metadata } from 'next'
import { Shield, Target, Users, Zap, Award, TrendingUp } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'

export const metadata: Metadata = {
  title: 'About Hannisol - Professional Solana Address Analysis',
  description: 'Learn about Hannisol\'s mission to provide professional Solana address validation and security analysis tools for the crypto community.',
  keywords: ['about hannisol', 'solana security', 'address validation', 'crypto analysis', 'blockchain tools'],
}

export default function AboutPage() {
  const features = [
    {
      icon: <Shield className="w-6 h-6 text-green-600" />,
      title: 'Advanced Security Analysis',
      description: 'Multi-layered security assessment using machine learning algorithms and blockchain pattern recognition.'
    },
    {
      icon: <Target className="w-6 h-6 text-blue-600" />,
      title: 'Precision Validation',
      description: 'Industry-leading address validation with 99.9% accuracy and comprehensive format verification.'
    },
    {
      icon: <Users className="w-6 h-6 text-purple-600" />,
      title: 'Community Intelligence',
      description: 'Real-time community sentiment analysis and social media monitoring for informed decisions.'
    },
    {
      icon: <Zap className="w-6 h-6 text-yellow-600" />,
      title: 'Lightning Fast',
      description: 'Sub-second response times with optimized RPC connections and intelligent caching.'
    }
  ]

  const stats = [
    { label: 'Addresses Analyzed', value: '50K+', icon: <Target className="w-5 h-5" /> },
    { label: 'Security Checks', value: '1M+', icon: <Shield className="w-5 h-5" /> },
    { label: 'Active Users', value: '5K+', icon: <Users className="w-5 h-5" /> },
    { label: 'Uptime', value: '99.9%', icon: <TrendingUp className="w-5 h-5" /> }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-6 py-16">
          <div className="text-center">
            {/* Logo */}
            <div className="hannisol-logo mx-auto mb-6">
              <div className="hannisol-logo-h">H</div>
              <div className="hannisol-logo-accent-1"></div>
              <div className="hannisol-logo-accent-2"></div>
              <div className="hannisol-logo-accent-3"></div>
            </div>
            
            <h1 className="hannisol-logo-text text-4xl mb-4">HANNISOL</h1>
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Professional Solana Address Analysis
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Named after the legendary strategist Hannibal, Hannisol brings the same tactical 
              precision to cryptocurrency analysis. We provide professional-grade tools for 
              Solana address validation, security assessment, and risk analysis.
            </p>
          </div>
        </div>
      </div>

      {/* Mission Section */}
      <div className="max-w-4xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Mission</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            To democratize professional-grade blockchain analysis tools, making crypto safer 
            and more accessible for everyone.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {features.map((feature, index) => (
            <Card key={index} className="address-card">
              <CardHeader>
                <div className="flex items-center space-x-3">
                  {feature.icon}
                  <CardTitle className="text-xl">{feature.title}</CardTitle>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600">{feature.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Stats Section */}
        <div className="bg-white rounded-lg p-8 shadow-sm border mb-16">
          <h3 className="text-2xl font-bold text-center text-gray-900 mb-8">
            Trusted by the Community
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="flex items-center justify-center mb-2">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    {stat.icon}
                  </div>
                </div>
                <div className="text-2xl font-bold text-gray-900 mb-1">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Story Section */}
        <Card className="address-card mb-16">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center space-x-2">
              <Award className="w-6 h-6 text-yellow-600" />
              <span>The Hannibal Strategy</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="prose prose-gray max-w-none">
            <p className="text-gray-600 leading-relaxed mb-4">
              Just as Hannibal crossed the Alps with strategic precision and innovative tactics, 
              Hannisol navigates the complex landscape of cryptocurrency with advanced analytics 
              and security insights.
            </p>
            <p className="text-gray-600 leading-relaxed mb-4">
              Our platform was born from the need for reliable, professional-grade tools in the 
              rapidly evolving Solana ecosystem. We combine cutting-edge technology with 
              time-tested security principles to deliver unparalleled address analysis.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Every feature is designed with the user in mind - from the instant validation 
              that saves time, to the comprehensive risk assessment that protects investments.
            </p>
          </CardContent>
        </Card>

        {/* Technology Stack */}
        <Card className="address-card mb-16">
          <CardHeader>
            <CardTitle className="text-2xl">Technology & Security</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-3">Infrastructure</h4>
                <div className="space-y-2">
                  <Badge variant="outline">Next.js 14</Badge>
                  <Badge variant="outline">TypeScript</Badge>
                  <Badge variant="outline">Solana Web3.js</Badge>
                  <Badge variant="outline">Real-time APIs</Badge>
                </div>
              </div>
              <div>
                <h4 className="text-lg font-semibold text-gray-900 mb-3">Security</h4>
                <div className="space-y-2">
                  <Badge variant="outline">End-to-end Encryption</Badge>
                  <Badge variant="outline">Rate Limiting</Badge>
                  <Badge variant="outline">Input Validation</Badge>
                  <Badge variant="outline">Privacy First</Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Contact Section */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Get in Touch</h2>
          <p className="text-lg text-gray-600 mb-8">
            Have questions or feedback? We'd love to hear from you.
          </p>
          <div className="flex justify-center space-x-6">
            <a 
              href="mailto:contact@hannisol.com"
              className="text-blue-600 hover:underline font-medium"
            >
              contact@hannisol.com
            </a>
            <span className="text-gray-300">•</span>
            <a 
              href="/docs"
              className="text-blue-600 hover:underline font-medium"
            >
              Documentation
            </a>
            <span className="text-gray-300">•</span>
            <a 
              href="/support"
              className="text-blue-600 hover:underline font-medium"
            >
              Support Center
            </a>
          </div>
        </div>

        {/* Brand Slogan */}
        <div className="text-center mt-16 pt-8 border-t border-gray-200">
          <p className="hannisol-slogan text-xl text-gray-700">
            "Hannisol's Insight, Navigating Crypto Like Hannibal Crossed the Alps."
          </p>
        </div>
      </div>
    </div>
  )
}