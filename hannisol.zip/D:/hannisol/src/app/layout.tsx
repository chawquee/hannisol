import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import { GoogleAnalytics } from '@/components/analytics/google-analytics'
import { cn } from '@/lib/utils'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: {
    default: 'Hannisol - Solana Address Checker | Professional Blockchain Analysis',
    template: '%s | Hannisol - Solana Address Checker'
  },
  description: 'Professional Solana address validation and analysis tool with real-time balance tracking, security assessment, risk analysis, and community insights. Navigate crypto like Hannibal crossed the Alps.',
  keywords: [
    'Solana address checker',
    'Solana address validator',
    'crypto address analysis',
    'blockchain security',
    'Solana wallet checker',
    'crypto risk assessment',
    'Hannisol',
    'Solana analytics',
    'DeFi security',
    'smart contract analysis'
  ],
  authors: [{ name: 'Hannisol Team' }],
  creator: 'Hannisol',
  publisher: 'Hannisol',
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-video-preview': -1,
      'max-image-preview': 'large',
      'max-snippet': -1,
    },
  },
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: process.env.NEXT_PUBLIC_SITE_URL || 'https://hannisol.com',
    siteName: 'Hannisol - Solana Address Checker',
    title: 'Hannisol - Professional Solana Address Analysis',
    description: 'Professional Solana address validation and analysis tool with comprehensive security assessment and risk analysis.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Hannisol - Solana Address Checker',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Hannisol - Solana Address Checker',
    description: 'Professional Solana address validation and analysis tool',
    images: ['/og-image.png'],
    creator: '@hannisol',
  },
  verification: {
    google: process.env.GOOGLE_VERIFICATION_ID,
  },
  alternates: {
    canonical: process.env.NEXT_PUBLIC_SITE_URL || 'https://hannisol.com',
  },
  category: 'technology',
  classification: 'Business',
  referrer: 'origin-when-cross-origin',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'https://hannisol.com'),
  other: {
    'application-name': 'Hannisol',
    'apple-mobile-web-app-title': 'Hannisol',
    'msapplication-TileColor': '#f59e0b',
    'theme-color': '#f59e0b',
  },
}

interface RootLayoutProps {
  children: React.ReactNode
}

export default function RootLayout({ children }: RootLayoutProps) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        {/* Preconnect to external domains for performance */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link rel="preconnect" href="https://www.google-analytics.com" />
        <link rel="preconnect" href="https://www.googletagmanager.com" />
        
        {/* Favicon and App Icons */}
        <link rel="icon" href="/favicon.ico" sizes="any" />
        <link rel="icon" href="/icon.svg" type="image/svg+xml" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/site.webmanifest" />
        
        {/* PWA Meta Tags */}
        <meta name="application-name" content="Hannisol" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="apple-mobile-web-app-status-bar-style" content="default" />
        <meta name="apple-mobile-web-app-title" content="Hannisol" />
        <meta name="format-detection" content="telephone=no" />
        <meta name="mobile-web-app-capable" content="yes" />
        <meta name="msapplication-config" content="/browserconfig.xml" />
        <meta name="msapplication-TileColor" content="#f59e0b" />
        <meta name="msapplication-tap-highlight" content="no" />
        <meta name="theme-color" content="#f59e0b" />
        
        {/* Performance Hints */}
        <link rel="dns-prefetch" href="//fonts.googleapis.com" />
        <link rel="dns-prefetch" href="//www.google-analytics.com" />
        <link rel="dns-prefetch" href="//pagead2.googlesyndication.com" />
        
        {/* Schema.org structured data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              "@context": "https://schema.org",
              "@type": "WebApplication",
              "name": "Hannisol",
              "description": "Professional Solana address validation and analysis tool",
              "url": process.env.NEXT_PUBLIC_SITE_URL || 'https://hannisol.com',
              "applicationCategory": "FinanceApplication",
              "operatingSystem": "All",
              "offers": {
                "@type": "Offer",
                "price": "0",
                "priceCurrency": "USD"
              },
              "creator": {
                "@type": "Organization",
                "name": "Hannisol",
                "url": process.env.NEXT_PUBLIC_SITE_URL || 'https://hannisol.com'
              }
            }),
          }}
        />
      </head>
      <body className={cn(
        "min-h-screen bg-background font-sans antialiased",
        inter.className
      )}>
        {/* Skip to content link for accessibility */}
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:top-4 focus:left-4 bg-primary text-primary-foreground px-4 py-2 rounded-md z-50"
        >
          Skip to main content
        </a>

        {/* Site Layout */}
        <div className="relative flex min-h-screen flex-col">
          <Header />
          
          <main id="main-content" className="flex-1">
            {children}
          </main>
          
          <Footer />
        </div>

        {/* Analytics */}
        <GoogleAnalytics />

        {/* Service Worker Registration */}
        <script
          dangerouslySetInnerHTML={{
            __html: `
              if ('serviceWorker' in navigator) {
                window.addEventListener('load', function() {
                  navigator.serviceWorker.register('/sw.js');
                });
              }
            `,
          }}
        />
      </body>
    </html>
  )
}