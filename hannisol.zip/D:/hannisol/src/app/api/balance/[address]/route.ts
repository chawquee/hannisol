import { NextRequest, NextResponse } from 'next/server'
import { isValidSolanaAddress } from '@/lib/utils'

interface RouteParams {
  params: {
    address: string
  }
}

export async function GET(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { address } = params
    
    if (!address || !isValidSolanaAddress(address)) {
      return NextResponse.json(
        { error: 'Invalid Solana address' },
        { status: 400 }
      )
    }

    // In production, this would make actual RPC calls to Solana
    // For demo purposes, we return mock data
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500))
    
    const balanceData = {
      address,
      timestamp: new Date().toISOString(),
      sol: {
        balance: 1.25,
        lamports: 1250000000,
        usdValue: 127.89
      },
      tokens: [
        {
          mint: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
          symbol: 'USDC',
          name: 'USD Coin',
          balance: '2000000',
          decimals: 6,
          uiAmount: 2.0,
          usdValue: 2.0,
          logo: 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v/logo.png'
        },
        {
          mint: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
          symbol: 'USDT',
          name: 'Tether USD',
          balance: '1500000',
          decimals: 6,
          uiAmount: 1.5,
          usdValue: 1.5,
          logo: 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB/logo.png'
        }
      ],
      nfts: {
        count: 3,
        collections: [
          {
            name: 'Solana Monkey Business',
            count: 1,
            floorPrice: 12.5
          },
          {
            name: 'DeGods',
            count: 2,
            floorPrice: 25.0
          }
        ]
      },
      staking: {
        totalStaked: 5.0,
        activeStake: 4.8,
        rewards: 0.2,
        validators: [
          {
            name: 'Validator 1',
            stake: 2.5,
            apy: 6.8
          },
          {
            name: 'Validator 2', 
            stake: 2.3,
            apy: 7.1
          }
        ]
      },
      totalValue: {
        sol: 1.25,
        tokens: 3.5,
        nfts: 62.5,
        staking: 5.0,
        total: 72.25,
        usd: 7402.45
      },
      priceData: {
        solPrice: 102.31,
        change24h: 2.4,
        lastUpdated: new Date().toISOString()
      }
    }

    // Cache for 5 minutes
    const headers = new Headers()
    headers.set('Cache-Control', 'public, max-age=300, stale-while-revalidate=600')
    headers.set('Access-Control-Allow-Origin', '*')

    return NextResponse.json(balanceData, { headers })

  } catch (error) {
    console.error('Balance fetch error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch balance data' },
      { status: 500 }
    )
  }
}

export async function POST(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { address } = params
    const body = await request.json()
    
    if (!address || !isValidSolanaAddress(address)) {
      return NextResponse.json(
        { error: 'Invalid Solana address' },
        { status: 400 }
      )
    }

    // Handle real-time balance updates via WebSocket or polling
    const options = {
      includeTokens: body.includeTokens ?? true,
      includeNfts: body.includeNfts ?? true,
      includeStaking: body.includeStaking ?? true,
      includePriceData: body.includePriceData ?? true,
      realTime: body.realTime ?? false
    }

    // Subscribe to real-time updates if requested
    if (options.realTime) {
      // In production, this would set up WebSocket connections
      // or register for push notifications
    }

    return NextResponse.json({
      success: true,
      message: 'Balance tracking configured',
      options
    })

  } catch (error) {
    console.error('Balance configuration error:', error)
    return NextResponse.json(
      { error: 'Failed to configure balance tracking' },
      { status: 500 }
    )
  }
}