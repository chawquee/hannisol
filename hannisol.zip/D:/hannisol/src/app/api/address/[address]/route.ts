import { NextRequest, NextResponse } from 'next/server'
import { isValidSolanaAddress } from '@/lib/utils'

interface RouteParams {
  params: {
    address: string
  }
}

export async function GET(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { address } = params
    
    if (!address) {
      return NextResponse.json(
        { error: 'Address parameter is required' },
        { status: 400 }
      )
    }

    // Basic validation
    const isValid = isValidSolanaAddress(address)
    const errors: string[] = []

    // Detailed validation
    if (!isValid) {
      if (address.length < 32) errors.push('Address too short')
      if (address.length > 44) errors.push('Address too long')
      if (!/^[1-9A-HJ-NP-Za-km-z]+$/.test(address)) {
        errors.push('Invalid Base58 characters')
      }
    }

    // For demo purposes, we'll return mock analysis data
    // In production, this would integrate with Solana RPC and other services
    const analysisResult = {
      address,
      timestamp: new Date().toISOString(),
      validation: {
        isValid,
        format: 'Base58',
        length: address.length,
        type: isValid ? 'Wallet Address' : 'Invalid',
        network: 'Solana Mainnet',
        errors
      },
      account: isValid ? {
        executable: false,
        owner: '11111111111111111111111111111112',
        lamports: 1250000000,
        rentEpoch: 18446744073709551615,
        dataSize: 0
      } : null,
      balance: isValid ? {
        sol: 1.25,
        lamports: 1250000000,
        usdValue: 127.89,
        tokens: [
          {
            mint: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
            symbol: 'USDC',
            balance: 2.0,
            usdValue: 2.0
          }
        ],
        nftCount: 3
      } : null,
      risk: isValid ? {
        score: 65,
        level: 'Medium',
        factors: {
          liquidityLocked: false,
          ownershipRenounced: 'partial',
          largeHolders: 'distributed',
          freezeAuthority: 'disabled'
        }
      } : null,
      security: isValid ? {
        flags: [],
        suspiciousActivity: false,
        riskScore: 75,
        overallRating: 'Good'
      } : null
    }

    // Set cache headers for valid addresses
    const headers = new Headers()
    if (isValid) {
      headers.set('Cache-Control', 'public, max-age=300, stale-while-revalidate=600')
    }

    return NextResponse.json(analysisResult, { headers })

  } catch (error) {
    console.error('Address analysis error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(
  request: NextRequest,
  { params }: RouteParams
) {
  try {
    const { address } = params
    const body = await request.json()
    
    // Handle POST requests for more detailed analysis
    const options = {
      includeTransactions: body.includeTransactions ?? true,
      includeTokens: body.includeTokens ?? true,
      includeNfts: body.includeNfts ?? true,
      includeRiskAssessment: body.includeRiskAssessment ?? true,
      transactionLimit: body.transactionLimit ?? 50
    }

    if (!address || !isValidSolanaAddress(address)) {
      return NextResponse.json(
        { error: 'Invalid Solana address' },
        { status: 400 }
      )
    }

    // Enhanced analysis with options
    const enhancedResult = {
      address,
      timestamp: new Date().toISOString(),
      options,
      transactions: options.includeTransactions ? [
        {
          signature: 'example_signature_1',
          type: 'transfer',
          amount: 0.5,
          timestamp: new Date(Date.now() - 86400000).toISOString(),
          status: 'success'
        },
        {
          signature: 'example_signature_2', 
          type: 'receive',
          amount: 0.3,
          timestamp: new Date(Date.now() - 172800000).toISOString(),
          status: 'success'
        }
      ] : [],
      community: {
        socialMetrics: {
          followers: 15200,
          engagement: 4800,
          sentiment: 'positive'
        },
        trendingKeywords: ['Solana', 'Staking', 'DeFi']
      },
      finalGrade: {
        technical: 78,
        security: 82,
        community: 'A',
        overall: 'A-',
        confidence: 92
      }
    }

    return NextResponse.json(enhancedResult)

  } catch (error) {
    console.error('Enhanced analysis error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}