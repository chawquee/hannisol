import { Metadata } from 'next'
import { Book, Code, Key, Shield, Zap, ArrowRight } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { CopyCodeBlock } from '@/components/common/copy-button'

export const metadata: Metadata = {
  title: 'API Documentation - Hannisol Developer Guide',
  description: 'Complete API documentation for Hannisol Solana Address Checker. Learn how to integrate address validation and analysis into your applications.',
  keywords: ['hannisol api', 'solana api', 'address validation api', 'blockchain api', 'developer documentation'],
}

export default function DocsPage() {
  const endpoints = [
    {
      method: 'GET',
      path: '/api/address/{address}',
      description: 'Validate and analyze a Solana address',
      category: 'Address Analysis'
    },
    {
      method: 'GET', 
      path: '/api/balance/{address}',
      description: 'Get SOL and token balances for an address',
      category: 'Balance Lookup'
    },
    {
      method: 'POST',
      path: '/api/address/{address}',
      description: 'Enhanced analysis with custom options',
      category: 'Advanced Analysis'
    }
  ]

  const sdkExamples = {
    javascript: `
// JavaScript/TypeScript SDK
import { HannisolClient } from '@hannisol/sdk'

const client = new HannisolClient({
  apiKey: 'your-api-key'
})

// Validate address
const result = await client.validateAddress('DH2dr...3hxJqG2')
console.log(result.validation.isValid) // true

// Get balance
const balance = await client.getBalance('DH2dr...3hxJqG2')
console.log(\`\${balance.sol} SOL\`) // 1.25 SOL
`,
    python: `
# Python SDK
from hannisol import HannisolClient

client = HannisolClient(api_key='your-api-key')

# Validate address
result = client.validate_address('DH2dr...3hxJqG2')
print(f"Valid: {result.validation.is_valid}")

# Get balance  
balance = client.get_balance('DH2dr...3hxJqG2')
print(f"{balance.sol} SOL")
`,
    curl: `
# cURL Examples

# Validate address
curl -X GET "https://hannisol.com/api/address/DH2dr...3hxJqG2" \\
  -H "Authorization: Bearer your-api-key" \\
  -H "Content-Type: application/json"

# Get balance
curl -X GET "https://hannisol.com/api/balance/DH2dr...3hxJqG2" \\
  -H "Authorization: Bearer your-api-key"
`
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-6 py-12">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              API Documentation
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Integrate Hannisol's professional Solana address analysis into your applications 
              with our comprehensive REST API and SDKs.
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-6 py-12">
        {/* Quick Start */}
        <Card className="address-card mb-12">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center space-x-2">
              <Zap className="w-6 h-6 text-yellow-600" />
              <span>Quick Start</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  1. Get Your API Key
                </h3>
                <p className="text-gray-600 mb-4">
                  Sign up for a free account to get your API key. Free tier includes 
                  1,000 requests per month.
                </p>
                <Button className="mb-6">
                  Get API Key
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>

                <h3 className="text-lg font-semibold text-gray-900 mb-4">
                  2. Make Your First Request
                </h3>
                <p className="text-gray-600 mb-4">
                  Test the API with a simple address validation request.
                </p>
              </div>
              
              <div>
                <CopyCodeBlock 
                  code={`curl -X GET "https://hannisol.com/api/address/DH2dr...3hxJqG2" \\
  -H "Authorization: Bearer your-api-key"`}
                  language="bash"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* API Endpoints */}
        <Card className="address-card mb-12">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center space-x-2">
              <Code className="w-6 h-6 text-blue-600" />
              <span>API Endpoints</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {endpoints.map((endpoint, index) => (
                <div key={index} className="p-4 border rounded-lg">
                  <div className="flex items-center space-x-3 mb-2">
                    <Badge variant={endpoint.method === 'GET' ? 'valid' : 'info'}>
                      {endpoint.method}
                    </Badge>
                    <code className="text-sm font-mono text-gray-900">
                      {endpoint.path}
                    </code>
                  </div>
                  <p className="text-gray-600 text-sm">{endpoint.description}</p>
                  <Badge variant="outline" className="mt-2">
                    {endpoint.category}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* SDK Examples */}
        <Card className="address-card mb-12">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center space-x-2">
              <Book className="w-6 h-6 text-green-600" />
              <span>SDK Examples</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="javascript" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="javascript">JavaScript</TabsTrigger>
                <TabsTrigger value="python">Python</TabsTrigger>
                <TabsTrigger value="curl">cURL</TabsTrigger>
              </TabsList>
              
              <TabsContent value="javascript">
                <CopyCodeBlock 
                  code={sdkExamples.javascript}
                  language="javascript"
                />
              </TabsContent>
              
              <TabsContent value="python">
                <CopyCodeBlock 
                  code={sdkExamples.python}
                  language="python"
                />
              </TabsContent>
              
              <TabsContent value="curl">
                <CopyCodeBlock 
                  code={sdkExamples.curl}
                  language="bash"
                />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Response Examples */}
        <Card className="address-card mb-12">
          <CardHeader>
            <CardTitle className="text-2xl">Response Format</CardTitle>
          </CardHeader>
          <CardContent>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">
              Address Validation Response
            </h3>
            <CopyCodeBlock 
              code={`{
  "address": "DH2dr...3hxJqG2",
  "timestamp": "2025-06-01T12:00:00Z",
  "validation": {
    "isValid": true,
    "format": "Base58",
    "length": 44,
    "type": "Wallet Address",
    "network": "Solana Mainnet",
    "errors": []
  },
  "balance": {
    "sol": 1.25,
    "lamports": 1250000000,
    "usdValue": 127.89,
    "tokens": [...],
    "nftCount": 3
  },
  "security": {
    "riskScore": 75,
    "flags": [],
    "suspiciousActivity": false
  },
  "finalGrade": {
    "technical": 78,
    "security": 82,
    "community": "A",
    "overall": "A-",
    "confidence": 92
  }
}`}
              language="json"
            />
          </CardContent>
        </Card>

        {/* Rate Limits */}
        <Card className="address-card mb-12">
          <CardHeader>
            <CardTitle className="text-2xl flex items-center space-x-2">
              <Shield className="w-6 h-6 text-red-600" />
              <span>Rate Limits & Authentication</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Rate Limits</h3>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                    <span className="font-medium">Free Tier</span>
                    <Badge variant="outline">1,000/month</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                    <span className="font-medium">Pro Tier</span>
                    <Badge variant="outline">100/minute</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                    <span className="font-medium">Enterprise</span>
                    <Badge variant="outline">Custom</Badge>
                  </div>
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Authentication</h3>
                <p className="text-gray-600 mb-4">
                  Include your API key in the Authorization header:
                </p>
                <CopyCodeBlock 
                  code={`Authorization: Bearer your-api-key`}
                  language="http"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Error Handling */}
        <Card className="address-card mb-12">
          <CardHeader>
            <CardTitle className="text-2xl">Error Handling</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">HTTP Status Codes</h3>
                <div className="space-y-2">
                  <div className="flex items-center space-x-3 p-2 bg-green-50 rounded">
                    <Badge variant="valid">200</Badge>
                    <span className="text-sm">Success</span>
                  </div>
                  <div className="flex items-center space-x-3 p-2 bg-yellow-50 rounded">
                    <Badge variant="warning">400</Badge>
                    <span className="text-sm">Bad Request - Invalid address format</span>
                  </div>
                  <div className="flex items-center space-x-3 p-2 bg-red-50 rounded">
                    <Badge variant="error">401</Badge>
                    <span className="text-sm">Unauthorized - Invalid API key</span>
                  </div>
                  <div className="flex items-center space-x-3 p-2 bg-red-50 rounded">
                    <Badge variant="error">429</Badge>
                    <span className="text-sm">Rate Limited - Too many requests</span>
                  </div>
                  <div className="flex items-center space-x-3 p-2 bg-red-50 rounded">
                    <Badge variant="error">500</Badge>
                    <span className="text-sm">Server Error - Contact support</span>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Error Response Format</h3>
                <CopyCodeBlock 
                  code={`{
  "error": "Invalid Solana address format",
  "code": "INVALID_ADDRESS",
  "timestamp": "2025-06-01T12:00:00Z",
  "requestId": "req_abc123"
}`}
                  language="json"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Support */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">
            Need Help?
          </h2>
          <p className="text-lg text-gray-600 mb-8">
            Our support team is here to help you integrate successfully.
          </p>
          <div className="flex justify-center space-x-6">
            <Button variant="outline">
              <Key className="w-4 h-4 mr-2" />
              Get API Key
            </Button>
            <Button>
              Contact Support
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}