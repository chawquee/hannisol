import { Metadata } from 'next'
import { Shield, Eye, Lock, Users, FileText, Clock } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'

export const metadata: Metadata = {
  title: 'Privacy Policy - Hannisol Data Protection & Security',
  description: 'Learn how Hannisol protects your privacy and handles data in our Solana address checker platform. Transparent privacy practices.',
  keywords: ['privacy policy', 'data protection', 'hannisol privacy', 'solana security', 'crypto privacy'],
}

export default function PrivacyPage() {
  const lastUpdated = 'June 1, 2025'

  const sections = [
    {
      id: 'information-collection',
      title: 'Information We Collect',
      icon: <Eye className="w-5 h-5 text-blue-600" />,
      content: (
        <div className="space-y-4">
          <h4 className="font-semibold text-gray-900">Public Blockchain Data</h4>
          <p className="text-gray-600">
            We analyze publicly available Solana blockchain data including addresses, 
            transaction histories, and token balances. This information is already 
            public on the blockchain and not personally identifiable.
          </p>

          <h4 className="font-semibold text-gray-900">Usage Analytics</h4>
          <p className="text-gray-600">
            We collect anonymous usage statistics using Google Analytics to improve 
            our service, including page views, session duration, and feature usage. 
            IP addresses are anonymized.
          </p>

          <h4 className="font-semibold text-gray-900">Technical Information</h4>
          <p className="text-gray-600">
            Basic technical information such as browser type, device type, and 
            operating system to ensure compatibility and optimal performance.
          </p>
        </div>
      )
    },
    {
      id: 'data-usage',
      title: 'How We Use Your Data',
      icon: <Lock className="w-5 h-5 text-green-600" />,
      content: (
        <div className="space-y-4">
          <ul className="space-y-2 text-gray-600">
            <li>• Provide address validation and analysis services</li>
            <li>• Improve service performance and accuracy</li>
            <li>• Generate anonymous usage statistics</li>
            <li>• Ensure platform security and prevent abuse</li>
            <li>• Comply with legal obligations</li>
          </ul>
          
          <p className="text-gray-600 font-medium">
            We never sell, rent, or share your data with third parties for 
            marketing purposes.
          </p>
        </div>
      )
    },
    {
      id: 'data-storage',
      title: 'Data Storage & Security',
      icon: <Shield className="w-5 h-5 text-purple-600" />,
      content: (
        <div className="space-y-4">
          <h4 className="font-semibold text-gray-900">Security Measures</h4>
          <ul className="space-y-2 text-gray-600">
            <li>• End-to-end encryption for all data transmission</li>
            <li>• Secure cloud infrastructure with AWS/Vercel</li>
            <li>• Regular security audits and monitoring</li>
            <li>• Access controls and authentication</li>
            <li>• Data minimization practices</li>
          </ul>

          <h4 className="font-semibold text-gray-900">Data Retention</h4>
          <p className="text-gray-600">
            Analytics data is retained for 26 months. Cached blockchain data 
            is refreshed regularly and not permanently stored.
          </p>
        </div>
      )
    },
    {
      id: 'cookies',
      title: 'Cookies & Tracking',
      icon: <FileText className="w-5 h-5 text-yellow-600" />,
      content: (
        <div className="space-y-4">
          <h4 className="font-semibold text-gray-900">Essential Cookies</h4>
          <p className="text-gray-600">
            Required for basic site functionality, security, and user preferences. 
            These cannot be disabled.
          </p>

          <h4 className="font-semibold text-gray-900">Analytics Cookies</h4>
          <p className="text-gray-600">
            Google Analytics cookies help us understand how users interact with 
            our platform. These are anonymized and can be opted out.
          </p>

          <h4 className="font-semibold text-gray-900">Advertising Cookies</h4>
          <p className="text-gray-600">
            Third-party advertising networks may use cookies to display relevant 
            ads. You can control these through your browser settings.
          </p>
        </div>
      )
    },
    {
      id: 'third-parties',
      title: 'Third-Party Services',
      icon: <Users className="w-5 h-5 text-red-600" />,
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <h4 className="font-semibold text-gray-900">Analytics</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Google Analytics 4</li>
                <li>• Vercel Analytics</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900">Advertising</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Google AdSense</li>
                <li>• Coinzilla</li>
                <li>• A-ADS</li>
                <li>• Media.net</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900">Infrastructure</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Vercel (Hosting)</li>
                <li>• Solana RPC Providers</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold text-gray-900">Communication</h4>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• Email Service Providers</li>
                <li>• Support Systems</li>
              </ul>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'user-rights',
      title: 'Your Rights',
      icon: <Users className="w-5 h-5 text-indigo-600" />,
      content: (
        <div className="space-y-4">
          <p className="text-gray-600">
            Under GDPR and other privacy laws, you have the following rights:
          </p>
          
          <ul className="space-y-2 text-gray-600">
            <li>• <strong>Access:</strong> Request a copy of your data</li>
            <li>• <strong>Rectification:</strong> Correct inaccurate data</li>
            <li>• <strong>Erasure:</strong> Request deletion of your data</li>
            <li>• <strong>Portability:</strong> Transfer your data</li>
            <li>• <strong>Objection:</strong> Object to data processing</li>
            <li>• <strong>Restriction:</strong> Limit data processing</li>
          </ul>

          <p className="text-gray-600">
            To exercise these rights, contact us at{' '}
            <a href="mailto:privacy@hannisol.com" className="text-blue-600 hover:underline">
              privacy@hannisol.com
            </a>
          </p>
        </div>
      )
    }
  ]

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-6 py-12">
          <div className="text-center">
            <div className="flex items-center justify-center mb-4">
              <Shield className="w-8 h-8 text-blue-600" />
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Privacy Policy
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Your privacy is important to us. This policy explains how we collect, 
              use, and protect your information when using Hannisol.
            </p>
            <div className="flex items-center justify-center mt-6 text-sm text-gray-500">
              <Clock className="w-4 h-4 mr-2" />
              Last updated: {lastUpdated}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-6 py-12">
        {/* Privacy Commitment */}
        <Card className="address-card mb-12">
          <CardContent className="p-8">
            <div className="text-center">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                Our Privacy Commitment
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Hannisol is committed to protecting your privacy while providing 
                professional Solana address analysis services. We believe in 
                transparency and user control over personal data.
              </p>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Lock className="w-6 h-6 text-blue-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Data Minimization</h3>
                  <p className="text-sm text-gray-600">
                    We only collect data necessary for our services
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Shield className="w-6 h-6 text-green-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Security First</h3>
                  <p className="text-sm text-gray-600">
                    Enterprise-grade security protects your data
                  </p>
                </div>
                <div className="text-center">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Eye className="w-6 h-6 text-purple-600" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">Transparency</h3>
                  <p className="text-sm text-gray-600">
                    Clear policies about data collection and use
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Privacy Policy Sections */}
        <div className="space-y-8">
          {sections.map((section) => (
            <Card key={section.id} className="address-card">
              <CardHeader>
                <CardTitle className="flex items-center space-x-3">
                  {section.icon}
                  <span>{section.title}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {section.content}
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Contact Information */}
        <Card className="address-card mt-12">
          <CardHeader>
            <CardTitle className="text-xl">Contact Us About Privacy</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-600 mb-4">
              If you have questions about this Privacy Policy or how we handle 
              your data, please contact us:
            </p>
            <div className="space-y-2 text-gray-600">
              <p>
                <strong>Email:</strong>{' '}
                <a href="mailto:privacy@hannisol.com" className="text-blue-600 hover:underline">
                  privacy@hannisol.com
                </a>
              </p>
              <p>
                <strong>Data Protection Officer:</strong>{' '}
                <a href="mailto:dpo@hannisol.com" className="text-blue-600 hover:underline">
                  dpo@hannisol.com
                </a>
              </p>
              <p>
                <strong>Response Time:</strong> We respond to privacy inquiries within 30 days
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Legal Compliance */}
        <div className="mt-12 p-6 bg-blue-50 rounded-lg border border-blue-200">
          <h3 className="text-lg font-semibold text-blue-900 mb-3">
            Legal Compliance
          </h3>
          <p className="text-blue-800 text-sm">
            This Privacy Policy complies with the General Data Protection Regulation (GDPR), 
            California Consumer Privacy Act (CCPA), and other applicable privacy laws. 
            We regularly review and update our practices to ensure continued compliance.
          </p>
        </div>
      </div>
    </div>
  )
}