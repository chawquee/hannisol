export default function Loading() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="text-center">
        {/* Hannisol Logo Animation */}
        <div className="mb-8">
          <div className="hannisol-logo animate-pulse-gold mx-auto">
            <div className="hannisol-logo-h">H</div>
            <div className="hannisol-logo-accent-1"></div>
            <div className="hannisol-logo-accent-2"></div>
            <div className="hannisol-logo-accent-3"></div>
          </div>
          <h1 className="hannisol-logo-text text-2xl mt-4">HANNISOL</h1>
        </div>

        {/* Loading Spinner */}
        <div className="mb-6">
          <div className="inline-flex items-center space-x-2">
            <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
            <span className="text-lg font-medium text-gray-900">Loading...</span>
          </div>
        </div>

        {/* Loading Message */}
        <p className="text-gray-600 max-w-md mx-auto">
          Preparing your professional Solana address analysis tools
        </p>

        {/* Progress Indicators */}
        <div className="mt-8 space-y-2 max-w-xs mx-auto">
          <div className="flex justify-between text-sm text-gray-500">
            <span>Initializing</span>
            <span>⚡</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-1">
            <div className="bg-blue-600 h-1 rounded-full animate-pulse" style={{ width: '75%' }}></div>
          </div>
        </div>
      </div>
    </div>
  )
}