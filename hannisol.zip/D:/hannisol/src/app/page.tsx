"use client"

import React, { useState } from 'react'
import { AddressInput } from '@/components/address-checker/address-input'
import { ValidationResults } from '@/components/address-checker/validation-results'
import { BalanceDisplay } from '@/components/address-checker/balance-display'
import { TransactionAnalysis } from '@/components/address-checker/transaction-analysis'
import { AccountDetails } from '@/components/address-checker/account-details'
import { SecurityAnalysis } from '@/components/address-checker/security-analysis'
import { RiskAssessment } from '@/components/address-checker/risk-assessment'
import { CommunityStats } from '@/components/address-checker/community-stats'
import { FinalAssessment } from '@/components/address-checker/final-assessment'
import { AnalysisSummary } from '@/components/address-checker/analysis-summary'
import { GoogleAdsense } from '@/components/ads/google-adsense'
import { CoinzillaAd } from '@/components/ads/coinzilla-ad'
import { isValidSolanaAddress } from '@/lib/utils'

interface AnalysisState {
  address: string
  isAnalyzing: boolean
  showResults: boolean
  isValid: boolean
}

export default function HomePage() {
  const [analysisState, setAnalysisState] = useState<AnalysisState>({
    address: '',
    isAnalyzing: false,
    showResults: false,
    isValid: false
  })

  const handleAddressCheck = async (address: string) => {
    setAnalysisState({
      address,
      isAnalyzing: true,
      showResults: false,
      isValid: isValidSolanaAddress(address)
    })

    // Simulate API call with realistic delay
    await new Promise(resolve => setTimeout(resolve, 2500))

    setAnalysisState(prev => ({
      ...prev,
      isAnalyzing: false,
      showResults: true
    }))
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-4xl mx-auto px-6 py-8">
          <div className="text-center mb-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Professional Solana Address Analysis
            </h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Comprehensive validation, security assessment, and risk analysis for Solana addresses. 
              Get instant insights into any wallet or smart contract.
            </p>
          </div>

          {/* Main Address Input */}
          <AddressInput 
            onAddressCheck={handleAddressCheck}
            isLoading={analysisState.isAnalyzing}
          />

          {/* Top Banner Ad */}
          <div className="mt-8">
            <GoogleAdsense 
              adSlot="1234567890"
              adFormat="auto"
              adLayout="in-article"
              className="max-w-2xl mx-auto"
            />
          </div>
        </div>
      </div>

      {/* Results Section */}
      {(analysisState.showResults || analysisState.isAnalyzing) && (
        <div className="max-w-4xl mx-auto px-6 py-8">
          <div className="space-y-6">
            {analysisState.isAnalyzing ? (
              // Loading State
              <div className="text-center py-12">
                <div className="inline-flex items-center space-x-3">
                  <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                  <div className="text-lg font-medium text-gray-900">
                    Analyzing address...
                  </div>
                </div>
                <div className="mt-4 text-sm text-gray-600 max-w-md mx-auto">
                  Running comprehensive security checks, validating blockchain data, 
                  and analyzing community sentiment.
                </div>
              </div>
            ) : (
              // Analysis Results
              <>
                {/* Address Validation */}
                <ValidationResults 
                  address={analysisState.address}
                  isValid={analysisState.isValid}
                />

                {/* Ad Banner - Middle */}
                <CoinzillaAd 
                  zoneId="C-123456789"
                  className="max-w-2xl mx-auto"
                />

                {/* Balance & Holdings */}
                <BalanceDisplay />

                {/* Transaction Analysis */}
                <TransactionAnalysis />

                {/* Account Details */}
                <AccountDetails address={analysisState.address} />

                {/* Security Analysis */}
                <SecurityAnalysis />

                {/* Ad Banner - Middle 2 */}
                <div className="flex justify-center">
                  <GoogleAdsense 
                    adSlot="9876543210"
                    adFormat="rectangle"
                    className="max-w-md"
                  />
                </div>

                {/* Risk Assessment */}
                <RiskAssessment />

                {/* Community Stats */}
                <CommunityStats />

                {/* Final Assessment */}
                <FinalAssessment />

                {/* Analysis Summary */}
                <AnalysisSummary address={analysisState.address} />

                {/* Bottom Ad Banner */}
                <div className="pt-6">
                  <CoinzillaAd 
                    zoneId="C-987654321"
                    className="max-w-3xl mx-auto"
                  />
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* Features Section (shown when no results) */}
      {!analysisState.showResults && !analysisState.isAnalyzing && (
        <div className="max-w-6xl mx-auto px-6 py-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Choose Hannisol?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Professional-grade analysis tools trusted by traders, developers, and security researchers
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-white rounded-lg shadow-sm border">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <svg className="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Address Validation</h3>
              <p className="text-gray-600">
                Instant validation of Solana address format, structure, and blockchain presence
              </p>
            </div>

            <div className="text-center p-6 bg-white rounded-lg shadow-sm border">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Security Analysis</h3>
              <p className="text-gray-600">
                Comprehensive security assessment with risk scoring and threat detection
              </p>
            </div>

            <div className="text-center p-6 bg-white rounded-lg shadow-sm border">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Community Insights</h3>
              <p className="text-gray-600">
                Real-time community sentiment analysis and social media monitoring
              </p>
            </div>
          </div>

          {/* Bottom Features Ad */}
          <div className="mt-12 flex justify-center">
            <GoogleAdsense 
              adSlot="5555555555"
              adFormat="auto"
              adLayout="in-article"
              className="max-w-2xl"
            />
          </div>
        </div>
      )}
    </div>
  )
}