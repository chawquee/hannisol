import Link from 'next/link'
import { Search, Home, ArrowLeft } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'

export default function NotFound() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <Card className="max-w-lg w-full">
        <CardContent className="p-8 text-center">
          {/* Hannisol Logo */}
          <div className="hannisol-logo mx-auto mb-6">
            <div className="hannisol-logo-h">H</div>
            <div className="hannisol-logo-accent-1"></div>
            <div className="hannisol-logo-accent-2"></div>
            <div className="hannisol-logo-accent-3"></div>
          </div>
          
          {/* 404 Message */}
          <div className="mb-6">
            <h1 className="text-6xl font-bold text-gray-400 mb-2">404</h1>
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Page Not Found</h2>
            <p className="text-gray-600 mb-6">
              The page you're looking for doesn't exist or has been moved to a different location.
            </p>
          </div>
          
          {/* Search Suggestion */}
          <div className="mb-8 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center space-x-2 mb-2">
              <Search className="w-5 h-5 text-blue-600" />
              <span className="font-medium text-blue-800">Looking for address validation?</span>
            </div>
            <p className="text-sm text-blue-700">
              Try our main address checker to validate and analyze any Solana address.
            </p>
          </div>
          
          {/* Navigation Options */}
          <div className="space-y-3">
            <Link href="/" className="block">
              <Button className="w-full flex items-center justify-center space-x-2">
                <Home className="w-4 h-4" />
                <span>Go to Address Checker</span>
              </Button>
            </Link>
            
            <Button 
              variant="outline" 
              onClick={() => window.history.back()}
              className="w-full flex items-center justify-center space-x-2"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Go Back</span>
            </Button>
          </div>
          
          {/* Popular Links */}
          <div className="mt-8 pt-6 border-t border-gray-200">
            <p className="text-sm font-medium text-gray-700 mb-3">Popular Pages:</p>
            <div className="flex flex-wrap gap-2 justify-center">
              <Link href="/about" className="text-sm text-blue-600 hover:underline">
                About
              </Link>
              <span className="text-gray-300">•</span>
              <Link href="/docs" className="text-sm text-blue-600 hover:underline">
                Documentation
              </Link>
              <span className="text-gray-300">•</span>
              <Link href="/api" className="text-sm text-blue-600 hover:underline">
                API
              </Link>
              <span className="text-gray-300">•</span>
              <Link href="/support" className="text-sm text-blue-600 hover:underline">
                Support
              </Link>
            </div>
          </div>
          
          {/* Brand Slogan */}
          <div className="mt-6">
            <p className="hannisol-slogan text-sm text-gray-600">
              "Hannisol's Insight, Navigating Crypto Like Hannibal Crossed the Alps."
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}