"use client"

import Script from 'next/script'

declare global {
  interface Window {
    gtag: any
    dataLayer: any[]
  }
}

export function GoogleAnalytics() {
  const GA_MEASUREMENT_ID = process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS_ID

  if (!GA_MEASUREMENT_ID) {
    return null
  }

  return (
    <>
      <Script
        strategy="afterInteractive"
        src={`https://www.googletagmanager.com/gtag/js?id=${GA_MEASUREMENT_ID}`}
      />
      <Script
        id="google-analytics"
        strategy="afterInteractive"
        dangerouslySetInnerHTML={{
          __html: `
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', '${GA_MEASUREMENT_ID}', {
              page_title: document.title,
              page_location: window.location.href,
              send_page_view: true,
              // Privacy settings
              anonymize_ip: true,
              allow_google_signals: false,
              allow_ad_personalization_signals: false
            });
          `,
        }}
      />
    </>
  )
}

// Google Analytics utility functions
export const trackEvent = (eventName: string, parameters?: any) => {
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('event', eventName, {
      event_category: 'user_interaction',
      event_label: parameters?.label || '',
      value: parameters?.value || 0,
      ...parameters
    })
  }
}

export const trackAddressCheck = (address: string, isValid: boolean) => {
  trackEvent('address_check', {
    event_category: 'address_validation',
    event_label: isValid ? 'valid' : 'invalid',
    custom_parameters: {
      address_length: address.length,
      address_valid: isValid
    }
  })
}

export const trackAnalysisComplete = (address: string, analysisTime: number) => {
  trackEvent('analysis_complete', {
    event_category: 'analysis',
    event_label: 'completed',
    value: analysisTime,
    custom_parameters: {
      address_length: address.length,
      analysis_duration: analysisTime
    }
  })
}

export const trackRiskAssessment = (riskScore: number, riskLevel: string) => {
  trackEvent('risk_assessment', {
    event_category: 'security',
    event_label: riskLevel,
    value: riskScore,
    custom_parameters: {
      risk_score: riskScore,
      risk_level: riskLevel
    }
  })
}

export const trackAdClick = (adNetwork: string, adSlot: string) => {
  trackEvent('ad_click', {
    event_category: 'monetization',
    event_label: adNetwork,
    custom_parameters: {
      ad_network: adNetwork,
      ad_slot: adSlot
    }
  })
}

export const trackUserFlow = (step: string, action: string) => {
  trackEvent('user_flow', {
    event_category: 'user_journey',
    event_label: step,
    custom_parameters: {
      flow_step: step,
      action: action
    }
  })
}

export const trackPerformance = (metric: string, value: number) => {
  trackEvent('performance_metric', {
    event_category: 'performance',
    event_label: metric,
    value: value,
    custom_parameters: {
      metric_name: metric,
      metric_value: value
    }
  })
}

// Enhanced ecommerce tracking for premium features
export const trackPremiumInterest = (feature: string) => {
  trackEvent('premium_interest', {
    event_category: 'monetization',
    event_label: feature,
    custom_parameters: {
      premium_feature: feature
    }
  })
}

// Page view tracking for SPA navigation
export const trackPageView = (url: string, title: string) => {
  if (typeof window !== 'undefined' && window.gtag) {
    window.gtag('config', process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS_ID, {
      page_title: title,
      page_location: url,
    })
  }
}