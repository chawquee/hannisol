import React from 'react'
import { cn } from '@/lib/utils'

interface LoadingSpinnerProps {
  size?: 'sm' | 'md' | 'lg' | 'xl'
  variant?: 'default' | 'hannisol' | 'dots' | 'pulse'
  className?: string
  text?: string
}

export function LoadingSpinner({ 
  size = 'md', 
  variant = 'default', 
  className,
  text 
}: LoadingSpinnerProps) {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-6 h-6', 
    lg: 'w-8 h-8',
    xl: 'w-12 h-12'
  }

  if (variant === 'hannisol') {
    return (
      <div className={cn("flex flex-col items-center space-y-2", className)}>
        <div className={cn("hannisol-logo animate-pulse-gold", sizeClasses[size])}>
          <div className="hannisol-logo-h text-xs">H</div>
          <div className="hannisol-logo-accent-1"></div>
          <div className="hannisol-logo-accent-2"></div>
          <div className="hannisol-logo-accent-3"></div>
        </div>
        {text && <span className="text-sm text-gray-600">{text}</span>}
      </div>
    )
  }

  if (variant === 'dots') {
    return (
      <div className={cn("flex items-center space-x-1", className)}>
        <div className={cn("bg-blue-600 rounded-full animate-bounce", sizeClasses.sm)}></div>
        <div className={cn("bg-blue-600 rounded-full animate-bounce [animation-delay:0.1s]", sizeClasses.sm)}></div>
        <div className={cn("bg-blue-600 rounded-full animate-bounce [animation-delay:0.2s]", sizeClasses.sm)}></div>
        {text && <span className="ml-2 text-sm text-gray-600">{text}</span>}
      </div>
    )
  }

  if (variant === 'pulse') {
    return (
      <div className={cn("flex items-center space-x-2", className)}>
        <div className={cn("bg-blue-600 rounded-full animate-pulse", sizeClasses[size])}></div>
        {text && <span className="text-sm text-gray-600">{text}</span>}
      </div>
    )
  }

  // Default spinner
  return (
    <div className={cn("flex items-center space-x-2", className)}>
      <div className={cn(
        "border-4 border-gray-200 border-t-blue-600 rounded-full animate-spin",
        sizeClasses[size]
      )}></div>
      {text && <span className="text-sm text-gray-600">{text}</span>}
    </div>
  )
}

// Specific loading components for common use cases
export function PageLoader({ text = "Loading..." }: { text?: string }) {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <LoadingSpinner variant="hannisol" size="xl" text={text} />
    </div>
  )
}

export function InlineLoader({ text }: { text?: string }) {
  return (
    <div className="flex items-center justify-center py-8">
      <LoadingSpinner variant="default" size="md" text={text} />
    </div>
  )
}

export function ButtonLoader({ size = 'sm' }: { size?: 'sm' | 'md' }) {
  return (
    <div className={cn(
      "border-2 border-gray-300 border-t-transparent rounded-full animate-spin",
      size === 'sm' ? 'w-4 h-4' : 'w-5 h-5'
    )}></div>
  )
}