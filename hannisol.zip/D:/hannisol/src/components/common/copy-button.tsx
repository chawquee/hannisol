'use client'

import React, { useState } from 'react'
import { Copy, Check } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip'
import { copyToClipboard, cn } from '@/lib/utils'

interface CopyButtonProps {
  text: string
  variant?: 'default' | 'ghost' | 'outline'
  size?: 'sm' | 'md' | 'lg' | 'icon'
  className?: string
  showText?: boolean
  successMessage?: string
  tooltipText?: string
}

export function CopyButton({
  text,
  variant = 'ghost',
  size = 'icon',
  className,
  showText = false,
  successMessage = 'Copied!',
  tooltipText = 'Copy to clipboard'
}: CopyButtonProps) {
  const [copied, setCopied] = useState(false)
  const [isLoading, setIsLoading] = useState(false)

  const handleCopy = async () => {
    if (isLoading || copied) return

    setIsLoading(true)
    const success = await copyToClipboard(text)
    
    if (success) {
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    }
    
    setIsLoading(false)
  }

  const buttonContent = (
    <Button
      variant={variant}
      size={size}
      onClick={handleCopy}
      disabled={isLoading || copied}
      className={cn(
        "transition-all duration-200",
        copied && "text-green-600 bg-green-50 border-green-200",
        className
      )}
    >
      {copied ? (
        <>
          <Check className="w-4 h-4" />
          {showText && <span className="ml-1">{successMessage}</span>}
        </>
      ) : (
        <>
          <Copy className="w-4 h-4" />
          {showText && <span className="ml-1">Copy</span>}
        </>
      )}
    </Button>
  )

  if (tooltipText) {
    return (
      <TooltipProvider>
        <Tooltip>
          <TooltipTrigger asChild>
            {buttonContent}
          </TooltipTrigger>
          <TooltipContent>
            <p>{copied ? successMessage : tooltipText}</p>
          </TooltipContent>
        </Tooltip>
      </TooltipProvider>
    )
  }

  return buttonContent
}

// Specialized copy components
export function CopyAddress({ address, className }: { address: string; className?: string }) {
  return (
    <div className={cn("flex items-center space-x-2 p-2 bg-gray-50 rounded-lg border", className)}>
      <code className="flex-1 text-sm font-mono text-gray-900 break-all">
        {address}
      </code>
      <CopyButton
        text={address}
        tooltipText="Copy address"
        successMessage="Address copied!"
      />
    </div>
  )
}

export function CopyText({ 
  text, 
  displayText, 
  className 
}: { 
  text: string
  displayText?: string
  className?: string 
}) {
  return (
    <div className={cn("inline-flex items-center space-x-1", className)}>
      <span className="text-sm text-gray-700">{displayText || text}</span>
      <CopyButton
        text={text}
        size="sm"
        variant="ghost"
        className="h-6 w-6"
      />
    </div>
  )
}

export function CopyCodeBlock({ 
  code, 
  language = '',
  className 
}: { 
  code: string
  language?: string
  className?: string 
}) {
  return (
    <div className={cn("relative group", className)}>
      <pre className="bg-gray-900 text-gray-100 p-4 rounded-lg overflow-x-auto">
        <code className={`language-${language}`}>{code}</code>
      </pre>
      <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
        <CopyButton
          text={code}
          variant="outline"
          size="sm"
          className="bg-gray-800 border-gray-600 text-gray-200 hover:bg-gray-700"
          tooltipText="Copy code"
        />
      </div>
    </div>
  )
}