"use client"

import { useEffect } from 'react'
import { cn } from '@/lib/utils'

interface AAdsProps {
  adId: string
  width?: number
  height?: number
  className?: string
  style?: React.CSSProperties
}

export function AAds({
  adId,
  width = 728,
  height = 90,
  className,
  style
}: AAdsProps) {
  const aAdsId = process.env.NEXT_PUBLIC_A_ADS_ID || adId

  useEffect(() => {
    if (typeof window !== 'undefined' && aAdsId) {
      try {
        // Create A-ADS iframe
        const adContainer = document.getElementById(`a-ads-${aAdsId}`)
        if (adContainer && !adContainer.querySelector('iframe')) {
          const iframe = document.createElement('iframe')
          iframe.src = `https://a-ads.com/${aAdsId}?size=${width}x${height}`
          iframe.width = width.toString()
          iframe.height = height.toString()
          iframe.style.border = 'none'
          iframe.style.display = 'block'
          iframe.loading = 'lazy'
          iframe.title = 'A-ADS Advertisement'
          
          adContainer.appendChild(iframe)
        }
      } catch (error) {
        console.error('A-ADS error:', error)
      }
    }
  }, [aAdsId, width, height])

  // Don't render if no ad ID
  if (!aAdsId) {
    return (
      <div 
        className={cn("ad-banner bg-gray-100 text-gray-400", className)} 
        style={{ width, height, ...style }}
      >
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <p className="text-sm">Bitcoin Advertisement</p>
            <p className="text-xs">A-ADS not configured</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className={cn("ad-container", className)}>
      <div className="text-center text-xs text-gray-400 mb-2">Bitcoin Advertisement</div>
      <div 
        id={`a-ads-${aAdsId}`}
        className="a-ads"
        style={{ width, height, ...style }}
      >
        {/* A-ADS iframe will be loaded here */}
      </div>
    </div>
  )
}

// Specific A-ADS components for different placements
export function AAdsEarningBanner({ className }: { className?: string }) {
  return (
    <AAds
      adId="1234567"
      width={728}
      height={90}
      className={cn("max-w-2xl mx-auto", className)}
    />
  )
}

export function AAdsRectangle({ className }: { className?: string }) {
  return (
    <AAds
      adId="2345678"
      width={300}
      height={250}
      className={cn("ad-sidebar", className)}
    />
  )
}

export function AAdsSquare({ className }: { className?: string }) {
  return (
    <AAds
      adId="3456789"
      width={250}
      height={250}
      className={cn("ad-sidebar", className)}
    />
  )
}

export function AAdsMobile({ className }: { className?: string }) {
  return (
    <AAds
      adId="4567890"
      width={320}
      height={100}
      className={cn("max-w-sm mx-auto md:hidden", className)}
    />
  )
}