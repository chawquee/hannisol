"use client"

import { useEffect } from 'react'
import { cn } from '@/lib/utils'

interface MediaNetProps {
  dataVN: string
  dataCrid?: string
  width?: number
  height?: number
  className?: string
  style?: React.CSSProperties
}

declare global {
  interface Window {
    _mNHandle: any
    _mNDetails: any
  }
}

export function MediaNet({
  dataVN,
  dataCrid,
  width = 728,
  height = 90,
  className,
  style
}: MediaNetProps) {
  const mediaNetId = process.env.NEXT_PUBLIC_MEDIA_NET_ID || dataVN

  useEffect(() => {
    if (typeof window !== 'undefined' && mediaNetId) {
      try {
        // Load Media.net script if not already loaded
        if (!document.querySelector('script[src*="media.net"]')) {
          const script = document.createElement('script')
          script.src = 'https://contextual.media.net/dmedianet.js?cid=8CUW8XQ2L'
          script.async = true
          document.head.appendChild(script)
        }

        // Initialize Media.net ad
        window._mNHandle = window._mNHandle || {}
        window._mNHandle.queue = window._mNHandle.queue || []
        window._mNDetails = window._mNDetails || {}

        window._mNHandle.queue.push(function() {
          window._mNDetails[mediaNetId] = {
            vn: mediaNetId,
            crid: dataCrid || '211666235',
            size: `${width}x${height}`,
            opt: {
              div: `div-media-net-${mediaNetId}`,
              type: 'banner'
            }
          }
        })
      } catch (error) {
        console.error('Media.net error:', error)
      }
    }
  }, [mediaNetId, dataCrid, width, height])

  // Don't render if no VN ID
  if (!mediaNetId) {
    return (
      <div 
        className={cn("ad-banner bg-gray-100 text-gray-400", className)} 
        style={{ width, height, ...style }}
      >
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <p className="text-sm">Yahoo/Bing Advertisement</p>
            <p className="text-xs">Media.net not configured</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className={cn("ad-container", className)}>
      <div className="text-center text-xs text-gray-400 mb-2">Sponsored Content</div>
      <div 
        id={`div-media-net-${mediaNetId}`}
        className="media-net-ad"
        style={{ width, height, ...style }}
      >
        {/* Media.net ad will be loaded here */}
      </div>
    </div>
  )
}

// Specific Media.net components for different placements
export function MediaNetBanner({ className }: { className?: string }) {
  return (
    <MediaNet
      dataVN="123456789"
      dataCrid="211666235"
      width={728}
      height={90}
      className={cn("max-w-2xl mx-auto", className)}
    />
  )
}

export function MediaNetRectangle({ className }: { className?: string }) {
  return (
    <MediaNet
      dataVN="234567890"
      dataCrid="311666235" 
      width={300}
      height={250}
      className={cn("ad-sidebar", className)}
    />
  )
}

export function MediaNetLeaderboard({ className }: { className?: string }) {
  return (
    <MediaNet
      dataVN="345678901"
      dataCrid="411666235"
      width={728}
      height={90}
      className={cn("max-w-4xl mx-auto", className)}
    />
  )
}

export function MediaNetMobile({ className }: { className?: string }) {
  return (
    <MediaNet
      dataVN="456789012"
      dataCrid="511666235"
      width={320}
      height={50}
      className={cn("max-w-sm mx-auto md:hidden", className)}
    />
  )
}