"use client"

import { useEffect } from 'react'
import { cn } from '@/lib/utils'

interface GoogleAdsenseProps {
  adSlot: string
  adFormat?: 'auto' | 'rectangle' | 'banner' | 'leaderboard' | 'skyscraper'
  adLayout?: 'in-article' | 'in-feed' | string
  adLayoutKey?: string
  fullWidthResponsive?: boolean
  className?: string
  style?: React.CSSProperties
}

declare global {
  interface Window {
    adsbygoogle: any[]
  }
}

export function GoogleAdsense({
  adSlot,
  adFormat = 'auto',
  adLayout,
  adLayoutKey,
  fullWidthResponsive = true,
  className,
  style
}: GoogleAdsenseProps) {
  const adClientId = process.env.NEXT_PUBLIC_GOOGLE_ADSENSE_ID

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        // Load AdSense script if not already loaded
        if (!document.querySelector('script[src*="adsbygoogle.js"]')) {
          const script = document.createElement('script')
          script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${adClientId}`
          script.async = true
          script.crossOrigin = 'anonymous'
          document.head.appendChild(script)
        }

        // Initialize ads
        window.adsbygoogle = window.adsbygoogle || []
        window.adsbygoogle.push({})
      } catch (error) {
        console.error('AdSense error:', error)
      }
    }
  }, [adClientId])

  // Don't render if no client ID
  if (!adClientId) {
    return (
      <div className={cn("ad-banner bg-gray-100 text-gray-400", className)} style={style}>
        <div className="text-center">
          <p className="text-sm">Advertisement</p>
          <p className="text-xs">AdSense not configured</p>
        </div>
      </div>
    )
  }

  const adStyle = {
    display: 'block',
    ...style
  }

  return (
    <div className={cn("ad-container", className)}>
      <div className="text-center text-xs text-gray-400 mb-2">Advertisement</div>
      <ins
        className="adsbygoogle"
        style={adStyle}
        data-ad-client={adClientId}
        data-ad-slot={adSlot}
        data-ad-format={adFormat}
        data-ad-layout={adLayout}
        data-ad-layout-key={adLayoutKey}
        data-full-width-responsive={fullWidthResponsive}
      ></ins>
    </div>
  )
}

// Specific AdSense components for different placements
export function TopBannerAd({ className }: { className?: string }) {
  return (
    <GoogleAdsense
      adSlot="1234567890"
      adFormat="banner"
      className={cn("max-w-2xl mx-auto", className)}
    />
  )
}

export function SidebarAd({ className }: { className?: string }) {
  return (
    <GoogleAdsense
      adSlot="2345678901"
      adFormat="rectangle"
      className={cn("ad-sidebar", className)}
    />
  )
}

export function InArticleAd({ className }: { className?: string }) {
  return (
    <GoogleAdsense
      adSlot="3456789012"
      adFormat="auto"
      adLayout="in-article"
      className={cn("max-w-xl mx-auto my-6", className)}
    />
  )
}

export function FooterAd({ className }: { className?: string }) {
  return (
    <GoogleAdsense
      adSlot="4567890123"
      adFormat="leaderboard"
      className={cn("max-w-4xl mx-auto", className)}
    />
  )
}