"use client"

import { useEffect } from 'react'
import { cn } from '@/lib/utils'

interface CoinzillaAdProps {
  zoneId: string
  width?: number
  height?: number
  className?: string
  style?: React.CSSProperties
}

export function CoinzillaAd({
  zoneId,
  width = 728,
  height = 90,
  className,
  style
}: CoinzillaAdProps) {
  const coinzillaId = process.env.NEXT_PUBLIC_COINZILLA_ZONE_ID || zoneId

  useEffect(() => {
    if (typeof window !== 'undefined' && coinzillaId) {
      try {
        // Load Coinzilla script if not already loaded
        if (!document.querySelector('script[src*="coinzilla.com"]')) {
          const script = document.createElement('script')
          script.src = 'https://coinzilla.com/js/c.js'
          script.async = true
          document.head.appendChild(script)
        }

        // Initialize Coinzilla ad
        const coinzillaScript = document.createElement('script')
        coinzillaScript.innerHTML = `
          window.coinzilla_display = window.coinzilla_display || [];
          var c_display_preferences = {};
          c_display_preferences.zone = "${coinzillaId}";
          c_display_preferences.width = "${width}";
          c_display_preferences.height = "${height}";
          coinzilla_display.push(c_display_preferences);
        `
        document.head.appendChild(coinzillaScript)
      } catch (error) {
        console.error('Coinzilla error:', error)
      }
    }
  }, [coinzillaId, width, height])

  // Don't render if no zone ID
  if (!coinzillaId) {
    return (
      <div 
        className={cn("ad-banner bg-gray-100 text-gray-400", className)} 
        style={{ width, height, ...style }}
      >
        <div className="flex items-center justify-center h-full">
          <div className="text-center">
            <p className="text-sm">Crypto Advertisement</p>
            <p className="text-xs">Coinzilla not configured</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className={cn("ad-container", className)}>
      <div className="text-center text-xs text-gray-400 mb-2">Crypto Advertisement</div>
      <div 
        id={`coinzilla-${coinzillaId}`}
        className="coinzilla-ad"
        style={{ width, height, ...style }}
      >
        {/* Coinzilla ad will be loaded here */}
      </div>
    </div>
  )
}

// Specific Coinzilla components for different placements
export function CoinzillaBanner({ className }: { className?: string }) {
  return (
    <CoinzillaAd
      zoneId="C-123456789"
      width={728}
      height={90}
      className={cn("max-w-2xl mx-auto", className)}
    />
  )
}

export function CoinzillaRectangle({ className }: { className?: string }) {
  return (
    <CoinzillaAd
      zoneId="C-234567890"
      width={300}
      height={250}
      className={cn("ad-sidebar", className)}
    />
  )
}

export function CoinzillaLeaderboard({ className }: { className?: string }) {
  return (
    <CoinzillaAd
      zoneId="C-345678901"
      width={728}
      height={90}
      className={cn("max-w-4xl mx-auto", className)}
    />
  )
}

export function CoinzillaSkyscraper({ className }: { className?: string }) {
  return (
    <CoinzillaAd
      zoneId="C-456789012"
      width={160}
      height={600}
      className={cn("ad-sidebar", className)}
    />
  )
}