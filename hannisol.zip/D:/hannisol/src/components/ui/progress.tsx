import * as React from "react"
import * as ProgressPrimitive from "@radix-ui/react-progress"

import { cn } from "@/lib/utils"

const Progress = React.forwardRef<
  React.ElementRef<typeof ProgressPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ProgressPrimitive.Root> & {
    indicatorClassName?: string
  }
>(({ className, value, indicatorClassName, ...props }, ref) => (
  <ProgressPrimitive.Root
    ref={ref}
    className={cn(
      "relative h-4 w-full overflow-hidden rounded-full bg-secondary",
      className
    )}
    {...props}
  >
    <ProgressPrimitive.Indicator
      className={cn(
        "h-full w-full flex-1 bg-primary transition-all",
        indicatorClassName
      )}
      style={{ transform: `translateX(-${100 - (value || 0)}%)` }}
    />
  </ProgressPrimitive.Root>
))
Progress.displayName = ProgressPrimitive.Root.displayName

// Custom progress variants for different contexts
const TokenDistributionProgress = React.forwardRef<
  React.ElementRef<typeof ProgressPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ProgressPrimitive.Root> & {
    variant?: "largest" | "top10" | "burn"
  }
>(({ className, value, variant = "largest", ...props }, ref) => {
  const getVariantStyles = () => {
    switch (variant) {
      case "largest":
        return "bg-blue-600"
      case "top10":
        return "bg-purple-600"
      case "burn":
        return "bg-green-600"
      default:
        return "bg-primary"
    }
  }

  return (
    <ProgressPrimitive.Root
      ref={ref}
      className={cn(
        "relative h-2 w-full overflow-hidden rounded-full bg-gray-200",
        className
      )}
      {...props}
    >
      <ProgressPrimitive.Indicator
        className={cn(
          "h-full w-full flex-1 transition-all duration-500 ease-out",
          getVariantStyles()
        )}
        style={{ transform: `translateX(-${100 - (value || 0)}%)` }}
      />
    </ProgressPrimitive.Root>
  )
})
TokenDistributionProgress.displayName = "TokenDistributionProgress"

// Risk assessment progress bar
const RiskProgress = React.forwardRef<
  React.ElementRef<typeof ProgressPrimitive.Root>,
  React.ComponentPropsWithoutRef<typeof ProgressPrimitive.Root> & {
    riskScore: number
  }
>(({ className, value, riskScore, ...props }, ref) => {
  const getRiskColor = () => {
    if (riskScore >= 80) return "bg-red-500"
    if (riskScore >= 60) return "bg-yellow-500"
    if (riskScore >= 40) return "bg-orange-500"
    return "bg-green-500"
  }

  return (
    <ProgressPrimitive.Root
      ref={ref}
      className={cn(
        "relative h-3 w-full overflow-hidden rounded-full bg-gray-200",
        className
      )}
      {...props}
    >
      <ProgressPrimitive.Indicator
        className={cn(
          "h-full w-full flex-1 transition-all duration-700 ease-out",
          getRiskColor()
        )}
        style={{ transform: `translateX(-${100 - (value || 0)}%)` }}
      />
    </ProgressPrimitive.Root>
  )
})
RiskProgress.displayName = "RiskProgress"

// Circular progress for final assessment scores
const CircularProgress = React.forwardRef<
  HTMLDivElement,
  React.HTMLAttributes<HTMLDivElement> & {
    value: number
    size?: number
    strokeWidth?: number
    variant?: "blue" | "purple" | "green" | "gold"
  }
>(({ className, value, size = 60, strokeWidth = 4, variant = "blue", ...props }, ref) => {
  const radius = (size - strokeWidth) / 2
  const circumference = radius * 2 * Math.PI
  const strokeDasharray = circumference
  const strokeDashoffset = circumference - (value / 100) * circumference

  const getVariantColor = () => {
    switch (variant) {
      case "blue":
        return "stroke-blue-500"
      case "purple":
        return "stroke-purple-500"
      case "green":
        return "stroke-green-500"
      case "gold":
        return "stroke-yellow-500"
      default:
        return "stroke-blue-500"
    }
  }

  return (
    <div
      ref={ref}
      className={cn("relative inline-flex items-center justify-center", className)}
      {...props}
    >
      <svg
        width={size}
        height={size}
        viewBox={`0 0 ${size} ${size}`}
        className="transform -rotate-90"
      >
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="none"
          className="text-gray-200"
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="currentColor"
          strokeWidth={strokeWidth}
          fill="none"
          strokeDasharray={strokeDasharray}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          className={cn("transition-all duration-1000 ease-out", getVariantColor())}
        />
      </svg>
    </div>
  )
})
CircularProgress.displayName = "CircularProgress"

export { Progress, TokenDistributionProgress, RiskProgress, CircularProgress }