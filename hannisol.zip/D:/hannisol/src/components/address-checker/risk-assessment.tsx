"use client"

import React from 'react'
import { AlertTriangle, Shield, TrendingDown, Lock } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { TokenDistributionProgress } from '@/components/ui/progress'
import { formatCurrency, getRiskLevel, getRiskScoreColor, cn } from '@/lib/utils'

interface RiskFactor {
  label: string
  status: 'yes' | 'no' | 'partial' | 'disabled' | 'distributed'
  impact: 'positive' | 'negative' | 'neutral'
}

interface TokenDistribution {
  label: string
  percentage: number
  variant: 'largest' | 'top10' | 'burn'
}

interface RiskAssessmentProps {
  riskScore?: number
  totalValue?: number
  className?: string
}

export function RiskAssessment({ 
  riskScore = 65,
  totalValue = 1200000,
  className 
}: RiskAssessmentProps) {
  
  const riskFactors: RiskFactor[] = [
    {
      label: 'Liquidity Locked',
      status: 'no',
      impact: 'negative'
    },
    {
      label: 'Ownership Renounced',
      status: 'partial',
      impact: 'neutral'
    },
    {
      label: 'Large Holders',
      status: 'distributed',
      impact: 'positive'
    },
    {
      label: 'Freeze Authority',
      status: 'disabled',
      impact: 'positive'
    }
  ]

  const tokenDistribution: TokenDistribution[] = [
    {
      label: 'Largest Holder',
      percentage: 42,
      variant: 'largest'
    },
    {
      label: 'Top 10 Holders',
      percentage: 68,
      variant: 'top10'
    },
    {
      label: 'Burn Wallet',
      percentage: 15,
      variant: 'burn'
    }
  ]

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'yes':
      case 'disabled':
      case 'distributed':
        return <Shield className="w-4 h-4 text-green-600" />
      case 'partial':
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />
      case 'no':
        return <TrendingDown className="w-4 h-4 text-red-600" />
      default:
        return <AlertTriangle className="w-4 h-4 text-gray-600" />
    }
  }

  const getStatusVariant = (status: string, impact: string): any => {
    if (impact === 'positive') return 'valid'
    if (impact === 'negative') return 'error'
    return 'warning'
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'yes':
        return 'Yes'
      case 'no':
        return 'No'
      case 'partial':
        return 'Partial'
      case 'disabled':
        return 'Disabled'
      case 'distributed':
        return 'Distributed'
      default:
        return status
    }
  }

  return (
    <Card className={cn("address-card animate-slide-up", className)}>
      <div className="address-card-header">
        <AlertTriangle className="w-5 h-5 text-yellow-500" />
        <h3 className="address-card-title">Rug Pull Risk Analysis</h3>
      </div>
      
      <CardContent className="p-6 pt-0">
        {/* Risk Score Display */}
        <div className="text-center mb-6">
          <div className="text-5xl font-bold text-yellow-600 mb-2">
            {riskScore}/100
          </div>
          <Badge variant="warning" className="text-base px-4 py-2 mb-2">
            {getRiskLevel(riskScore)}
          </Badge>
          <div className="text-lg text-gray-600">
            {formatCurrency(totalValue, 'USD')}
          </div>
        </div>

        {/* Risk Assessment Bar */}
        <div className="mb-6">
          <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
            <div 
              className={cn(
                "h-3 rounded-full transition-all duration-700",
                riskScore >= 80 ? "bg-red-500" :
                riskScore >= 60 ? "bg-yellow-500" :
                riskScore >= 40 ? "bg-orange-500" : "bg-green-500"
              )}
              style={{ width: `${riskScore}%` }}
            ></div>
          </div>
          <div className="flex justify-between text-xs text-gray-500">
            <span>Low Risk</span>
            <span>High Risk</span>
          </div>
        </div>

        {/* Risk Factors */}
        <div className="space-y-4 mb-6">
          <div className="text-sm font-medium text-gray-700 mb-3">Risk Factors</div>
          
          {riskFactors.map((factor, index) => (
            <div key={index} className="flex justify-between items-center py-2">
              <div className="flex items-center space-x-2 flex-1">
                {getStatusIcon(factor.status)}
                <span className="text-sm text-gray-600">{factor.label}</span>
              </div>
              <Badge variant={getStatusVariant(factor.status, factor.impact)}>
                {getStatusText(factor.status)}
              </Badge>
            </div>
          ))}
        </div>

        {/* Token Distribution */}
        <div className="space-y-4">
          <div className="text-sm font-medium text-gray-700 mb-3">Token Distribution</div>
          
          {tokenDistribution.map((dist, index) => (
            <div key={index} className="space-y-1">
              <div className="flex justify-between text-xs">
                <span className="text-gray-600">{dist.label}</span>
                <span className="font-medium">{dist.percentage}%</span>
              </div>
              <TokenDistributionProgress 
                value={dist.percentage} 
                variant={dist.variant}
                className="h-2"
              />
            </div>
          ))}
        </div>

        {/* Additional Risk Metrics */}
        <div className="mt-6 pt-4 border-t border-gray-200">
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 bg-yellow-50 rounded-lg">
              <div className="text-lg font-bold text-yellow-600">Medium</div>
              <div className="text-xs text-gray-600">Risk Level</div>
            </div>
            <div className="text-center p-3 bg-blue-50 rounded-lg">
              <div className="text-lg font-bold text-blue-600">Active</div>
              <div className="text-xs text-gray-600">Monitoring</div>
            </div>
          </div>
        </div>

        {/* Risk Summary */}
        <div className="mt-4 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
          <div className="flex items-start space-x-2">
            <AlertTriangle className="w-4 h-4 text-yellow-600 mt-0.5 flex-shrink-0" />
            <div className="text-sm text-yellow-800">
              <div className="font-medium mb-1">Moderate Risk Detected</div>
              <div className="text-xs">
                Some risk factors present. Exercise caution and conduct additional research before investing.
              </div>
            </div>
          </div>
        </div>

        {/* Last Analysis */}
        <div className="mt-4 text-center">
          <div className="text-xs text-gray-500">
            Risk analysis updated: {new Date().toLocaleString()}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}