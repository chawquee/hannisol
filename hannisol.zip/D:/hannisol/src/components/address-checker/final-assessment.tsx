"use client"

import React from 'react'
import { Search, Target, Shield, TrendingUp } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { cn } from '@/lib/utils'

interface AssessmentScore {
  icon: React.ReactNode
  score: string | number
  label?: string
  variant: 'blue' | 'purple' | 'green' | 'gold'
}

interface FinalAssessmentProps {
  className?: string
}

export function FinalAssessment({ className }: FinalAssessmentProps) {
  const assessmentScores: AssessmentScore[] = [
    {
      icon: <Target className="w-4 h-4" />,
      score: 78,
      label: 'Technical Score',
      variant: 'blue'
    },
    {
      icon: <Shield className="w-4 h-4" />,
      score: 82,
      label: 'Security Score',
      variant: 'purple'
    },
    {
      icon: <TrendingUp className="w-4 h-4" />,
      score: 'A',
      label: 'Community Grade',
      variant: 'green'
    },
    {
      icon: <Search className="w-4 h-4" />,
      score: 'A',
      label: 'Overall Grade',
      variant: 'gold'
    }
  ]

  const getVariantStyles = (variant: string) => {
    switch (variant) {
      case 'blue':
        return {
          bg: 'bg-blue-50',
          circle: 'bg-blue-500',
          text: 'text-blue-600'
        }
      case 'purple':
        return {
          bg: 'bg-purple-50',
          circle: 'bg-purple-500',
          text: 'text-purple-600'
        }
      case 'green':
        return {
          bg: 'bg-green-50',
          circle: 'bg-green-500',
          text: 'text-green-600'
        }
      case 'gold':
        return {
          bg: 'bg-yellow-50',
          circle: 'bg-yellow-500',
          text: 'text-yellow-600'
        }
      default:
        return {
          bg: 'bg-gray-50',
          circle: 'bg-gray-500',
          text: 'text-gray-600'
        }
    }
  }

  const getScoreDescription = (score: string | number) => {
    if (typeof score === 'number') {
      if (score >= 80) return 'Excellent'
      if (score >= 70) return 'Good'
      if (score >= 60) return 'Fair'
      return 'Needs Improvement'
    }
    
    switch (score) {
      case 'A':
        return 'Excellent'
      case 'B':
        return 'Good'
      case 'C':
        return 'Average'
      case 'D':
        return 'Below Average'
      case 'F':
        return 'Poor'
      default:
        return 'Unknown'
    }
  }

  return (
    <Card className={cn("address-card animate-slide-up", className)}>
      <div className="address-card-header">
        <Search className="w-5 h-5 text-gray-500" />
        <h3 className="address-card-title">Final Results</h3>
      </div>
      
      <CardContent className="p-6 pt-0">
        {/* Assessment Scores Grid */}
        <div className="grid grid-cols-4 gap-4 mb-6">
          {assessmentScores.map((assessment, index) => {
            const styles = getVariantStyles(assessment.variant)
            return (
              <div 
                key={index} 
                className={cn("text-center p-4 rounded-lg transition-transform hover:scale-105", styles.bg)}
              >
                {/* Icon Circle */}
                <div className={cn(
                  "assessment-circle mx-auto mb-3",
                  styles.circle
                )}>
                  {assessment.icon}
                </div>
                
                {/* Score */}
                <div className={cn("assessment-score mb-1", styles.text)}>
                  {assessment.score}
                </div>
                
                {/* Description */}
                <div className="text-xs text-gray-600 mb-1">
                  {getScoreDescription(assessment.score)}
                </div>
                
                {/* Label */}
                {assessment.label && (
                  <div className="text-xs text-gray-500">
                    {assessment.label}
                  </div>
                )}
              </div>
            )
          })}
        </div>

        {/* Overall Assessment */}
        <div className="p-4 bg-gradient-to-r from-green-50 to-blue-50 rounded-lg border mb-6">
          <div className="text-center">
            <div className="text-lg font-bold text-gray-900 mb-2">Overall Assessment</div>
            <div className="text-3xl font-bold text-green-600 mb-2">A-</div>
            <div className="text-sm text-gray-600 mb-2">
              This address shows strong technical and security characteristics with excellent community engagement.
            </div>
            <div className="text-xs text-gray-500">
              Recommended for moderate to high confidence interactions.
            </div>
          </div>
        </div>

        {/* Score Breakdown */}
        <div className="space-y-3 mb-6">
          <div className="text-sm font-medium text-gray-700 mb-3">Score Breakdown</div>
          
          <div className="flex justify-between items-center p-2 bg-blue-50 rounded">
            <span className="text-sm text-gray-700">Technical Analysis</span>
            <span className="font-medium text-blue-600">78/100</span>
          </div>
          
          <div className="flex justify-between items-center p-2 bg-purple-50 rounded">
            <span className="text-sm text-gray-700">Security Rating</span>
            <span className="font-medium text-purple-600">82/100</span>
          </div>
          
          <div className="flex justify-between items-center p-2 bg-green-50 rounded">
            <span className="text-sm text-gray-700">Community Score</span>
            <span className="font-medium text-green-600">Grade A</span>
          </div>
          
          <div className="flex justify-between items-center p-2 bg-yellow-50 rounded">
            <span className="text-sm text-gray-700">Final Rating</span>
            <span className="font-medium text-yellow-600">Grade A</span>
          </div>
        </div>

        {/* Confidence Level */}
        <div className="p-3 bg-gray-50 rounded-lg border">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm font-medium text-gray-700">Confidence Level</div>
            <div className="text-lg font-bold text-green-600">92%</div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
            <div className="bg-green-600 h-2 rounded-full transition-all duration-500" style={{ width: '92%' }}></div>
          </div>
          <div className="text-xs text-gray-600">
            High confidence in assessment accuracy based on available data
          </div>
        </div>

        {/* Analysis Timestamp */}
        <div className="mt-4 text-center">
          <div className="text-xs text-gray-500">
            Final assessment completed: {new Date().toLocaleString()}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}