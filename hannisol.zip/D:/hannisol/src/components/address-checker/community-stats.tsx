"use client"

import React from 'react'
import { Users, TrendingUp, MessageCircle, Hash } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { formatCompactNumber, cn } from '@/lib/utils'

interface CommunityMetric {
  label: string
  value: string | number
  type: 'followers' | 'assessment' | 'growth' | 'sentiment' | 'engagement'
  variant?: 'blue' | 'green' | 'yellow' | 'purple' | 'gray'
}

interface SentimentData {
  label: string
  percentage: number
  color: string
}

interface CommunitySentiment {
  positive: number
  neutral: number
  negative: number
}

interface CommunityStatsProps {
  followers?: number
  assessmentScore?: string
  growth?: number
  sentiment?: string
  className?: string
}

export function CommunityStats({ 
  followers = 15200,
  assessmentScore = 'High',
  growth = 12,
  sentiment = 'Positive',
  className 
}: CommunityStatsProps) {
  
  const communityMetrics: CommunityMetric[] = [
    {
      label: 'Social Media Followers',
      value: `${formatCompactNumber(followers)}`,
      type: 'followers',
      variant: 'blue'
    },
    {
      label: 'AI Assessment Score',
      value: assessmentScore,
      type: 'assessment',
      variant: 'blue'
    },
    {
      label: 'Growth',
      value: `+${growth}%`,
      type: 'growth',
      variant: 'green'
    },
    {
      label: 'Overall Sentiment',
      value: sentiment,
      type: 'sentiment',
      variant: 'yellow'
    },
    {
      label: 'Engagement',
      value: '4.8K',
      type: 'engagement',
      variant: 'purple'
    },
    {
      label: 'Mentions',
      value: '2.1K',
      type: 'engagement',
      variant: 'purple'
    },
    {
      label: 'Active Rate',
      value: '47%',
      type: 'engagement',
      variant: 'gray'
    }
  ]

  const sentimentData: SentimentData[] = [
    { label: 'Positive', percentage: 72, color: 'text-green-600' },
    { label: 'Neutral', percentage: 20, color: 'text-gray-600' },
    { label: 'Negative', percentage: 8, color: 'text-red-600' }
  ]

  const getVariantStyles = (variant: string) => {
    switch (variant) {
      case 'blue':
        return 'bg-blue-50 text-blue-600'
      case 'green':
        return 'bg-green-50 text-green-600'
      case 'yellow':
        return 'bg-yellow-50 text-yellow-600'
      case 'purple':
        return 'bg-purple-50 text-purple-600'
      case 'gray':
        return 'bg-gray-50 text-gray-600'
      default:
        return 'bg-gray-50 text-gray-600'
    }
  }

  const trendingKeywords = ['Solana', 'Staking', 'DeFi']

  return (
    <Card className={cn("address-card animate-slide-up", className)}>
      <div className="address-card-header">
        <Users className="w-5 h-5 text-blue-500" />
        <h3 className="address-card-title">Community Interaction</h3>
      </div>
      
      <CardContent className="p-6 pt-0">
        {/* Community Metrics Grid */}
        <div className="grid grid-cols-1 gap-4 mb-6">
          {communityMetrics.map((metric, index) => (
            <div 
              key={index} 
              className={cn(
                "metric-card transition-transform hover:scale-105",
                getVariantStyles(metric.variant)
              )}
            >
              <div className="metric-value">
                {metric.value}
              </div>
              <div className="metric-label">
                {metric.label}
              </div>
            </div>
          ))}
        </div>

        {/* Community Sentiment Analysis */}
        <div className="space-y-4 mb-6">
          <div className="text-sm font-medium text-gray-700 mb-3">Community Sentiment</div>
          
          {sentimentData.map((sentiment, index) => (
            <div key={index} className="flex justify-between items-center text-sm">
              <span className="text-gray-600">{sentiment.label}</span>
              <span className={cn("font-medium", sentiment.color)}>
                {sentiment.percentage}%
              </span>
            </div>
          ))}
        </div>

        {/* Recent Activity */}
        <div className="space-y-3 mb-6">
          <div className="text-sm font-medium text-gray-700 mb-3">Recent Activity</div>
          
          <div className="p-3 bg-green-50 rounded-lg border border-green-200">
            <div className="flex items-center space-x-2 mb-1">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className="text-sm font-medium text-green-800">Positive Trend</span>
            </div>
            <div className="text-xs text-green-600">
              Social media activity increased by 15% this week
            </div>
          </div>

          <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-center space-x-2 mb-1">
              <MessageCircle className="w-4 h-4 text-blue-600" />
              <span className="text-sm font-medium text-blue-800">High Engagement</span>
            </div>
            <div className="text-xs text-blue-600">
              Above average community interaction rates
            </div>
          </div>
        </div>

        {/* Recent Mentions */}
        <div className="mb-6">
          <div className="text-sm font-medium text-gray-700 mb-2">Recent Mentions</div>
          <div className="text-xs text-gray-600 leading-relaxed">
            Social media activity has increased by 15% in the last week with positive mentions 
            regarding community engagement and high staking rewards. Overall sentiment remains 
            optimistic with strong developer activity.
          </div>
        </div>

        {/* Trending Keywords */}
        <div className="mb-6">
          <div className="text-sm font-medium text-gray-700 mb-2">Trending Keywords</div>
          <div className="flex flex-wrap gap-2">
            {trendingKeywords.map((keyword, index) => (
              <Badge key={index} variant="info" className="text-xs">
                <Hash className="w-3 h-3 mr-1" />
                {keyword}
              </Badge>
            ))}
          </div>
        </div>

        {/* Community Health Score */}
        <div className="p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg border">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm font-medium text-gray-700">Community Health Score</div>
            <div className="text-2xl font-bold text-blue-600">A+</div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 h-2 rounded-full" style={{ width: '85%' }}></div>
          </div>
          <div className="text-xs text-gray-600">
            Strong community engagement with positive sentiment trends
          </div>
        </div>

        {/* Last Updated */}
        <div className="mt-4 text-center">
          <div className="text-xs text-gray-500">
            Community data updated: {new Date().toLocaleString()}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}