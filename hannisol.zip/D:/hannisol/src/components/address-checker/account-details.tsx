"use client"

import React, { useState } from 'react'
import { FileText, Copy, Check } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { truncateAddress, copyToClipboard, cn } from '@/lib/utils'

interface AccountDetail {
  label: string
  value: string | number
  copyable?: boolean
  technical?: boolean
}

interface AccountDetailsProps {
  address: string
  className?: string
}

export function AccountDetails({ 
  address = 'DH2dr...3hxJqG2',
  className 
}: AccountDetailsProps) {
  const [copiedField, setCopiedField] = useState<string | null>(null)

  const accountDetails: AccountDetail[] = [
    {
      label: 'Address',
      value: address,
      copyable: true
    },
    {
      label: 'Executable',
      value: 'No',
      technical: true
    },
    {
      label: 'Rent Epoch',
      value: '18446744073709551615',
      technical: true
    },
    {
      label: 'Data Size',
      value: '0 bytes',
      technical: true
    },
    {
      label: 'Owner',
      value: 'System Program',
      technical: true
    },
    {
      label: 'Lamports',
      value: '1250000000',
      technical: true
    }
  ]

  const handleCopy = async (field: string, value: string) => {
    const success = await copyToClipboard(value)
    if (success) {
      setCopiedField(field)
      setTimeout(() => setCopiedField(null), 2000)
    }
  }

  return (
    <Card className={cn("address-card animate-slide-up", className)}>
      <div className="address-card-header">
        <FileText className="w-5 h-5 text-gray-500" />
        <h3 className="address-card-title">Account Details</h3>
      </div>
      
      <CardContent className="p-6 pt-0">
        {/* Main Address Display */}
        <div className="mb-6 p-4 bg-gray-50 rounded-lg">
          <div className="text-sm text-gray-600 mb-2">Solana Address</div>
          <div className="flex items-center justify-between">
            <div className="text-sm font-mono text-gray-900 break-all flex-1">
              {address}
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleCopy('address', address)}
              className="ml-2 flex-shrink-0"
            >
              {copiedField === 'address' ? (
                <Check className="w-4 h-4 text-green-600" />
              ) : (
                <Copy className="w-4 h-4" />
              )}
            </Button>
          </div>
        </div>

        {/* Account Properties */}
        <div className="space-y-3">
          {accountDetails.slice(1).map((detail, index) => (
            <div key={index} className="flex justify-between items-center py-2">
              <div className="text-sm text-gray-600 flex-1">
                {detail.label}
                {detail.technical && (
                  <span className="ml-1 text-xs text-gray-400">(technical)</span>
                )}
              </div>
              <div className="flex items-center space-x-2">
                <div className="text-sm font-medium text-gray-900 text-right">
                  {detail.value}
                </div>
                {detail.copyable && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleCopy(detail.label, String(detail.value))}
                    className="w-6 h-6"
                  >
                    {copiedField === detail.label ? (
                      <Check className="w-3 h-3 text-green-600" />
                    ) : (
                      <Copy className="w-3 h-3" />
                    )}
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Network Information */}
        <div className="mt-6 pt-4 border-t border-gray-200">
          <div className="text-sm font-medium text-gray-700 mb-3">Network Information</div>
          <div className="grid grid-cols-2 gap-4">
            <div className="text-center p-3 bg-blue-50 rounded-lg">
              <div className="text-sm font-medium text-blue-900">Mainnet</div>
              <div className="text-xs text-blue-600">Network</div>
            </div>
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <div className="text-sm font-medium text-green-900">Active</div>
              <div className="text-xs text-green-600">Status</div>
            </div>
          </div>
        </div>

        {/* Account Type */}
        <div className="mt-4 p-3 bg-gray-50 rounded-lg">
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-600">Account Type</div>
            <div className="text-sm font-medium text-gray-900">Standard Wallet</div>
          </div>
        </div>

        {/* Last Updated */}
        <div className="mt-4 text-center">
          <div className="text-xs text-gray-500">
            Last updated: {new Date().toLocaleString()}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}