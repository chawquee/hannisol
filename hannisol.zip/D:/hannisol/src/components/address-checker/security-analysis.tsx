"use client"

import React from 'react'
import { Shield, AlertTriangle, CheckCircle, XCircle } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { getStatusColor, cn } from '@/lib/utils'

interface SecurityMetric {
  label: string
  status: 'low' | 'medium' | 'high' | 'normal' | 'flagged'
  description?: string
  icon?: React.ReactNode
}

interface SecurityAnalysisProps {
  className?: string
}

export function SecurityAnalysis({ className }: SecurityAnalysisProps) {
  const securityMetrics: SecurityMetric[] = [
    {
      label: 'Flagged',
      status: 'medium',
      description: 'Address has some activity patterns that warrant attention',
      icon: <AlertTriangle className="w-4 h-4" />
    },
    {
      label: 'Suspicious Activity',
      status: 'low',
      description: 'No suspicious transaction patterns detected',
      icon: <CheckCircle className="w-4 h-4" />
    },
    {
      label: 'Activity Score',
      status: 'normal',
      description: 'Normal transaction frequency and amounts',
      icon: <CheckCircle className="w-4 h-4" />
    }
  ]

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'low':
      case 'normal':
        return <CheckCircle className="w-4 h-4 text-green-600" />
      case 'medium':
        return <AlertTriangle className="w-4 h-4 text-yellow-600" />
      case 'high':
      case 'flagged':
        return <XCircle className="w-4 h-4 text-red-600" />
      default:
        return <Shield className="w-4 h-4 text-gray-600" />
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case 'low':
        return 'Low'
      case 'medium':
        return 'Medium'
      case 'high':
        return 'High'
      case 'normal':
        return 'Normal'
      case 'flagged':
        return 'Flagged'
      default:
        return 'Unknown'
    }
  }

  const getStatusVariant = (status: string): any => {
    switch (status) {
      case 'low':
      case 'normal':
        return 'valid'
      case 'medium':
        return 'warning'
      case 'high':
      case 'flagged':
        return 'error'
      default:
        return 'neutral'
    }
  }

  return (
    <Card className={cn("address-card animate-slide-up", className)}>
      <div className="address-card-header">
        <Shield className="w-5 h-5 text-green-500" />
        <h3 className="address-card-title">Security Analysis</h3>
      </div>
      
      <CardContent className="p-6 pt-0">
        {/* Security Metrics */}
        <div className="space-y-4 mb-6">
          {securityMetrics.map((metric, index) => (
            <div key={index} className="flex justify-between items-center py-2">
              <div className="flex items-center space-x-2 flex-1">
                {getStatusIcon(metric.status)}
                <span className="text-sm text-gray-600">{metric.label}</span>
              </div>
              <Badge variant={getStatusVariant(metric.status)}>
                {getStatusText(metric.status)}
              </Badge>
            </div>
          ))}
        </div>

        {/* Security Score */}
        <div className="mb-6 p-4 bg-green-50 rounded-lg border border-green-200">
          <div className="flex items-center justify-between mb-2">
            <div className="text-sm font-medium text-green-800">Overall Security Score</div>
            <div className="text-2xl font-bold text-green-600">75/100</div>
          </div>
          <div className="w-full bg-green-200 rounded-full h-2">
            <div 
              className="bg-green-600 h-2 rounded-full transition-all duration-500" 
              style={{ width: '75%' }}
            ></div>
          </div>
          <div className="text-xs text-green-600 mt-1">Good security rating</div>
        </div>

        {/* Security Factors */}
        <div className="space-y-3 mb-6">
          <div className="text-sm font-medium text-gray-700 mb-3">Security Factors</div>
          
          <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <span className="text-sm text-gray-700">No Known Exploits</span>
            </div>
            <Badge variant="valid">Verified</Badge>
          </div>

          <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
            <div className="flex items-center space-x-2">
              <CheckCircle className="w-4 h-4 text-green-600" />
              <span className="text-sm text-gray-700">Standard Transactions</span>
            </div>
            <Badge variant="valid">Normal</Badge>
          </div>

          <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 text-yellow-600" />
              <span className="text-sm text-gray-700">Transaction Volume</span>
            </div>
            <Badge variant="warning">Moderate</Badge>
          </div>
        </div>

        {/* Risk Indicators */}
        <div className="space-y-3">
          <div className="text-sm font-medium text-gray-700 mb-3">Risk Indicators</div>
          
          <div className="grid grid-cols-2 gap-3">
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <div className="text-lg font-bold text-green-600">0</div>
              <div className="text-xs text-gray-600">Red Flags</div>
            </div>
            <div className="text-center p-3 bg-yellow-50 rounded-lg">
              <div className="text-lg font-bold text-yellow-600">2</div>
              <div className="text-xs text-gray-600">Warnings</div>
            </div>
          </div>
        </div>

        {/* Last Security Check */}
        <div className="mt-6 pt-4 border-t border-gray-200">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Last Security Scan</span>
            <span className="font-medium text-gray-900">
              {new Date().toLocaleString()}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}