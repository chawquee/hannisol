"use client"

import React from 'react'
import { FileText, CheckCircle } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { cn } from '@/lib/utils'

interface AnalysisSummaryProps {
  address?: string
  className?: string
}

export function AnalysisSummary({ 
  address = 'DH2dr...3hxJqG2',
  className 
}: AnalysisSummaryProps) {
  
  const summaryText = `The Solana address appears to be a legitimate Solana Account with moderate activity and no suspicious behavior detected. The account has received multiple SOL tokens and conducted multiple staking transactions. Historical portfolio performance is high with moderate community engagement.`

  const keyFindings = [
    'Valid Solana address format and structure',
    'Active transaction history with normal patterns',
    'Moderate risk profile with standard security metrics',
    'Strong community engagement and positive sentiment',
    'No red flags or suspicious activities detected'
  ]

  return (
    <div className="space-y-6">
      {/* Summary Card */}
      <Card className={cn("address-card animate-slide-up", className)}>
        <div className="address-card-header">
          <FileText className="w-5 h-5 text-gray-500" />
          <h3 className="address-card-title">Summary</h3>
        </div>
        
        <CardContent className="p-6 pt-0">
          {/* Main Summary Text */}
          <p className="text-sm text-gray-600 leading-relaxed mb-6">
            {summaryText}
          </p>

          {/* Key Findings */}
          <div className="space-y-3 mb-6">
            <div className="text-sm font-medium text-gray-700 mb-3">Key Findings</div>
            {keyFindings.map((finding, index) => (
              <div key={index} className="flex items-start space-x-2">
                <CheckCircle className="w-4 h-4 text-green-500 mt-0.5 flex-shrink-0" />
                <span className="text-sm text-gray-600">{finding}</span>
              </div>
            ))}
          </div>

          {/* Analysis Statistics */}
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="text-center p-3 bg-green-50 rounded-lg">
              <div className="text-lg font-bold text-green-600">5</div>
              <div className="text-xs text-gray-600">Checks Passed</div>
            </div>
            <div className="text-center p-3 bg-yellow-50 rounded-lg">
              <div className="text-lg font-bold text-yellow-600">2</div>
              <div className="text-xs text-gray-600">Warnings</div>
            </div>
            <div className="text-center p-3 bg-red-50 rounded-lg">
              <div className="text-lg font-bold text-red-600">0</div>
              <div className="text-xs text-gray-600">Critical Issues</div>
            </div>
          </div>

          {/* Recommendation */}
          <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="text-sm font-medium text-blue-800 mb-2">Recommendation</div>
            <p className="text-sm text-blue-700">
              This address demonstrates normal usage patterns and acceptable risk levels. 
              Suitable for standard transactions with appropriate due diligence.
            </p>
          </div>

          {/* Analysis Metadata */}
          <div className="mt-6 pt-4 border-t border-gray-200">
            <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
              <div className="flex justify-between">
                <span>Analysis Date:</span>
                <span className="font-medium">{new Date().toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Analysis Time:</span>
                <span className="font-medium">{new Date().toLocaleTimeString()}</span>
              </div>
              <div className="flex justify-between">
                <span>Data Sources:</span>
                <span className="font-medium">7 Active</span>
              </div>
              <div className="flex justify-between">
                <span>Confidence:</span>
                <span className="font-medium text-green-600">92%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Brand Slogan */}
      <div className="text-center py-8">
        <p className="hannisol-slogan text-xl">
          "Hannisol's Insight, Navigating Crypto Like Hannibal Crossed the Alps."
        </p>
        <div className="mt-4 text-sm text-gray-500">
          Professional Solana address analysis powered by advanced blockchain intelligence
        </div>
      </div>
    </div>
  )
}