"use client"

import React from 'react'
import { BarChart3, ArrowUpRight, ArrowDownLeft, Repeat } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { formatDate, formatSOL, cn } from '@/lib/utils'

interface Transaction {
  id: string
  type: 'transfer' | 'receive' | 'unstake' | 'stake' | 'swap'
  amount: number
  token: string
  date: string
  status: 'success' | 'pending' | 'failed'
  direction: 'in' | 'out'
}

interface TransactionAnalysisProps {
  totalTransactions: number
  lastActivity: string
  recentTransactions: Transaction[]
  className?: string
}

const defaultTransactions: Transaction[] = [
  {
    id: '1',
    type: 'transfer',
    amount: 0.5,
    token: 'SOL',
    date: '2024/06/01',
    status: 'success',
    direction: 'out'
  },
  {
    id: '2',
    type: 'receive',
    amount: 0.3,
    token: 'SOL',
    date: '2024/06/01',
    status: 'success',
    direction: 'in'
  },
  {
    id: '3',
    type: 'unstake',
    amount: 0.25,
    token: 'SOL',
    date: '2024/12/20',
    status: 'success',
    direction: 'in'
  }
]

export function TransactionAnalysis({ 
  totalTransactions = 158,
  lastActivity = '2024/06/01',
  recentTransactions = defaultTransactions,
  className 
}: TransactionAnalysisProps) {
  
  const getTransactionIcon = (type: string) => {
    switch (type) {
      case 'transfer':
        return <ArrowUpRight className="w-4 h-4" />
      case 'receive':
        return <ArrowDownLeft className="w-4 h-4" />
      case 'unstake':
      case 'stake':
        return <Repeat className="w-4 h-4" />
      default:
        return <BarChart3 className="w-4 h-4" />
    }
  }

  const getAmountColor = (direction: string) => {
    return direction === 'out' ? 'text-red-600' : 'text-green-600'
  }

  const getAmountPrefix = (direction: string) => {
    return direction === 'out' ? '-' : '+'
  }

  return (
    <Card className={cn("address-card animate-slide-up", className)}>
      <div className="address-card-header">
        <BarChart3 className="w-5 h-5 text-purple-500" />
        <h3 className="address-card-title">Transaction Analysis</h3>
      </div>
      
      <CardContent className="p-6 pt-0">
        {/* Transaction Stats */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <div className="text-center p-4 bg-blue-50 rounded-lg">
            <div className="text-3xl font-bold text-blue-600 mb-1">
              {totalTransactions}
            </div>
            <div className="text-sm text-gray-600">Total Transactions</div>
          </div>
          <div className="text-center p-4 bg-gray-50 rounded-lg">
            <div className="text-sm text-gray-600 mb-1">Last Activity</div>
            <div className="text-sm font-medium text-gray-900">
              {formatDate(lastActivity)}
            </div>
          </div>
        </div>

        {/* Activity Timeline */}
        <div className="space-y-3 mb-6">
          <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
            <div className="text-sm font-medium text-green-800">2024/06/01</div>
            <div className="text-xs text-green-600">Last Activity</div>
          </div>
          <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="text-sm font-medium text-blue-800">2024/12/20</div>
            <div className="text-xs text-blue-600">Last Activity</div>
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="space-y-4">
          <div className="text-sm font-medium text-gray-700 mb-3">Recent Transactions</div>
          
          {recentTransactions.map((transaction) => (
            <div key={transaction.id} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className={cn(
                  "w-8 h-8 rounded-full flex items-center justify-center",
                  transaction.direction === 'out' ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'
                )}>
                  {getTransactionIcon(transaction.type)}
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-900 capitalize">
                    {transaction.type}
                  </div>
                  <div className="text-xs text-gray-500">
                    {transaction.type === 'transfer' && 'SOL Sent'}
                    {transaction.type === 'receive' && 'Token Received'}
                    {transaction.type === 'unstake' && 'SOL Staking'}
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className={cn(
                  "text-sm font-medium",
                  getAmountColor(transaction.direction)
                )}>
                  {getAmountPrefix(transaction.direction)}{formatSOL(transaction.amount)}
                </div>
                <div className="text-xs text-gray-500">
                  {formatDate(transaction.date)}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Transaction Summary */}
        <div className="mt-6 pt-4 border-t border-gray-200">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-lg font-bold text-green-600">
                +{(recentTransactions.filter(t => t.direction === 'in').length)}
              </div>
              <div className="text-xs text-gray-500">Incoming</div>
            </div>
            <div>
              <div className="text-lg font-bold text-red-600">
                -{(recentTransactions.filter(t => t.direction === 'out').length)}
              </div>
              <div className="text-xs text-gray-500">Outgoing</div>
            </div>
            <div>
              <div className="text-lg font-bold text-gray-900">
                {recentTransactions.filter(t => t.status === 'success').length}
              </div>
              <div className="text-xs text-gray-500">Successful</div>
            </div>
          </div>
        </div>

        {/* Activity Pattern */}
        <div className="mt-4 p-3 bg-purple-50 rounded-lg border border-purple-200">
          <div className="flex items-center justify-between">
            <div className="text-sm text-purple-800">Activity Pattern</div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
              <span className="text-sm font-medium text-purple-700">Regular User</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}