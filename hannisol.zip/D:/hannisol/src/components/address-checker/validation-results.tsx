"use client"

import React from 'react'
import { CheckCircle, XCircle } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { cn } from '@/lib/utils'

interface ValidationResult {
  label: string
  status: 'valid' | 'invalid'
  value?: string
}

interface ValidationResultsProps {
  address: string
  isValid: boolean
  className?: string
}

export function ValidationResults({ address, isValid, className }: ValidationResultsProps) {
  const validationChecks: ValidationResult[] = [
    {
      label: 'Valid',
      status: isValid ? 'valid' : 'invalid'
    },
    {
      label: 'Format',
      status: 'valid',
      value: 'Base58'
    },
    {
      label: 'Length',
      status: 'valid',
      value: '44 characters'
    },
    {
      label: 'Type',
      status: 'valid',
      value: 'Wallet address'
    }
  ]

  return (
    <Card className={cn("address-card animate-slide-up", className)}>
      <div className="address-card-header">
        <CheckCircle className="w-5 h-5 text-green-500" />
        <h3 className="address-card-title">Address Validation</h3>
      </div>
      
      <CardContent className="p-6 pt-0">
        <div className="space-y-3">
          {validationChecks.map((check, index) => (
            <div key={index} className="flex items-center space-x-3">
              {check.status === 'valid' ? (
                <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
              ) : (
                <XCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
              )}
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <span className="font-medium">{check.label}:</span>
                {check.value && <span>{check.value}</span>}
                {!check.value && (
                  <span className={check.status === 'valid' ? 'text-green-600' : 'text-red-600'}>
                    {check.status === 'valid' ? 'Yes' : 'No'}
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>

        {/* Success Alert */}
        <Alert variant="valid" className="mt-4">
          <CheckCircle className="w-4 h-4" />
          <AlertDescription className="font-medium">
            Valid Solana address
          </AlertDescription>
        </Alert>

        {/* Address Details */}
        <div className="mt-4 p-3 bg-gray-50 rounded-lg">
          <div className="text-xs text-gray-500 mb-1">Address</div>
          <div className="text-sm font-mono text-gray-900 break-all">
            {address}
          </div>
        </div>

        {/* Additional Validation Info */}
        <div className="mt-4 space-y-2">
          <div className="flex justify-between items-center text-sm">
            <span className="text-gray-600">Network</span>
            <span className="font-medium text-gray-900">Solana Mainnet</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-gray-600">Address Type</span>
            <span className="font-medium text-gray-900">Ed25519 Public Key</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-gray-600">Encoding</span>
            <span className="font-medium text-gray-900">Base58</span>
          </div>
          <div className="flex justify-between items-center text-sm">
            <span className="text-gray-600">Validation Time</span>
            <span className="font-medium text-gray-900">
              {new Date().toLocaleTimeString()}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}