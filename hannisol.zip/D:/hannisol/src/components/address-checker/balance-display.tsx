"use client"

import React from 'react'
import { TrendingUp, Coins, ImageIcon } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { formatSOL, formatCurrency, formatNumber, cn } from '@/lib/utils'

interface TokenHolding {
  symbol: string
  amount: number
  name?: string
  logo?: string
}

interface BalanceDisplayProps {
  solBalance: number
  usdValue: number
  tokens: TokenHolding[]
  nftCount: number
  className?: string
}

export function BalanceDisplay({ 
  solBalance = 1.25, 
  usdValue = 127.89, 
  tokens = [
    { symbol: 'USDC', amount: 2, name: 'USD Coin' }
  ],
  nftCount = 3,
  className 
}: BalanceDisplayProps) {
  return (
    <Card className={cn("address-card animate-slide-up", className)}>
      <div className="address-card-header">
        <TrendingUp className="w-5 h-5 text-blue-500" />
        <h3 className="address-card-title">Balance & Holdings</h3>
      </div>
      
      <CardContent className="p-6 pt-0">
        {/* SOL Balance */}
        <div className="mb-6">
          <div className="text-sm text-gray-600 mb-1">SOL Balance</div>
          <div className="text-3xl font-bold text-blue-600 mb-1">
            {formatSOL(solBalance)}
          </div>
          <div className="text-sm text-gray-500">
            {formatCurrency(usdValue)}
          </div>
          
          {/* Price change indicator */}
          <div className="flex items-center mt-2 space-x-2">
            <div className="flex items-center text-green-600 text-sm">
              <TrendingUp className="w-3 h-3 mr-1" />
              <span>+2.4%</span>
            </div>
            <span className="text-gray-400 text-sm">24h</span>
          </div>
        </div>

        {/* Token Holdings */}
        <div className="space-y-4">
          <div className="text-sm font-medium text-gray-700 mb-3">Token Holdings</div>
          
          {/* Token List */}
          {tokens.map((token, index) => (
            <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                  <Coins className="w-4 h-4 text-blue-600" />
                </div>
                <div>
                  <div className="text-sm font-medium text-gray-900">{token.symbol}</div>
                  {token.name && (
                    <div className="text-xs text-gray-500">{token.name}</div>
                  )}
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm font-medium text-gray-900">
                  {formatNumber(token.amount)}
                </div>
                <div className="text-xs text-gray-500">Tokens</div>
              </div>
            </div>
          ))}

          {/* NFTs */}
          <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                <ImageIcon className="w-4 h-4 text-purple-600" />
              </div>
              <div>
                <div className="text-sm font-medium text-gray-900">NFTs</div>
                <div className="text-xs text-gray-500">Non-Fungible Tokens</div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-sm font-medium text-gray-900">
                {nftCount}
              </div>
              <div className="text-xs text-gray-500">Items</div>
            </div>
          </div>
        </div>

        {/* Portfolio Summary */}
        <div className="mt-6 pt-4 border-t border-gray-200">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-lg font-bold text-gray-900">
                {formatCurrency(usdValue)}
              </div>
              <div className="text-xs text-gray-500">Total Value</div>
            </div>
            <div>
              <div className="text-lg font-bold text-gray-900">
                {tokens.length + 1}
              </div>
              <div className="text-xs text-gray-500">Token Types</div>
            </div>
            <div>
              <div className="text-lg font-bold text-gray-900">
                {nftCount}
              </div>
              <div className="text-xs text-gray-500">NFTs</div>
            </div>
          </div>
        </div>

        {/* Activity Indicator */}
        <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-center justify-between">
            <div className="text-sm text-blue-800">Portfolio Status</div>
            <div className="flex items-center space-x-2">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span className="text-sm font-medium text-green-700">Active</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}