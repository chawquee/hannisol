"use client"

import React, { useState } from 'react'
import { Search } from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { cn, isValidSolanaAddress } from '@/lib/utils'

interface AddressInputProps {
  onAddressCheck: (address: string) => void
  isLoading?: boolean
  className?: string
}

export function AddressInput({ onAddressCheck, isLoading = false, className }: AddressInputProps) {
  const [address, setAddress] = useState('DH2dr...3hxJqG2')
  const [isValid, setIsValid] = useState(false)

  const handleAddressChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.trim()
    setAddress(value)
    setIsValid(isValidSolanaAddress(value))
  }

  const handleCheck = () => {
    if (isValid && address) {
      onAddressCheck(address)
    }
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && isValid && !isLoading) {
      handleCheck()
    }
  }

  return (
    <Card className={cn("address-card", className)}>
      <CardContent className="p-6">
        <div className="flex space-x-4">
          <div className="relative flex-1">
            <Input
              type="text"
              value={address}
              onChange={handleAddressChange}
              onKeyPress={handleKeyPress}
              placeholder="Enter Solana address..."
              className={cn(
                "address-input pr-10",
                isValid ? "ring-2 ring-green-500 border-green-500" : 
                address && !isValid ? "ring-2 ring-red-500 border-red-500" : ""
              )}
              disabled={isLoading}
            />
            <div className="absolute inset-y-0 right-0 flex items-center pr-3">
              {address && (
                <div
                  className={cn(
                    "w-2 h-2 rounded-full",
                    isValid ? "bg-green-500" : "bg-red-500"
                  )}
                />
              )}
            </div>
          </div>
          <Button
            onClick={handleCheck}
            disabled={!isValid || isLoading}
            variant="default"
            size="lg"
            className="btn-primary min-w-[140px]"
          >
            {isLoading ? (
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                <span>Checking...</span>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Search className="w-4 h-4" />
                <span>Check Address</span>
              </div>
            )}
          </Button>
        </div>
        
        {/* Address validation hints */}
        {address && !isValid && (
          <div className="mt-3 text-sm text-red-600">
            Please enter a valid Solana address (32-44 characters, Base58 format)
          </div>
        )}
        
        {/* Example addresses */}
        <div className="mt-4 space-y-2">
          <div className="text-sm text-gray-600">Try these example addresses:</div>
          <div className="flex flex-wrap gap-2">
            {[
              'DH2dr...3hxJqG2',
              '9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM',
              'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v'
            ].map((exampleAddress) => (
              <button
                key={exampleAddress}
                onClick={() => {
                  setAddress(exampleAddress)
                  setIsValid(isValidSolanaAddress(exampleAddress))
                }}
                className="px-2 py-1 text-xs bg-gray-100 text-gray-700 rounded hover:bg-gray-200 transition-colors"
                disabled={isLoading}
              >
                {exampleAddress}
              </button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}