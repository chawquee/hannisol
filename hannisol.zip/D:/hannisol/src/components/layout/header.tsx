"use client"

import React from 'react'
import { Menu, X } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

interface HeaderProps {
  className?: string
}

export function Header({ className }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = React.useState(false)

  return (
    <header className={cn("bg-white border-b border-gray-200 sticky top-0 z-50", className)}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-4">
            {/* Hannisol Logo */}
            <div className="hannisol-logo">
              <div className="hannisol-logo-h">H</div>
              <div className="hannisol-logo-accent-1"></div>
              <div className="hannisol-logo-accent-2"></div>
              <div className="hannisol-logo-accent-3"></div>
            </div>
            
            {/* Brand Text */}
            <div className="hidden sm:block">
              <h1 className="hannisol-logo-text text-2xl">HANNISOL</h1>
              <h2 className="text-lg text-gray-700 font-medium">Solana Address Checker</h2>
              <p className="text-sm text-gray-500 hidden lg:block">
                Comprehensive validation and analysis for Solana addresses
              </p>
            </div>
          </div>

          {/* Navigation - Desktop */}
          <nav className="hidden md:flex items-center space-x-6">
            <a 
              href="#checker" 
              className="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium"
            >
              Address Checker
            </a>
            <a 
              href="#about" 
              className="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium"
            >
              About
            </a>
            <a 
              href="#api" 
              className="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium"
            >
              API
            </a>
            <a 
              href="#support" 
              className="text-gray-600 hover:text-gray-900 transition-colors text-sm font-medium"
            >
              Support
            </a>
          </nav>

          {/* Action Buttons - Desktop */}
          <div className="hidden md:flex items-center space-x-3">
            <Button variant="outline" size="sm">
              Documentation
            </Button>
            <Button variant="hannisol" size="sm">
              Premium
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-gray-600"
            >
              {isMenuOpen ? (
                <X className="w-5 h-5" />
              ) : (
                <Menu className="w-5 h-5" />
              )}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-200 py-4 space-y-3">
            <a 
              href="#checker" 
              className="block px-3 py-2 text-gray-600 hover:text-gray-900 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Address Checker
            </a>
            <a 
              href="#about" 
              className="block px-3 py-2 text-gray-600 hover:text-gray-900 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              About
            </a>
            <a 
              href="#api" 
              className="block px-3 py-2 text-gray-600 hover:text-gray-900 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              API
            </a>
            <a 
              href="#support" 
              className="block px-3 py-2 text-gray-600 hover:text-gray-900 transition-colors"
              onClick={() => setIsMenuOpen(false)}
            >
              Support
            </a>
            <div className="flex space-x-3 px-3 pt-3 border-t border-gray-200">
              <Button variant="outline" size="sm" className="flex-1">
                Documentation
              </Button>
              <Button variant="hannisol" size="sm" className="flex-1">
                Premium
              </Button>
            </div>
          </div>
        )}
      </div>
    </header>
  )
}