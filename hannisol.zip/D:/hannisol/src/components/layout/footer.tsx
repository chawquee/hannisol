"use client"

import React from 'react'
import Link from 'next/link'
import { Github, Twitter, Linkedin, Mail, ExternalLink } from 'lucide-react'
import { Separator } from '@/components/ui/separator'
import { cn } from '@/lib/utils'

interface FooterProps {
  className?: string
}

export function Footer({ className }: FooterProps) {
  const currentYear = new Date().getFullYear()

  const footerLinks = {
    product: [
      { name: 'Address Checker', href: '/' },
      { name: 'API Documentation', href: '/docs' },
      { name: 'Premium Features', href: '/premium' },
      { name: 'Pricing', href: '/pricing' }
    ],
    company: [
      { name: 'About Hannisol', href: '/about' },
      { name: 'Blog', href: '/blog' },
      { name: 'Careers', href: '/careers' },
      { name: 'Contact', href: '/contact' }
    ],
    resources: [
      { name: 'Help Center', href: '/help' },
      { name: 'Security', href: '/security' },
      { name: 'Status', href: '/status' },
      { name: 'Changelog', href: '/changelog' }
    ],
    legal: [
      { name: 'Privacy Policy', href: '/privacy' },
      { name: 'Terms of Service', href: '/terms' },
      { name: 'Cookie Policy', href: '/cookies' },
      { name: 'GDPR', href: '/gdpr' }
    ]
  }

  const socialLinks = [
    { name: 'GitHub', icon: Github, href: 'https://github.com/hannisol' },
    { name: 'Twitter', icon: Twitter, href: 'https://twitter.com/hannisol' },
    { name: 'LinkedIn', icon: Linkedin, href: 'https://linkedin.com/company/hannisol' },
    { name: 'Email', icon: Mail, href: 'mailto:contact@hannisol.com' }
  ]

  return (
    <footer className={cn("bg-gray-50 border-t border-gray-200", className)}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-8">
          {/* Brand Section */}
          <div className="lg:col-span-2">
            {/* Logo and Brand */}
            <div className="flex items-center space-x-3 mb-4">
              <div className="hannisol-logo">
                <div className="hannisol-logo-h">H</div>
                <div className="hannisol-logo-accent-1"></div>
                <div className="hannisol-logo-accent-2"></div>
                <div className="hannisol-logo-accent-3"></div>
              </div>
              <div>
                <h3 className="hannisol-logo-text text-xl">HANNISOL</h3>
                <p className="text-sm text-gray-600">Solana Address Checker</p>
              </div>
            </div>
            
            {/* Brand Description */}
            <p className="text-gray-600 text-sm mb-4 max-w-md">
              Professional Solana address validation and analysis tool. Navigate the crypto 
              landscape with confidence using comprehensive blockchain intelligence.
            </p>
            
            {/* Brand Slogan */}
            <p className="hannisol-slogan text-sm text-gray-700 mb-6">
              "Hannisol's Insight, Navigating Crypto Like Hannibal Crossed the Alps."
            </p>

            {/* Social Links */}
            <div className="flex space-x-4">
              {socialLinks.map((social) => (
                <a
                  key={social.name}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-gray-500 hover:text-gray-700 transition-colors"
                  aria-label={social.name}
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Product Links */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-4">Product</h4>
            <ul className="space-y-3">
              {footerLinks.product.map((link) => (
                <li key={link.name}>
                  <Link 
                    href={link.href}
                    className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company Links */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-4">Company</h4>
            <ul className="space-y-3">
              {footerLinks.company.map((link) => (
                <li key={link.name}>
                  <Link 
                    href={link.href}
                    className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources Links */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-4">Resources</h4>
            <ul className="space-y-3">
              {footerLinks.resources.map((link) => (
                <li key={link.name}>
                  <Link 
                    href={link.href}
                    className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Links */}
          <div>
            <h4 className="text-sm font-semibold text-gray-900 mb-4">Legal</h4>
            <ul className="space-y-3">
              {footerLinks.legal.map((link) => (
                <li key={link.name}>
                  <Link 
                    href={link.href}
                    className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <Separator className="my-8" />

        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="flex flex-col md:flex-row items-center space-y-2 md:space-y-0 md:space-x-6">
            <p className="text-sm text-gray-600">
              © {currentYear} Hannisol. All rights reserved.
            </p>
            <div className="flex items-center space-x-4 text-sm text-gray-500">
              <span>Made with ❤️ for the Solana community</span>
            </div>
          </div>

          {/* Additional Info */}
          <div className="flex items-center space-x-4 text-sm text-gray-500">
            <div className="flex items-center space-x-1">
              <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
              <span>All systems operational</span>
            </div>
            <a 
              href="https://solana.com" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center space-x-1 hover:text-gray-700 transition-colors"
            >
              <span>Powered by Solana</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>

        {/* Cookie Notice */}
        <div className="mt-6 p-3 bg-blue-50 rounded-lg border border-blue-200">
          <p className="text-sm text-blue-800">
            We use cookies to enhance your experience and analyze site usage. 
            <Link href="/cookies" className="underline hover:no-underline ml-1">
              Learn more about our cookie policy
            </Link>
          </p>
        </div>
      </div>
    </footer>
  )
}