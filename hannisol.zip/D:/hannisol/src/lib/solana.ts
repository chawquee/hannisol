import { Connection, PublicKey, LAMPORTS_PER_SOL } from '@solana/web3.js'
import { SOLANA_CONFIG, WELL_KNOWN_ADDRESSES } from './constants'

// Initialize Solana connection
export function createSolanaConnection(network: 'mainnet' | 'devnet' | 'testnet' = 'mainnet') {
  const config = SOLANA_CONFIG[network]
  return new Connection(config.rpc, 'confirmed')
}

// Default connection
export const connection = createSolanaConnection('mainnet')

// Address validation utilities
export function isValidSolanaAddress(address: string): boolean {
  try {
    new PublicKey(address)
    return true
  } catch {
    return false
  }
}

export function isValidBase58(str: string): boolean {
  const base58Regex = /^[1-9A-HJ-NP-Za-km-z]+$/
  return base58Regex.test(str)
}

export function validateAddressFormat(address: string): {
  isValid: boolean
  errors: string[]
  format: string
  length: number
} {
  const errors: string[] = []
  
  if (!address || address.trim().length === 0) {
    errors.push('Address is required')
    return { isValid: false, errors, format: 'unknown', length: 0 }
  }

  const trimmedAddress = address.trim()
  
  if (trimmedAddress.length < 32) {
    errors.push('Address too short (minimum 32 characters)')
  }
  
  if (trimmedAddress.length > 44) {
    errors.push('Address too long (maximum 44 characters)')
  }
  
  if (!isValidBase58(trimmedAddress)) {
    errors.push('Invalid Base58 characters')
  }
  
  const isValid = isValidSolanaAddress(trimmedAddress)
  if (!isValid && errors.length === 0) {
    errors.push('Invalid Solana address format')
  }

  return {
    isValid: isValid && errors.length === 0,
    errors,
    format: 'Base58',
    length: trimmedAddress.length
  }
}

// Balance utilities
export function lamportsToSol(lamports: number): number {
  return lamports / LAMPORTS_PER_SOL
}

export function solToLamports(sol: number): number {
  return Math.floor(sol * LAMPORTS_PER_SOL)
}

export async function getAccountBalance(address: string): Promise<{
  sol: number
  lamports: number
  exists: boolean
}> {
  try {
    const publicKey = new PublicKey(address)
    const balance = await connection.getBalance(publicKey)
    
    return {
      sol: lamportsToSol(balance),
      lamports: balance,
      exists: balance > 0
    }
  } catch (error) {
    console.error('Error fetching balance:', error)
    return {
      sol: 0,
      lamports: 0,
      exists: false
    }
  }
}

// Account info utilities
export async function getAccountInfo(address: string) {
  try {
    const publicKey = new PublicKey(address)
    const accountInfo = await connection.getAccountInfo(publicKey)
    
    if (!accountInfo) {
      return {
        exists: false,
        executable: false,
        owner: null,
        lamports: 0,
        dataSize: 0,
        rentEpoch: null
      }
    }

    return {
      exists: true,
      executable: accountInfo.executable,
      owner: accountInfo.owner.toString(),
      lamports: accountInfo.lamports,
      dataSize: accountInfo.data.length,
      rentEpoch: accountInfo.rentEpoch
    }
  } catch (error) {
    console.error('Error fetching account info:', error)
    throw new Error('Failed to fetch account information')
  }
}

// Transaction utilities
export async function getTransactionHistory(
  address: string, 
  limit: number = 50
): Promise<any[]> {
  try {
    const publicKey = new PublicKey(address)
    const signatures = await connection.getSignaturesForAddress(
      publicKey,
      { limit }
    )
    
    // Get detailed transaction info
    const transactions = await Promise.all(
      signatures.map(async (sig) => {
        try {
          const tx = await connection.getTransaction(sig.signature, {
            commitment: 'confirmed',
            maxSupportedTransactionVersion: 0
          })
          
          return {
            signature: sig.signature,
            slot: sig.slot,
            blockTime: sig.blockTime,
            confirmationStatus: sig.confirmationStatus,
            err: sig.err,
            memo: sig.memo,
            transaction: tx
          }
        } catch (error) {
          console.error(`Error fetching transaction ${sig.signature}:`, error)
          return null
        }
      })
    )
    
    return transactions.filter(tx => tx !== null)
  } catch (error) {
    console.error('Error fetching transaction history:', error)
    return []
  }
}

// Token utilities
export async function getTokenAccounts(address: string) {
  try {
    const publicKey = new PublicKey(address)
    const tokenAccounts = await connection.getParsedTokenAccountsByOwner(
      publicKey,
      { programId: new PublicKey(WELL_KNOWN_ADDRESSES.TOKEN_PROGRAM) }
    )
    
    return tokenAccounts.value.map(account => ({
      pubkey: account.pubkey.toString(),
      account: account.account,
      mint: account.account.data.parsed.info.mint,
      tokenAmount: account.account.data.parsed.info.tokenAmount,
      owner: account.account.data.parsed.info.owner
    }))
  } catch (error) {
    console.error('Error fetching token accounts:', error)
    return []
  }
}

// Program utilities
export function identifyProgram(programId: string): string {
  const knownPrograms: Record<string, string> = {
    [WELL_KNOWN_ADDRESSES.SYSTEM_PROGRAM]: 'System Program',
    [WELL_KNOWN_ADDRESSES.TOKEN_PROGRAM]: 'Token Program',
    [WELL_KNOWN_ADDRESSES.ASSOCIATED_TOKEN_PROGRAM]: 'Associated Token Program',
    [WELL_KNOWN_ADDRESSES.SERUM_DEX]: 'Serum DEX',
    [WELL_KNOWN_ADDRESSES.RAYDIUM]: 'Raydium',
    [WELL_KNOWN_ADDRESSES.ORCA]: 'Orca'
  }
  
  return knownPrograms[programId] || 'Unknown Program'
}

// Address type detection
export function detectAddressType(address: string): 'wallet' | 'program' | 'token_account' | 'unknown' {
  if (Object.values(WELL_KNOWN_ADDRESSES).includes(address)) {
    return 'program'
  }
  
  // More sophisticated detection would require checking account data
  // For now, assume wallet addresses
  return 'wallet'
}

// Network utilities
export function getExplorerUrl(address: string, network: 'mainnet' | 'devnet' | 'testnet' = 'mainnet'): string {
  const baseUrl = SOLANA_CONFIG[network].explorer
  return `${baseUrl}/address/${address}`
}

export function getTransactionUrl(signature: string, network: 'mainnet' | 'devnet' | 'testnet' = 'mainnet'): string {
  const baseUrl = SOLANA_CONFIG[network].explorer
  return `${baseUrl}/tx/${signature}`
}

// RPC health check
export async function checkRpcHealth(): Promise<{
  healthy: boolean
  latency: number
  version?: string
  error?: string
}> {
  const startTime = Date.now()
  
  try {
    const version = await connection.getVersion()
    const latency = Date.now() - startTime
    
    return {
      healthy: true,
      latency,
      version: version['solana-core']
    }
  } catch (error) {
    return {
      healthy: false,
      latency: Date.now() - startTime,
      error: error instanceof Error ? error.message : 'Unknown error'
    }
  }
}

// Batch operations
export async function batchGetMultipleAccounts(addresses: string[]) {
  try {
    const publicKeys = addresses.map(addr => new PublicKey(addr))
    const accountInfos = await connection.getMultipleAccountsInfo(publicKeys)
    
    return addresses.map((address, index) => ({
      address,
      accountInfo: accountInfos[index]
    }))
  } catch (error) {
    console.error('Error in batch account fetch:', error)
    return addresses.map(address => ({
      address,
      accountInfo: null
    }))
  }
}

// Subscription utilities (for real-time updates)
export function subscribeToAccount(
  address: string,
  callback: (accountInfo: any) => void
): number {
  try {
    const publicKey = new PublicKey(address)
    return connection.onAccountChange(publicKey, callback, 'confirmed')
  } catch (error) {
    console.error('Error subscribing to account:', error)
    return -1
  }
}

export function unsubscribeFromAccount(subscriptionId: number) {
  try {
    connection.removeAccountChangeListener(subscriptionId)
  } catch (error) {
    console.error('Error unsubscribing from account:', error)
  }
}

// Error handling utilities
export function handleSolanaError(error: any): string {
  if (error.message) {
    // Common Solana RPC errors
    if (error.message.includes('Invalid public key')) {
      return 'Invalid Solana address format'
    }
    if (error.message.includes('AccountNotFound')) {
      return 'Account not found on the blockchain'
    }
    if (error.message.includes('Connection refused')) {
      return 'Unable to connect to Solana network'
    }
    if (error.message.includes('timeout')) {
      return 'Request timeout - please try again'
    }
    
    return error.message
  }
  
  return 'Unknown Solana RPC error'
}