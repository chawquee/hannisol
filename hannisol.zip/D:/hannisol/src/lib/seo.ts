import { Metadata } from 'next'
import { SITE_CONFIG, SEO_CONFIG } from './constants'

// Base SEO Configuration
export function createSEOConfig(options: {
  title?: string
  description?: string
  keywords?: string[]
  image?: string
  url?: string
  type?: 'website' | 'article'
  noIndex?: boolean
  canonicalUrl?: string
}): Metadata {
  const {
    title = SEO_CONFIG.default_title,
    description = SEO_CONFIG.default_description,
    keywords = SITE_CONFIG.keywords,
    image = SEO_CONFIG.default_image,
    url = SITE_CONFIG.url,
    type = 'website',
    noIndex = false,
    canonicalUrl
  } = options

  const formattedTitle = title === SEO_CONFIG.default_title 
    ? title 
    : `${title} | ${SITE_CONFIG.name}`

  return {
    title: formattedTitle,
    description: truncateDescription(description),
    keywords: keywords.join(', '),
    authors: [{ name: 'Hannisol Team' }],
    creator: 'Hannisol',
    publisher: 'Hannisol',
    robots: noIndex ? 'noindex,nofollow' : 'index,follow',
    
    // Open Graph
    openGraph: {
      title: formattedTitle,
      description: truncateDescription(description),
      url,
      siteName: SITE_CONFIG.name,
      images: [
        {
          url: image,
          width: 1200,
          height: 630,
          alt: formattedTitle,
        }
      ],
      locale: SEO_CONFIG.locale,
      type,
    },

    // Twitter Card
    twitter: {
      card: 'summary_large_image',
      title: formattedTitle,
      description: truncateDescription(description),
      images: [image],
      creator: SEO_CONFIG.twitter_handle,
    },

    // Canonical URL
    alternates: {
      canonical: canonicalUrl || url,
    },

    // Additional metadata
    category: 'Technology',
    classification: 'Cryptocurrency Tools',
    referrer: 'origin-when-cross-origin',
  }
}

// Page-specific SEO configurations
export const seoConfigs = {
  home: createSEOConfig({
    title: 'Professional Solana Address Checker & Analysis Tool',
    description: 'Validate and analyze any Solana address with professional-grade security assessment, risk analysis, and community insights. Free address checker with instant results.',
    keywords: [
      'solana address checker',
      'solana address validator',
      'crypto address analysis',
      'solana wallet checker',
      'blockchain security',
      'crypto risk assessment'
    ]
  }),

  about: createSEOConfig({
    title: 'About Hannisol - Professional Solana Analysis Platform',
    description: 'Learn about Hannisol\'s mission to provide professional Solana address validation and security analysis tools. Navigate crypto like Hannibal crossed the Alps.',
    keywords: [
      'about hannisol',
      'solana security platform',
      'blockchain analysis tools',
      'crypto security company'
    ]
  }),

  docs: createSEOConfig({
    title: 'API Documentation - Hannisol Developer Guide',
    description: 'Complete API documentation for Hannisol Solana Address Checker. Integrate professional address validation and analysis into your applications.',
    keywords: [
      'hannisol api',
      'solana api documentation',
      'address validation api',
      'blockchain developer tools',
      'crypto api integration'
    ]
  }),

  privacy: createSEOConfig({
    title: 'Privacy Policy - Data Protection & Security',
    description: 'Learn how Hannisol protects your privacy and handles data in our Solana address checker platform. Transparent privacy practices.',
    keywords: [
      'privacy policy',
      'data protection',
      'hannisol privacy',
      'crypto privacy'
    ]
  }),

  terms: createSEOConfig({
    title: 'Terms of Service - Legal Agreement',
    description: 'Terms of Service and legal agreement for using Hannisol Solana address checker platform and services.',
    keywords: [
      'terms of service',
      'user agreement',
      'hannisol terms',
      'legal agreement'
    ]
  })
}

// Dynamic SEO for address pages
export function createAddressSEO(address: string, isValid: boolean): Metadata {
  const truncatedAddress = truncateAddress(address)
  
  if (!isValid) {
    return createSEOConfig({
      title: `Invalid Address: ${truncatedAddress}`,
      description: `The Solana address ${truncatedAddress} appears to be invalid. Use Hannisol to validate and analyze Solana addresses with professional security assessment.`,
      noIndex: true
    })
  }

  return createSEOConfig({
    title: `Solana Address Analysis: ${truncatedAddress}`,
    description: `Complete analysis of Solana address ${truncatedAddress} including balance, security assessment, risk analysis, and transaction history. Professional blockchain insights.`,
    keywords: [
      'solana address analysis',
      'blockchain security check',
      'crypto address validation',
      `solana ${truncatedAddress}`,
      'address risk assessment'
    ],
    url: `${SITE_CONFIG.url}/address/${address}`
  })
}

// Utility functions
function truncateDescription(description: string, maxLength: number = 160): string {
  if (description.length <= maxLength) return description
  return description.substring(0, maxLength - 3) + '...'
}

function truncateAddress(address: string, chars: number = 8): string {
  if (address.length <= chars * 2 + 3) return address
  return `${address.slice(0, chars)}...${address.slice(-chars)}`
}

// Structured Data Generators
export function generateWebsiteStructuredData() {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name: SITE_CONFIG.name,
    description: SITE_CONFIG.description,
    url: SITE_CONFIG.url,
    potentialAction: {
      '@type': 'SearchAction',
      target: {
        '@type': 'EntryPoint',
        urlTemplate: `${SITE_CONFIG.url}/?address={search_term_string}`
      },
      'query-input': 'required name=search_term_string'
    },
    publisher: {
      '@type': 'Organization',
      name: SITE_CONFIG.name,
      url: SITE_CONFIG.url,
      logo: `${SITE_CONFIG.url}/logo.png`
    }
  }
}

export function generateOrganizationStructuredData() {
  return {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name: SITE_CONFIG.name,
    description: SITE_CONFIG.description,
    url: SITE_CONFIG.url,
    logo: `${SITE_CONFIG.url}/logo.png`,
    sameAs: [
      'https://twitter.com/hannisol',
      'https://github.com/hannisol',
      'https://linkedin.com/company/hannisol'
    ],
    contactPoint: {
      '@type': 'ContactPoint',
      contactType: 'Customer Service',
      email: 'support@hannisol.com',
      availableLanguage: ['English']
    }
  }
}

export function generateWebApplicationStructuredData() {
  return {
    '@context': 'https://schema.org',
    '@type': 'WebApplication',
    name: SITE_CONFIG.name,
    description: SITE_CONFIG.description,
    url: SITE_CONFIG.url,
    applicationCategory: 'FinanceApplication',
    operatingSystem: 'Web Browser',
    browserRequirements: 'Requires JavaScript. Requires HTML5.',
    permissions: 'No special permissions required',
    offers: {
      '@type': 'Offer',
      price: '0',
      priceCurrency: 'USD',
      availability: 'https://schema.org/InStock'
    },
    creator: {
      '@type': 'Organization',
      name: SITE_CONFIG.name
    },
    applicationSubCategory: 'Cryptocurrency Tools',
    featureList: [
      'Solana Address Validation',
      'Security Assessment',
      'Risk Analysis',
      'Balance Tracking',
      'Transaction Analysis',
      'Community Insights'
    ]
  }
}

export function generateBreadcrumbStructuredData(items: Array<{ name: string; url: string }>) {
  return {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: item.url
    }))
  }
}

export function generateFAQStructuredData(faqs: Array<{ question: string; answer: string }>) {
  return {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: faqs.map(faq => ({
      '@type': 'Question',
      name: faq.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: faq.answer
      }
    }))
  }
}

// SEO Analysis Tools
export function analyzeSEO(config: Metadata) {
  const issues: string[] = []
  const suggestions: string[] = []

  // Title analysis
  if (typeof config.title === 'string') {
    if (config.title.length < 30) {
      suggestions.push('Title could be longer for better SEO (30-60 characters recommended)')
    }
    if (config.title.length > 60) {
      issues.push('Title is too long and may be truncated in search results')
    }
  }

  // Description analysis
  if (typeof config.description === 'string') {
    if (config.description.length < 120) {
      suggestions.push('Description could be longer for better CTR (120-160 characters recommended)')
    }
    if (config.description.length > 160) {
      issues.push('Description is too long and may be truncated in search results')
    }
  }

  // Keywords analysis
  if (typeof config.keywords === 'string') {
    const keywordCount = config.keywords.split(',').length
    if (keywordCount < 3) {
      suggestions.push('Consider adding more relevant keywords')
    }
    if (keywordCount > 10) {
      suggestions.push('Too many keywords may dilute SEO value')
    }
  }

  return { issues, suggestions }
}

// Sitemap generation helpers
export function generateSitemapEntry(url: string, lastModified?: Date, changeFreq?: string, priority?: number) {
  return {
    url,
    lastModified: lastModified || new Date(),
    changefreq: changeFreq || 'weekly',
    priority: priority || 0.5
  }
}

export const sitemapEntries = [
  generateSitemapEntry(SITE_CONFIG.url, new Date(), 'daily', 1.0),
  generateSitemapEntry(`${SITE_CONFIG.url}/about`, new Date(), 'weekly', 0.8),
  generateSitemapEntry(`${SITE_CONFIG.url}/docs`, new Date(), 'weekly', 0.9),
  generateSitemapEntry(`${SITE_CONFIG.url}/privacy`, new Date(), 'monthly', 0.3),
  generateSitemapEntry(`${SITE_CONFIG.url}/terms`, new Date(), 'monthly', 0.3)
]