// Hannisol Application Constants

// Site Configuration
export const SITE_CONFIG = {
  name: 'Hannisol',
  fullName: 'Hannisol - Solana Address Checker',
  description: 'Professional Solana address validation and analysis tool with comprehensive security assessment and risk analysis.',
  url: process.env.NEXT_PUBLIC_SITE_URL || 'https://hannisol.com',
  slogan: "Hannisol's Insight, Navigating Crypto Like Hannibal Crossed the Alps.",
  keywords: [
    'Solana address checker',
    'Solana address validator', 
    'crypto address analysis',
    'blockchain security',
    'Solana wallet checker',
    'crypto risk assessment',
    'DeFi security',
    'smart contract analysis'
  ]
} as const

// Brand Colors (matching Tailwind config)
export const BRAND_COLORS = {
  gold: {
    50: '#fefce8',
    100: '#fef3c7',
    200: '#fde68a', 
    300: '#fcd34d',
    400: '#fbbf24',
    500: '#f59e0b', // Primary gold
    600: '#d97706',
    700: '#b45309',
    800: '#92400e',
    900: '#78350f'
  },
  teal: '#4ade80',
  purple: '#a855f7',
  orange: '#fb923c'
} as const

// Solana Network Configuration
export const SOLANA_CONFIG = {
  mainnet: {
    rpc: process.env.SOLANA_RPC_URL || 'https://api.mainnet-beta.solana.com',
    websocket: process.env.SOLANA_RPC_WEBSOCKET || 'wss://api.mainnet-beta.solana.com',
    explorer: 'https://explorer.solana.com'
  },
  devnet: {
    rpc: 'https://api.devnet.solana.com',
    websocket: 'wss://api.devnet.solana.com',
    explorer: 'https://explorer.solana.com?cluster=devnet'
  },
  testnet: {
    rpc: 'https://api.testnet.solana.com', 
    websocket: 'wss://api.testnet.solana.com',
    explorer: 'https://explorer.solana.com?cluster=testnet'
  }
} as const

// Common Solana Addresses
export const WELL_KNOWN_ADDRESSES = {
  // Native Programs
  SYSTEM_PROGRAM: '11111111111111111111111111111112',
  TOKEN_PROGRAM: 'TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA',
  ASSOCIATED_TOKEN_PROGRAM: 'ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL',
  
  // Popular Tokens
  USDC: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
  USDT: 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB',
  WBTC: '9n4nbM75f5Ui33ZbPYXn59EwSgE8CGsHtAeTH5YFeJ9E',
  
  // DEX Programs
  SERUM_DEX: '9xQeWvG816bUx9EPjHmaT23yvVM2ZWbrrpZb9PusVFin',
  RAYDIUM: '675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8',
  ORCA: 'whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc'
} as const

// Risk Assessment Thresholds
export const RISK_THRESHOLDS = {
  very_low: { min: 0, max: 20, color: 'green' },
  low: { min: 21, max: 40, color: 'green' },
  medium: { min: 41, max: 60, color: 'yellow' },
  high: { min: 61, max: 80, color: 'orange' },
  very_high: { min: 81, max: 100, color: 'red' }
} as const

// Security Score Ranges
export const SECURITY_SCORES = {
  excellent: { min: 90, max: 100, grade: 'A+' },
  very_good: { min: 80, max: 89, grade: 'A' },
  good: { min: 70, max: 79, grade: 'B' },
  fair: { min: 60, max: 69, grade: 'C' },
  poor: { min: 50, max: 59, grade: 'D' },
  very_poor: { min: 0, max: 49, grade: 'F' }
} as const

// API Rate Limits
export const RATE_LIMITS = {
  address_validation: { requests: 100, window: '1m' },
  balance_check: { requests: 50, window: '1m' },
  analysis: { requests: 20, window: '1m' },
  general: { requests: 200, window: '1m' }
} as const

// Cache Durations (in seconds)
export const CACHE_DURATIONS = {
  address_validation: 300, // 5 minutes
  balance_data: 60, // 1 minute
  token_metadata: 3600, // 1 hour
  risk_assessment: 1800, // 30 minutes
  community_data: 900, // 15 minutes
  static_content: 86400 // 24 hours
} as const

// Ad Network Configuration
export const AD_CONFIG = {
  google_adsense: {
    client: process.env.NEXT_PUBLIC_GOOGLE_ADSENSE_ID,
    slots: {
      header_banner: '1234567890',
      sidebar: '2345678901', 
      in_article: '3456789012',
      footer: '4567890123'
    }
  },
  coinzilla: {
    zones: {
      banner: 'C-123456789',
      rectangle: 'C-234567890',
      leaderboard: 'C-345678901'
    }
  },
  a_ads: {
    units: {
      banner: '1234567',
      rectangle: '2345678',
      square: '3456789'
    }
  },
  media_net: {
    customer_id: process.env.NEXT_PUBLIC_MEDIA_NET_ID,
    slots: {
      banner: '123456789',
      rectangle: '234567890'
    }
  }
} as const

// Analytics Configuration
export const ANALYTICS_CONFIG = {
  google_analytics: {
    id: process.env.NEXT_PUBLIC_GOOGLE_ANALYTICS_ID,
    config: {
      anonymize_ip: true,
      allow_google_signals: false,
      allow_ad_personalization_signals: false
    }
  },
  events: {
    address_check: 'address_check',
    analysis_complete: 'analysis_complete',
    risk_assessment: 'risk_assessment',
    ad_click: 'ad_click',
    premium_interest: 'premium_interest'
  }
} as const

// SEO Configuration
export const SEO_CONFIG = {
  default_title: 'Hannisol - Solana Address Checker | Professional Blockchain Analysis',
  title_template: '%s | Hannisol - Solana Address Checker',
  default_description: 'Professional Solana address validation and analysis tool with real-time balance tracking, security assessment, risk analysis, and community insights.',
  default_image: '/og-image.png',
  twitter_handle: '@hannisol',
  locale: 'en_US'
} as const

// Error Messages
export const ERROR_MESSAGES = {
  invalid_address: 'Please enter a valid Solana address',
  network_error: 'Network error. Please try again.',
  rate_limit: 'Too many requests. Please wait before trying again.',
  server_error: 'Server error. Please try again later.',
  not_found: 'Address not found on the blockchain',
  insufficient_data: 'Insufficient data for analysis'
} as const

// Success Messages
export const SUCCESS_MESSAGES = {
  address_validated: 'Address validation completed successfully',
  analysis_complete: 'Analysis completed successfully',
  data_refreshed: 'Data refreshed successfully',
  copied_to_clipboard: 'Copied to clipboard!'
} as const

// Feature Flags
export const FEATURE_FLAGS = {
  real_time_updates: true,
  community_analysis: true,
  risk_assessment: true,
  nft_analysis: true,
  staking_analysis: true,
  premium_features: false,
  api_access: true
} as const

// External API Endpoints
export const EXTERNAL_APIS = {
  coingecko: 'https://api.coingecko.com/api/v3',
  jupiter: 'https://quote-api.jup.ag/v6',
  birdeye: 'https://public-api.birdeye.so',
  alchemy: `https://solana-mainnet.g.alchemy.com/v2/${process.env.ALCHEMY_API_KEY}`,
  helius: `https://rpc.helius.xyz/?api-key=${process.env.HELIUS_API_KEY}`
} as const

// Social Media Links
export const SOCIAL_LINKS = {
  twitter: 'https://twitter.com/hannisol',
  github: 'https://github.com/hannisol',
  linkedin: 'https://linkedin.com/company/hannisol',
  discord: 'https://discord.gg/hannisol',
  telegram: 'https://t.me/hannisol'
} as const