import { z } from 'zod'
import { isValidSolanaAddress } from './utils'

// Solana Address Validation Schema
export const solanaAddressSchema = z
  .string()
  .min(32, 'Address must be at least 32 characters')
  .max(44, 'Address must be at most 44 characters')
  .regex(/^[1-9A-HJ-NP-Za-km-z]+$/, 'Invalid Base58 characters')
  .refine(isValidSolanaAddress, 'Invalid Solana address format')

// API Request Validation Schemas
export const addressAnalysisSchema = z.object({
  address: solanaAddressSchema,
  options: z.object({
    includeTransactions: z.boolean().default(true),
    includeTokens: z.boolean().default(true),
    includeNfts: z.boolean().default(true),
    includeRiskAssessment: z.boolean().default(true),
    includeCommunityData: z.boolean().default(true),
    transactionLimit: z.number().min(1).max(1000).default(50),
    realTime: z.boolean().default(false)
  }).optional()
})

export const balanceRequestSchema = z.object({
  address: solanaAddressSchema,
  options: z.object({
    includeTokens: z.boolean().default(true),
    includeNfts: z.boolean().default(true),
    includeStaking: z.boolean().default(true),
    includePriceData: z.boolean().default(true),
    realTime: z.boolean().default(false)
  }).optional()
})

// Email Validation
export const emailSchema = z
  .string()
  .email('Invalid email address')
  .max(254, 'Email address too long')

// Contact Form Schema
export const contactFormSchema = z.object({
  name: z.string().min(2, 'Name must be at least 2 characters').max(100, 'Name too long'),
  email: emailSchema,
  subject: z.string().min(5, 'Subject must be at least 5 characters').max(200, 'Subject too long'),
  message: z.string().min(10, 'Message must be at least 10 characters').max(1000, 'Message too long'),
  category: z.enum(['general', 'technical', 'billing', 'feature-request', 'bug-report']).default('general')
})

// API Key Schema
export const apiKeySchema = z
  .string()
  .min(32, 'API key must be at least 32 characters')
  .max(128, 'API key too long')
  .regex(/^[A-Za-z0-9_-]+$/, 'Invalid API key format')

// Rate Limiting Schema
export const rateLimitSchema = z.object({
  requests: z.number().min(1).max(10000),
  window: z.string().regex(/^\d+[smhd]$/, 'Invalid time window format'),
  identifier: z.string().optional()
})

// Search Query Schema
export const searchQuerySchema = z.object({
  query: z.string().min(1, 'Search query required').max(100, 'Query too long'),
  limit: z.number().min(1).max(100).default(10),
  offset: z.number().min(0).default(0),
  filters: z.object({
    type: z.enum(['address', 'transaction', 'token']).optional(),
    network: z.enum(['mainnet', 'devnet', 'testnet']).default('mainnet'),
    dateFrom: z.string().datetime().optional(),
    dateTo: z.string().datetime().optional()
  }).optional()
})

// Webhook Schema
export const webhookSchema = z.object({
  url: z.string().url('Invalid webhook URL'),
  events: z.array(z.enum(['address_validation', 'balance_update', 'risk_change', 'transaction_detected'])),
  secret: z.string().min(16, 'Webhook secret must be at least 16 characters').optional(),
  active: z.boolean().default(true)
})

// User Preferences Schema
export const userPreferencesSchema = z.object({
  theme: z.enum(['light', 'dark', 'system']).default('system'),
  language: z.enum(['en', 'es', 'fr', 'de', 'ja', 'ko', 'zh']).default('en'),
  currency: z.enum(['USD', 'EUR', 'GBP', 'JPY', 'BTC', 'ETH', 'SOL']).default('USD'),
  notifications: z.object({
    email: z.boolean().default(true),
    browser: z.boolean().default(true),
    security: z.boolean().default(true),
    marketing: z.boolean().default(false)
  }).default({}),
  privacy: z.object({
    analytics: z.boolean().default(true),
    cookies: z.boolean().default(true),
    thirdParty: z.boolean().default(false)
  }).default({})
})

// Risk Assessment Input Schema
export const riskAssessmentSchema = z.object({
  address: solanaAddressSchema,
  factors: z.object({
    liquidityLocked: z.boolean().optional(),
    ownershipRenounced: z.enum(['yes', 'no', 'partial']).optional(),
    largeHolders: z.enum(['concentrated', 'distributed']).optional(),
    freezeAuthority: z.enum(['enabled', 'disabled']).optional(),
    mintAuthority: z.enum(['enabled', 'disabled']).optional(),
    blacklisted: z.boolean().optional(),
    suspicious: z.boolean().optional()
  }),
  weights: z.object({
    liquidity: z.number().min(0).max(1).default(0.3),
    ownership: z.number().min(0).max(1).default(0.2),
    distribution: z.number().min(0).max(1).default(0.2),
    authority: z.number().min(0).max(1).default(0.15),
    reputation: z.number().min(0).max(1).default(0.15)
  }).optional()
})

// Community Data Schema
export const communityDataSchema = z.object({
  address: solanaAddressSchema,
  platforms: z.array(z.enum(['twitter', 'discord', 'telegram', 'reddit', 'github'])).optional(),
  metrics: z.object({
    followers: z.number().min(0).optional(),
    engagement: z.number().min(0).optional(),
    sentiment: z.enum(['positive', 'neutral', 'negative']).optional(),
    mentions: z.number().min(0).optional()
  }).optional()
})

// Pagination Schema
export const paginationSchema = z.object({
  page: z.number().min(1).default(1),
  limit: z.number().min(1).max(100).default(25),
  sort: z.enum(['asc', 'desc']).default('desc'),
  sortBy: z.string().optional()
})

// Date Range Schema
export const dateRangeSchema = z.object({
  from: z.string().datetime(),
  to: z.string().datetime()
}).refine(
  (data) => new Date(data.from) < new Date(data.to),
  'From date must be before to date'
)

// File Upload Schema
export const fileUploadSchema = z.object({
  file: z.any(),
  type: z.enum(['csv', 'json', 'txt']),
  maxSize: z.number().max(10 * 1024 * 1024), // 10MB max
  encoding: z.enum(['utf8', 'base64']).default('utf8')
})

// Analytics Event Schema
export const analyticsEventSchema = z.object({
  event: z.string().min(1, 'Event name required'),
  properties: z.record(z.any()).optional(),
  userId: z.string().optional(),
  sessionId: z.string().optional(),
  timestamp: z.string().datetime().optional()
})

// Validation Helper Functions
export function validateSolanaAddress(address: string): { success: boolean; error?: string } {
  const result = solanaAddressSchema.safeParse(address)
  if (result.success) {
    return { success: true }
  }
  return { 
    success: false, 
    error: result.error.issues[0]?.message || 'Invalid address'
  }
}

export function validateEmail(email: string): { success: boolean; error?: string } {
  const result = emailSchema.safeParse(email)
  if (result.success) {
    return { success: true }
  }
  return { 
    success: false, 
    error: result.error.issues[0]?.message || 'Invalid email'
  }
}

export function validateApiKey(apiKey: string): { success: boolean; error?: string } {
  const result = apiKeySchema.safeParse(apiKey)
  if (result.success) {
    return { success: true }
  }
  return { 
    success: false, 
    error: result.error.issues[0]?.message || 'Invalid API key'
  }
}

// Sanitization Functions
export function sanitizeAddress(address: string): string {
  return address.trim().replace(/[^1-9A-HJ-NP-Za-km-z]/g, '')
}

export function sanitizeString(input: string, maxLength: number = 255): string {
  return input
    .trim()
    .slice(0, maxLength)
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '') // Remove script tags
    .replace(/[<>]/g, '') // Remove < and > characters
}

export function sanitizeNumber(input: any, min: number = 0, max: number = Number.MAX_SAFE_INTEGER): number {
  const num = Number(input)
  if (isNaN(num)) return min
  return Math.max(min, Math.min(max, num))
}

// Type Exports
export type AddressAnalysisInput = z.infer<typeof addressAnalysisSchema>
export type BalanceRequestInput = z.infer<typeof balanceRequestSchema>
export type ContactFormInput = z.infer<typeof contactFormSchema>
export type UserPreferencesInput = z.infer<typeof userPreferencesSchema>
export type RiskAssessmentInput = z.infer<typeof riskAssessmentSchema>
export type CommunityDataInput = z.infer<typeof communityDataSchema>
export type SearchQueryInput = z.infer<typeof searchQuerySchema>
export type WebhookInput = z.infer<typeof webhookSchema>
export type PaginationInput = z.infer<typeof paginationSchema>
export type DateRangeInput = z.infer<typeof dateRangeSchema>
export type AnalyticsEventInput = z.infer<typeof analyticsEventSchema>