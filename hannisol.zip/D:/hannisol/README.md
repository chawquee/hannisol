# 🏛️ Hannisol - Solana Address Checker

> *"Hannisol's Insight, Navigating Crypto Like Hannibal Crossed the Alps."*

Professional Solana address validation and analysis tool with comprehensive security assessment, risk analysis, and community insights. Built with Next.js 14, TypeScript, and the latest ShadCN UI components.

![Hannisol Logo](./public/logo.png)

## ✨ Features

### 🔍 **Address Validation**
- **Instant validation** of Solana address format and structure
- **Real-time verification** against blockchain data
- **Base58 encoding** validation with detailed error reporting
- **Address type detection** (wallet, program, token account)

### 💰 **Balance & Holdings Analysis**
- **SOL balance** tracking with USD conversion
- **Token holdings** with metadata and valuations
- **NFT collection** analysis and floor price tracking
- **Staking rewards** and validator information

### 🛡️ **Security Assessment**
- **Risk scoring** algorithm (0-100 scale)
- **Rug pull detection** with multiple risk factors
- **Suspicious activity** monitoring
- **Blacklist/whitelist** verification

### 👥 **Community Insights**
- **Social media** sentiment analysis
- **Community engagement** metrics
- **Trending keywords** and hashtag tracking
- **AI-powered** community score

### 📊 **Professional Analytics**
- **Transaction history** analysis
- **Final grade system** (A+ to F)
- **Confidence scoring** for assessments
- **Detailed reporting** with actionable insights

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/hannisol/address-checker.git
   cd hannisol-address-checker
   ```

2. **Install dependencies**
   ```bash
   npm install
   # or
   yarn install
   ```

3. **Configure environment variables**
   ```bash
   cp .env.example .env.local
   ```
   
   Edit `.env.local` with your configuration:
   ```bash
   # Required
   NEXT_PUBLIC_SITE_URL=https://hannisol.com
   SOLANA_RPC_URL=https://api.mainnet-beta.solana.com
   
   # Ad Networks (for monetization)
   NEXT_PUBLIC_GOOGLE_ADSENSE_ID=ca-pub-xxxxxxxxxx
   NEXT_PUBLIC_COINZILLA_ZONE_ID=C-123456789
   
   # Analytics
   NEXT_PUBLIC_GOOGLE_ANALYTICS_ID=G-XXXXXXXXXX
   ```

4. **Run development server**
   ```bash
   npm run dev
   ```

5. **Open in browser**
   ```
   http://localhost:3000
   ```

## 🏗️ Project Structure

```
hannisol-address-checker/
├── src/
│   ├── app/                    # Next.js 14 App Router
│   │   ├── api/               # API routes
│   │   ├── layout.tsx         # Root layout
│   │   └── page.tsx           # Home page
│   ├── components/
│   │   ├── ui/                # ShadCN UI components
│   │   ├── address-checker/   # Core functionality
│   │   ├── ads/               # Ad network integrations
│   │   ├── layout/            # Layout components
│   │   └── analytics/         # Tracking components
│   ├── lib/                   # Utilities and configurations
│   ├── hooks/                 # Custom React hooks
│   ├── types/                 # TypeScript definitions
│   └── styles/                # Global styles
├── public/                    # Static assets
└── docs/                      # Documentation
```

## 🎨 Design System

### Brand Identity
- **Logo**: Golden circular logo with colorful accent stripes
- **Typography**: Classical serif font (Times/Georgia) for brand text
- **Colors**: Gold primary (#f59e0b) with teal, purple, orange accents
- **Theme**: Professional, trustworthy, modern

### Components
Built with **ShadCN UI** for:
- Consistent design language
- Accessibility compliance
- Modern React patterns
- Type-safe components

## 💰 Monetization Strategy

### Ad Networks Integration
- **Google AdSense** - Primary revenue stream
- **Coinzilla** - Crypto-focused advertising
- **A-ADS** - Bitcoin ad network  
- **Media.net** - Yahoo/Bing network

### Revenue Projections
```
Month 1:  $40-$190
Month 3:  $250-$770  
Month 6:  $1,300-$2,580
Month 12: $3,400-$6,860
```

### SEO Strategy
- Target keywords: "Solana address checker", "Solana wallet validator"
- Fast loading times (Core Web Vitals optimized)
- Mobile-first responsive design
- Rich snippets and structured data

## 🔧 Development

### Available Scripts

```bash
# Development
npm run dev          # Start development server
npm run build        # Build for production
npm run start        # Start production server

# Code Quality  
npm run lint         # Run ESLint
npm run lint:fix     # Fix ESLint issues
npm run type-check   # Run TypeScript checks

# Testing
npm run test         # Run tests
npm run test:watch   # Run tests in watch mode
```

### Code Style
- **ESLint** + **Prettier** for consistent formatting
- **TypeScript** for type safety
- **Conventional Commits** for clear git history
- **Component-driven** development

## 📈 Analytics & Tracking

### Implemented Tracking
- **Google Analytics 4** with custom events
- **Address validation** tracking
- **User flow** analysis
- **Ad performance** monitoring
- **SEO performance** tracking

### Custom Events
```typescript
// Address validation
trackAddressCheck(address, isValid)

// Analysis completion  
trackAnalysisComplete(address, analysisTime)

// Risk assessment
trackRiskAssessment(riskScore, riskLevel)

// Monetization
trackAdClick(adNetwork, adSlot)
```

## 🚀 Deployment

### Production Checklist
- [ ] Environment variables configured
- [ ] Ad network accounts set up
- [ ] Google Analytics configured
- [ ] Domain and SSL certificate
- [ ] Performance optimization
- [ ] SEO verification

### Recommended Hosting
- **Vercel** (recommended) - Zero config deployment
- **Netlify** - Easy static hosting
- **Railway** - Full-stack deployment
- **VPS** - Custom server setup

### Deploy to Vercel
```bash
npm install -g vercel
vercel --prod
```

## 🤝 Contributing

1. **Fork the repository**
2. **Create feature branch** (`git checkout -b feature/amazing-feature`)
3. **Commit changes** (`git commit -m 'Add amazing feature'`)
4. **Push to branch** (`git push origin feature/amazing-feature`)
5. **Open Pull Request**

### Development Guidelines
- Follow existing code style
- Add tests for new features
- Update documentation
- Ensure mobile responsiveness

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- **Solana Foundation** for the amazing blockchain infrastructure
- **ShadCN** for the beautiful UI component library
- **Next.js Team** for the incredible React framework
- **Vercel** for seamless deployment platform

## 📞 Support

- **Website**: [https://hannisol.com](https://hannisol.com)
- **Email**: support@hannisol.com
- **Documentation**: [https://hannisol.com/docs](https://hannisol.com/docs)
- **Issues**: [GitHub Issues](https://github.com/hannisol/address-checker/issues)

---

<div align="center">
  <p><strong>"Hannisol's Insight, Navigating Crypto Like Hannibal Crossed the Alps."</strong></p>
  <p>Built with ❤️ for the Solana community</p>
</div>